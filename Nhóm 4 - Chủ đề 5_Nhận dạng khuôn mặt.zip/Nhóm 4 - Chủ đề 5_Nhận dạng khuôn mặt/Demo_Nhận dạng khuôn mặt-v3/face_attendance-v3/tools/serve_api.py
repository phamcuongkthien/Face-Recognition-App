"""API chỉ-đọc cho điểm danh (JSON), để tích hợp với hệ thống khác.

  set FACE_API_TOKEN=mot-chuoi-bi-mat-dai
  python tools/serve_api.py --port 8765

Gọi:  curl -H "Authorization: Bearer <token>" http://127.0.0.1:8765/api/attendance?day=2026-11-09

Điểm cần biết:
  - Chỉ đọc. Không có vector khuôn mặt nào được trả ra.
  - Mặc định chỉ lắng nghe 127.0.0.1. Muốn mở ra mạng, hãy đặt sau HTTPS (nginx/caddy):
    server này dùng HTTP thường nên token sẽ bị lộ nếu đi qua mạng không mã hóa.
  - Không có token trong biến môi trường thì server từ chối chạy.
"""

import argparse
import datetime
import hmac
import json
import os
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import Config  # noqa: E402
from db import Database  # noqa: E402


def route(db, path, query):
    """Trả (mã, dữ liệu). Tách riêng để kiểm thử được."""

    if path == "/api/health":
        return 200, {"ok": True}

    if path == "/api/students":
        return 200, [
            {k: s[k] for k in ("student_id", "name", "class_name", "faculty")}
            for s in db.list_students()
        ]

    if path == "/api/attendance":

        day = (query.get("day") or [datetime.date.today().isoformat()])[0]

        try:
            datetime.date.fromisoformat(day)
        except ValueError:
            return 400, {"error": "day phải dạng YYYY-MM-DD"}

        sess = query.get("session")

        return 200, db.attendance_on(day, sess[0] if sess else None)

    return 404, {"error": "không có đường dẫn này"}


def make_handler(db_path, token):

    class Handler(BaseHTTPRequestHandler):

        def do_GET(self):

            given = self.headers.get("Authorization", "")

            if not hmac.compare_digest(given, f"Bearer {token}"):
                return self._send(401, {"error": "sai hoặc thiếu token"})

            url = urlparse(self.path)

            # SQLite: mỗi yêu cầu một kết nối riêng (an toàn khi nhiều luồng)
            db = Database(db_path)

            try:
                code, data = route(db, url.path, parse_qs(url.query))
            finally:
                db.close()

            self._send(code, data)

        def _send(self, code, data):

            body = json.dumps(data, ensure_ascii=False).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, *args):
            pass

    return Handler


def main():

    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8765)
    a = ap.parse_args()

    token = os.environ.get("FACE_API_TOKEN", "")

    if len(token) < 16:
        sys.exit("Hãy đặt biến môi trường FACE_API_TOKEN dài ít nhất 16 ký tự.")

    base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    db_path = os.path.join(base, "diemdanh.db")

    Config.load(base)

    print(f"API chỉ-đọc tại http://{a.host}:{a.port}/api/  (Ctrl+C để dừng)")
    ThreadingHTTPServer((a.host, a.port), make_handler(db_path, token)).serve_forever()


if __name__ == "__main__":
    main()
