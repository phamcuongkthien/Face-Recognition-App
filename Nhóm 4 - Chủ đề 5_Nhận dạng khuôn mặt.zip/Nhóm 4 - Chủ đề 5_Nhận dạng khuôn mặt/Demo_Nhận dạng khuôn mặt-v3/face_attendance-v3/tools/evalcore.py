"""Lõi tính toán đánh giá nhận diện (thuần numpy, kiểm thử được không cần ảnh).

Mô phỏng đúng cách hệ thống thật quyết định: recognizer.match_face với ngưỡng
và biên (margin).
"""

import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from recognizer import match_face  # noqa: E402


def build_index(enrolled):
    """enrolled: {person: [enc,...]} -> (owner_ids, matrix)."""

    owners, rows = [], []

    for person, encs in enrolled.items():
        for e in encs:
            owners.append(person)
            rows.append(np.asarray(e, dtype=np.float64))

    return owners, np.vstack(rows)


def person_distances(owners, matrix, enc):
    """{person: khoảng cách nhỏ nhất tới các mẫu của người đó}."""

    d = np.linalg.norm(matrix - np.asarray(enc), axis=1)

    best = {}

    for person, x in zip(owners, d):
        if person not in best or x < best[person]:
            best[person] = float(x)

    return best


def pair_scores(tests, owners, matrix):
    """Điểm cặp: genuine (đúng người) và impostor (người khác / người lạ).

    tests: [(person_or_None, condition, enc)]; None = người lạ chưa đăng ký.
    """

    genuine, impostor = [], []

    for person, _cond, enc in tests:

        for other, d in person_distances(owners, matrix, enc).items():

            (genuine if other == person else impostor).append(d)

    return np.array(genuine), np.array(impostor)


def rates_at(genuine, impostor, t):
    """(FRR, FAR) tại ngưỡng t trên điểm cặp."""

    frr = float(np.mean(genuine > t)) if len(genuine) else float("nan")
    far = float(np.mean(impostor <= t)) if len(impostor) else float("nan")

    return frr, far


def equal_error_rate(genuine, impostor):
    """(EER, ngưỡng) — nơi FRR ≈ FAR."""

    best = (float("inf"), None, None)

    for t in np.linspace(0.2, 0.9, 701):

        frr, far = rates_at(genuine, impostor, t)

        gap = abs(frr - far)

        if gap < best[0]:
            best = (gap, (frr + far) / 2, float(t))

    return best[1], best[2]


def system_outcomes(tests, owners, matrix, threshold, margin):
    """Chạy quyết định thật của hệ thống trên từng ảnh test.

    Trả về dict đếm:
      ta  : nhận đúng người
      fr  : người đã đăng ký nhưng bị từ chối (hoặc "chưa chắc")
      mis : người đã đăng ký bị nhận NHẦM thành người khác  (nguy hiểm)
      fa  : người lạ bị nhận thành một người đã đăng ký     (nguy hiểm)
      tr  : người lạ bị từ chối đúng
    và by_cond: {condition: [số test, số fr]} cho người đã đăng ký.
    """

    out = dict(ta=0, fr=0, mis=0, fa=0, tr=0)
    by_cond = {}

    for person, cond, enc in tests:

        sid, _ = match_face(matrix, owners, enc, threshold, margin)

        if person is None:
            out["tr" if sid is None else "fa"] += 1
            continue

        n = by_cond.setdefault(cond, [0, 0])
        n[0] += 1

        if sid == person:
            out["ta"] += 1
        elif sid is None:
            out["fr"] += 1
            n[1] += 1
        else:
            out["mis"] += 1
            n[1] += 1

    out["by_cond"] = by_cond

    return out


def upper_bound_zero(n):
    """Cận trên 95% của tỉ lệ lỗi khi quan sát 0 lỗi trong n lần ("quy tắc 3")."""

    return 3.0 / n if n > 0 else float("nan")


def sweep(tests, owners, matrix, margin, thresholds):
    """Bảng theo ngưỡng: [(t, frr_hethong, loi_nguy_hiem)]."""

    rows = []

    for t in thresholds:

        o = system_outcomes(tests, owners, matrix, t, margin)

        genuine_n = o["ta"] + o["fr"] + o["mis"]
        imp_n = o["fa"] + o["tr"]

        frr = (o["fr"] + o["mis"]) / genuine_n if genuine_n else float("nan")

        bad = o["mis"] + o["fa"]
        bad_den = genuine_n + imp_n

        rows.append((float(t), frr, bad, bad_den))

    return rows
