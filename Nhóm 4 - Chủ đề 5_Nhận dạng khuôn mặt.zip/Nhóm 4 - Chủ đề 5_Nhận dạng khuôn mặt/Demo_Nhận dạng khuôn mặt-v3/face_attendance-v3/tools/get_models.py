"""Tải các mô hình ONNX cần cho chống giả mạo thụ động và ArcFace.

  python tools/get_models.py              # tải tất cả vào thư mục models/
  python tools/get_models.py --only antispoof
  python tools/get_models.py --only arcface

Mỗi file được kiểm tra SHA-256; file sai sẽ bị xóa.
Kiểm tra GIẤY PHÉP của từng mô hình trước khi dùng ngoài mục đích học tập.
"""

import argparse
import hashlib
import io
import os
import sys
import urllib.request
import zipfile

ANTISPOOF = {
    "MiniFASNetV2.onnx": (
        "https://github.com/yakhyo/face-anti-spoofing/releases/download/weights/MiniFASNetV2.onnx",
        "b32929adc2d9c34b9486f8c4c7bc97c1b69bc0ea9befefc380e4faae4e463907",
    ),
    "MiniFASNetV1SE.onnx": (
        "https://github.com/yakhyo/face-anti-spoofing/releases/download/weights/MiniFASNetV1SE.onnx",
        "ebab7f90c7833fbccd46d3a555410e78d969db5438e169b6524be444862b3676",
    ),
}

# Gói buffalo_s của InsightFace (~127 MB), chỉ lấy w600k_mbf.onnx (MobileFaceNet)
ARCFACE_ZIP = "https://github.com/deepinsight/insightface/releases/download/v0.7/buffalo_s.zip"
ARCFACE_FILE = "w600k_mbf.onnx"
ARCFACE_SHA = "9cc6e4a75f0e2bf0b1aed94578f144d15175f357bdc05e815e5c4a02b319eb4f"


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def fetch(url):

    print("Đang tải", url)

    with urllib.request.urlopen(url, timeout=120) as r:
        return r.read()


def save_checked(path, data, expected):

    if sha256(data) != expected:
        sys.exit(f"SHA-256 không khớp cho {os.path.basename(path)} — không lưu.")

    with open(path, "wb") as f:
        f.write(data)

    print("Đã lưu", path)


def main():

    ap = argparse.ArgumentParser()
    ap.add_argument("--only", choices=["antispoof", "arcface"])
    ap.add_argument("--dir", default="models")
    a = ap.parse_args()

    os.makedirs(a.dir, exist_ok=True)

    if a.only in (None, "antispoof"):

        for name, (url, sha) in ANTISPOOF.items():

            path = os.path.join(a.dir, name)

            if os.path.exists(path):
                print("Đã có", path)
                continue

            save_checked(path, fetch(url), sha)

    if a.only in (None, "arcface"):

        path = os.path.join(a.dir, ARCFACE_FILE)

        if os.path.exists(path):
            print("Đã có", path)
        else:
            z = zipfile.ZipFile(io.BytesIO(fetch(ARCFACE_ZIP)))
            save_checked(path, z.read(ARCFACE_FILE), ARCFACE_SHA)


if __name__ == "__main__":
    main()
