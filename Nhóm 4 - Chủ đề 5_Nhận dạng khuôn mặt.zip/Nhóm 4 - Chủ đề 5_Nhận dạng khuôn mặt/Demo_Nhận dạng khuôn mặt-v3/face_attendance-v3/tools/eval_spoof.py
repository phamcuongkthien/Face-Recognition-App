"""Chọn ngưỡng chống giả mạo thụ động (antispoof_threshold) từ ảnh thật của bạn.

Chuẩn bị 2 thư mục ảnh chụp BẰNG CHÍNH CAMERA ĐIỂM DANH, đúng chỗ đặt thật:
  spoof_data/real/    ảnh người thật đứng trước camera (nhiều người, nhiều ánh sáng)
  spoof_data/attack/  ảnh tấn công: ảnh in, ảnh/video trên điện thoại giơ trước camera

Chạy:  python tools/eval_spoof.py spoof_data

Kết quả:
  BPCER = tỉ lệ người thật bị chặn nhầm
  APCER = tỉ lệ ảnh giả vẫn lọt qua
Ngưỡng đề xuất là ngưỡng có APCER thấp nhất mà BPCER còn chịu được.
"""

import argparse
import datetime
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

IMG_EXT = (".jpg", ".jpeg", ".png", ".bmp")


def sweep(real, attack, thresholds):
    """[(ngưỡng, BPCER, APCER)] với real/attack là danh sách xác suất người thật."""

    real, attack = np.asarray(real, float), np.asarray(attack, float)
    rows = []

    for t in thresholds:
        bp = float((real < t).mean()) if len(real) else float("nan")
        ap = float((attack >= t).mean()) if len(attack) else float("nan")
        rows.append((float(t), bp, ap))

    return rows


def recommend(rows, max_bpcer=0.05):
    """Ngưỡng có APCER nhỏ nhất trong số những ngưỡng BPCER <= max_bpcer."""

    ok = [r for r in rows if r[1] <= max_bpcer and r[2] == r[2]]

    if not ok:
        return None

    best = min(r[2] for r in ok)

    return max(r[0] for r in ok if r[2] == best)


def probabilities(folder, model_dir):

    import cv2
    import face_recognition as fr

    from antispoof import PassiveAntiSpoof

    model = PassiveAntiSpoof(model_dir)
    out, skipped = [], 0

    for f in sorted(os.listdir(folder)):

        if not f.lower().endswith(IMG_EXT):
            continue

        img = cv2.imread(os.path.join(folder, f))

        if img is None:
            skipped += 1
            continue

        locs = fr.face_locations(np.ascontiguousarray(img[:, :, ::-1]))

        if not locs:
            skipped += 1
            continue

        t, r, b, l = max(locs, key=lambda x: (x[2] - x[0]) * (x[1] - x[3]))
        out.append(model.real_probability(img, [l, t, r, b]))

    return out, skipped


def main():

    ap = argparse.ArgumentParser()
    ap.add_argument("folder")
    ap.add_argument("--models", default="models")
    ap.add_argument("--max-bpcer", type=float, default=0.05)
    a = ap.parse_args()

    base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    models = a.models if os.path.isabs(a.models) else os.path.join(base, a.models)

    real, s1 = probabilities(os.path.join(a.folder, "real"), models)
    attack, s2 = probabilities(os.path.join(a.folder, "attack"), models)

    rows = sweep(real, attack, np.arange(0.30, 0.96, 0.05))
    best = recommend(rows, a.max_bpcer)

    L = [f"# Hiệu chỉnh chống giả mạo ({datetime.datetime.now():%Y-%m-%d %H:%M})", "",
         f"- Ảnh thật dùng được: {len(real)} (bỏ {s1}); ảnh tấn công: {len(attack)} (bỏ {s2})", ""]

    if len(real) < 30 or len(attack) < 30:
        L.append("⚠ Dưới 30 ảnh mỗi loại: kết quả chỉ mang tính tham khảo.\n")

    L += ["| Ngưỡng | Chặn nhầm người thật (BPCER) | Ảnh giả lọt qua (APCER) |", "|---|---|---|"]
    L += [f"| {t:.2f} | {b:.1%} | {p:.1%} |" for t, b, p in rows]
    L.append("")

    if best is None:
        L.append("**Kết luận:** không có ngưỡng nào đạt BPCER yêu cầu. KHÔNG bật antispoof_enable; "
                 "kiểm tra ánh sáng/vị trí camera hoặc chỉ dùng thử thách quay đầu/há miệng.")
    else:
        row = next(r for r in rows if r[0] == best)
        L.append(f"**Đề xuất:** `antispoof_threshold = {best:.2f}` "
                 f"(chặn nhầm {row[1]:.1%}, giả lọt {row[2]:.1%}). "
                 "APCER > 0 nghĩa là vẫn còn cách qua mặt, hãy giữ thêm thử thách ngẫu nhiên.")

    text = "\n".join(L)
    print(text)

    os.makedirs("reports", exist_ok=True)
    path = os.path.join("reports", f"spoof_{datetime.datetime.now():%Y%m%d_%H%M%S}.md")

    with open(path, "w", encoding="utf-8") as f:
        f.write(text)

    print(f"\nĐã lưu: {path}")


if __name__ == "__main__":
    main()
