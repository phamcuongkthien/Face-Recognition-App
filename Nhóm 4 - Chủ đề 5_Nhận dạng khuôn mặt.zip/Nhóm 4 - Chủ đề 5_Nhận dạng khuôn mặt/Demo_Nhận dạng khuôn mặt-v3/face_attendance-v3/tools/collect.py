"""Chụp ảnh từ webcam để làm bộ dữ liệu đánh giá.

  python tools/collect.py dataset An enroll          # 8 ảnh đăng ký
  python tools/collect.py dataset An test_sang       # ảnh thử: đủ sáng
  python tools/collect.py dataset An test_toi -n 10
  python tools/collect.py dataset _strangers ""      # người lạ (đặt tên thư mục con rỗng)

Nhấn SPACE để chụp, Q để thoát. Ảnh được lật gương giống màn hình điểm danh.
"""

import argparse
import datetime
import os
import sys


def main():

    import cv2

    ap = argparse.ArgumentParser()
    ap.add_argument("dataset")
    ap.add_argument("person")
    ap.add_argument("folder")
    ap.add_argument("-n", type=int, default=8)
    ap.add_argument("--camera", type=int, default=0)
    a = ap.parse_args()

    out = os.path.join(a.dataset, a.person, a.folder) if a.folder else os.path.join(a.dataset, a.person)
    os.makedirs(out, exist_ok=True)

    backend = cv2.CAP_DSHOW if sys.platform.startswith("win") else cv2.CAP_ANY
    cap = cv2.VideoCapture(a.camera, backend)

    if not cap.isOpened():
        sys.exit("Không mở được camera")

    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

    saved = 0

    while saved < a.n:

        ok, frame = cap.read()

        if not ok:
            continue

        frame = frame[:, ::-1].copy()

        view = frame.copy()
        cv2.putText(view, f"{a.person}/{a.folder}  {saved}/{a.n}  SPACE=chup  Q=thoat",
                    (10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
        cv2.imshow("collect", view)

        k = cv2.waitKey(30) & 0xFF

        if k == ord("q"):
            break

        if k == 32:
            name = datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f") + ".jpg"
            cv2.imwrite(os.path.join(out, name), frame)
            saved += 1

    cap.release()
    cv2.destroyAllWindows()
    print(f"Đã lưu {saved} ảnh vào {out}")


if __name__ == "__main__":
    main()
