"""Đo độ chính xác nhận diện trên ảnh thật của lớp.

Cấu trúc thư mục ảnh (mỗi ảnh một khuôn mặt, càng đa dạng càng tốt):

  dataset/
    An/
      enroll/        5-10 ảnh dùng để "đăng ký" (như lúc đăng ký thật)
      test_sang/     ảnh thử: đủ sáng
      test_toi/      ảnh thử: thiếu sáng
      test_kinh/     ảnh thử: đeo kính ...   (tên thư mục test_<điều kiện> tự đặt)
    Binh/
      ...
    _strangers/      ảnh của người KHÔNG đăng ký (để đo nhận nhầm người lạ)

Chạy:
  python tools/evaluate.py dataset
  python tools/evaluate.py dataset --threshold 0.45 --margin 0.04
"""

import argparse
import datetime
import os
import pickle
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from tools import evalcore  # noqa: E402

IMG_EXT = (".jpg", ".jpeg", ".png", ".bmp")


def list_images(folder):

    return sorted(
        os.path.join(folder, f) for f in os.listdir(folder)
        if f.lower().endswith(IMG_EXT)
    )


class Encoder:
    """Mã hóa ảnh bằng chính face_recognition của hệ thống, có cache."""

    def __init__(self, cache_path, backend=None):

        import face_recognition

        self.fr = face_recognition
        self.backend = backend
        self.cache_path = cache_path
        self.cache = {}
        self.no_face = 0
        self.multi_face = 0
        self.missing = {}      # {(người, thư mục): số ảnh không thấy mặt}
        self.total = {}        # {(người, thư mục): tổng số ảnh}

        if os.path.exists(cache_path):
            try:
                with open(cache_path, "rb") as f:
                    self.cache = pickle.load(f)
            except Exception:
                self.cache = {}

    def save(self):

        with open(self.cache_path, "wb") as f:
            pickle.dump(self.cache, f)

    def encode(self, path):
        """Vector 128 chiều của khuôn mặt lớn nhất, hoặc None nếu không có mặt."""

        key = (path, os.path.getmtime(path))

        if key in self.cache:
            enc, n = self.cache[key]
        else:
            img = self.fr.load_image_file(path)
            locs = self.fr.face_locations(img)
            n = len(locs)
            enc = None

            if locs:
                big = max(locs, key=lambda l: (l[2] - l[0]) * (l[1] - l[3]))
                if self.backend is None:
                    enc = self.fr.face_encodings(img, [big])[0]
                else:
                    # backend khác (ArcFace) nhận ảnh RGB + khung mặt
                    enc = self.backend.encode(img, [big])[0]

            self.cache[key] = (enc, n)

        if enc is None:
            self.no_face += 1
        elif n > 1:
            self.multi_face += 1

        return enc


def load_dataset(root, enc):
    """Trả về (enrolled, tests); thống kê ảnh không thấy mặt nằm ở enc.missing."""

    enrolled, tests = {}, []

    for person in sorted(os.listdir(root)):

        pdir = os.path.join(root, person)

        if not os.path.isdir(pdir) or person.startswith("."):
            continue

        if person == "_strangers":
            for p in list_images(pdir):
                e = enc.encode(p)
                enc.total[(person, "")] = enc.total.get((person, ""), 0) + 1
                if e is None:
                    enc.missing[(person, "")] = enc.missing.get((person, ""), 0) + 1
                if e is not None:
                    tests.append((None, "nguoi_la", e))
            continue

        for sub in sorted(os.listdir(pdir)):

            sdir = os.path.join(pdir, sub)

            if not os.path.isdir(sdir):
                continue

            for p in list_images(sdir):

                e = enc.encode(p)

                k = (person, sub)
                enc.total[k] = enc.total.get(k, 0) + 1

                if e is None:
                    enc.missing[k] = enc.missing.get(k, 0) + 1
                    continue

                if sub == "enroll":
                    enrolled.setdefault(person, []).append(e)
                elif sub.startswith("test_"):
                    tests.append((person, sub[5:], e))

    return enrolled, tests


def pct(x):
    return "n/a" if x != x else f"{100 * x:.2f}%"


def diagnostics(enrolled, tests, owners, matrix, threshold, margin, missing, total):
    """Phần chẩn đoán: giúp phát hiện dữ liệu bị gắn nhầm tên/lẫn người."""

    from recognizer import match_face

    L = []
    add = L.append

    add("")
    add("## Chẩn đoán dữ liệu")

    # 1) ảnh không thấy mặt theo thư mục
    if missing:
        add("")
        add("**Ảnh không tìm thấy mặt, theo thư mục** (nhiều = ảnh quá tối/xa/ngược sáng/lệch mặt):")
        add("")
        add("| Người | Thư mục | Không thấy mặt | Tổng ảnh |")
        add("|---|---|---|---|")
        for (person, sub), n in sorted(missing.items()):
            add(f"| {person} | {sub or '(gốc)'} | {n} | {total.get((person, sub), '?')} |")

    # 2) nhầm lẫn: người thật -> hệ thống nhận là ai
    conf = {}

    for person, _c, enc in tests:
        if person is None:
            continue
        sid, _ = match_face(matrix, owners, enc, threshold, margin)
        conf[(person, sid or "(từ chối)")] = conf.get((person, sid or "(từ chối)"), 0) + 1

    if conf:
        add("")
        add("**Hệ thống nhận ảnh của ai thành ai:**")
        add("")
        add("| Ảnh thật của | Hệ thống nhận là | Số ảnh |")
        add("|---|---|---|")
        for (a, b), n in sorted(conf.items()):
            add(f"| {a} | {b} | {n} |")

    # 3) mỗi người: khoảng cách tới mẫu của chính mình và của người khác
    people = sorted(enrolled)

    if len(people) >= 2:
        add("")
        add("**Khoảng cách trung bình từ ảnh thử của mỗi người tới mẫu đăng ký của từng người:**")
        add("")
        add("| Ảnh thử của \\ Mẫu của | " + " | ".join(people) + " |")
        add("|---|" + "---|" * len(people))
        for a in people:
            row = []
            for b in people:
                ds = [evalcore.person_distances(owners, matrix, e)[b]
                      for p, _c, e in tests if p == a]
                row.append(f"{np.mean(ds):.3f}" if ds else "—")
            add(f"| {a} | " + " | ".join(row) + " |")

        # 4) hai bộ mẫu đăng ký có phải cùng một khuôn mặt?
        add("")
        add("**Hai bộ mẫu đăng ký có khác người thật không?** (cùng người thường < 0.5, khác người thường > 0.6)")
        add("")
        for i, a in enumerate(people):
            for b in people[i + 1:]:
                d = np.linalg.norm(
                    np.array(enrolled[a])[:, None, :] - np.array(enrolled[b])[None, :, :],
                    axis=2
                )
                note = ""
                if d.min() < 0.5:
                    note = "  ⚠ GẦN NHƯ CÙNG MỘT KHUÔN MẶT — kiểm tra lại ảnh enroll của hai thư mục"
                add(f"- {a} ↔ {b}: nhỏ nhất {d.min():.3f}, trung bình {d.mean():.3f}{note}")

    # 5) mỗi bộ enroll có nhất quán không?
    add("")
    add("**Độ nhất quán trong bộ ảnh đăng ký của từng người** (khoảng cách giữa các ảnh enroll; > 0.6 là đáng ngờ — lẫn người hoặc ảnh quá khác nhau):")
    add("")
    for a in people:
        E = np.array(enrolled[a])
        if len(E) < 2:
            add(f"- {a}: chỉ có {len(E)} mẫu")
            continue
        d = np.linalg.norm(E[:, None, :] - E[None, :, :], axis=2)
        d = d[np.triu_indices(len(E), 1)]
        note = "  ⚠ bộ enroll không nhất quán" if d.max() > 0.6 else ""
        add(f"- {a}: {len(E)} mẫu, trung bình {d.mean():.3f}, lớn nhất {d.max():.3f}{note}")

    return L


SWEEP_RANGE = {"dlib": (0.30, 0.66, 0.025), "arcface": (0.60, 1.42, 0.04)}


def build_report(enrolled, tests, threshold, margin, no_face=0, multi_face=0,
                 missing=None, total=None, backend="dlib"):
    """Tạo báo cáo (chuỗi markdown). Chạy được cả khi chỉ có 1 người đăng ký."""

    owners, matrix = evalcore.build_index(enrolled)

    genuine, impostor = evalcore.pair_scores(tests, owners, matrix)

    o = evalcore.system_outcomes(tests, owners, matrix, threshold, margin)

    n_gen = o["ta"] + o["fr"] + o["mis"]
    n_str = o["fa"] + o["tr"]
    single = len(enrolled) < 2

    lines = []
    add = lines.append

    add(f"# Báo cáo đánh giá nhận diện — {datetime.datetime.now():%Y-%m-%d %H:%M}")
    add("")
    add("## Dữ liệu")
    add(f"- Số người đăng ký: {len(enrolled)}; số mẫu đăng ký: {len(owners)}")
    add(f"- Ảnh thử của người đã đăng ký: {n_gen}; ảnh người lạ: {n_str}")
    add(f"- Ảnh không tìm thấy mặt (bị bỏ): {no_face}; ảnh có nhiều mặt (lấy mặt lớn nhất): {multi_face}")

    if single:
        add("")
        add("> **Chỉ có 1 người đăng ký:** chỉ đo được phía *từ chối nhầm người thật* (FRR). "
            "Chưa đo được *nhận nhầm sang người khác*, nên KHÔNG kết luận được ngưỡng nào an toàn. "
            "Cần thêm người (hoặc ảnh người lạ) để đo phía nguy hiểm.")

    add("")
    add(f"## Kết quả với cấu hình hiện tại (ngưỡng {threshold}, biên {margin})")
    add(f"- Nhận đúng: {o['ta']}/{n_gen} ({pct(o['ta'] / n_gen if n_gen else float('nan'))})")
    add(f"- Từ chối nhầm người thật (FRR): {o['fr']}/{n_gen} ({pct(o['fr'] / n_gen if n_gen else float('nan'))})")

    if not single:
        add(f"- **Nhận NHẦM sang người khác: {o['mis']}/{n_gen}**")

    if n_str:
        add(f"- **Người lạ bị nhận thành người đã đăng ký: {o['fa']}/{n_str}**")

    if not single and n_str and o["mis"] + o["fa"] == 0:
        den = n_gen + n_str
        add(f"- 0 lỗi nguy hiểm trên {den} lượt → cận trên 95% của tỉ lệ lỗi ≈ "
            f"{pct(evalcore.upper_bound_zero(den))} (dữ liệu càng ít, cận càng rộng)")

    add("")
    add("## Theo điều kiện chụp (tỉ lệ bị từ chối/nhận sai)")
    add("| Điều kiện | Số ảnh | Lỗi | Tỉ lệ lỗi |")
    add("|---|---|---|---|")

    for cond, (n, bad) in sorted(o["by_cond"].items()):
        add(f"| {cond} | {n} | {bad} | {pct(bad / n)} |")

    add("")
    add("## Khoảng cách tới mẫu đăng ký (càng nhỏ càng giống)")

    if len(genuine):
        q = np.percentile(genuine, [50, 90, 99])
        add(f"- Cùng người: trung bình {genuine.mean():.3f}, trung vị {q[0]:.3f}, "
            f"phân vị 90% {q[1]:.3f}, 99% {q[2]:.3f}, lớn nhất {genuine.max():.3f}")

        for cond in sorted({c for p, c, _ in tests if p is not None}):
            ds = [evalcore.person_distances(owners, matrix, e).get(p)
                  for p, c, e in tests if p is not None and c == cond]
            ds = np.array([d for d in ds if d is not None])
            if len(ds):
                add(f"  - {cond}: trung bình {ds.mean():.3f}, lớn nhất {ds.max():.3f}")

    if len(impostor):
        add(f"- Khác người: trung bình {impostor.mean():.3f}, nhỏ nhất {impostor.min():.3f}")
        eer, eer_t = evalcore.equal_error_rate(genuine, impostor)
        if eer is not None:
            add(f"- EER ≈ {pct(eer)} tại ngưỡng ≈ {eer_t:.2f}")
    else:
        add("- Khác người: chưa có dữ liệu")

    lines.extend(diagnostics(
        enrolled, tests, owners, matrix, threshold, margin,
        missing or {}, total or {}
    ))

    add("")
    add("## Quét ngưỡng (giữ biên hiện tại)")
    add("| Ngưỡng | Từ chối nhầm người thật | Lỗi nguy hiểm (nhầm người + nhận người lạ) |")
    add("|---|---|---|")

    safe = []

    for t, frr, bad, den in evalcore.sweep(
        tests, owners, matrix, margin, np.arange(*SWEEP_RANGE.get(backend, SWEEP_RANGE["dlib"]))
    ):
        add(f"| {t:.3f} | {pct(frr)} | {bad}/{den} |" if not single or n_str
            else f"| {t:.3f} | {pct(frr)} | không đo được |")
        if bad == 0:
            safe.append((t, frr))

    add("")

    if single and not n_str:
        add("**Gợi ý:** chưa thể chọn ngưỡng. Hãy giữ 0,5 và chờ dữ liệu của người khác.")
    elif safe:
        t, frr = max(safe, key=lambda x: x[0])
        add(f"**Gợi ý:** ngưỡng lớn nhất không có lỗi nguy hiểm trong dữ liệu này là {t:.3f} "
            f"(từ chối nhầm người thật {pct(frr)}). Nên chọn thấp hơn một chút để có dư địa.")
    else:
        add("**Gợi ý:** mọi ngưỡng thử đều có lỗi nguy hiểm; cần thêm ảnh hoặc xem lại chất lượng ảnh đăng ký.")

    return "\n".join(lines)


def main():

    ap = argparse.ArgumentParser()
    ap.add_argument("dataset")
    ap.add_argument("--backend", choices=("dlib", "arcface"), default="dlib")
    ap.add_argument("--threshold", type=float, default=None)
    ap.add_argument("--margin", type=float, default=None)
    ap.add_argument("--out", default="reports")
    a = ap.parse_args()

    base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    sys.path.insert(0, base)

    import backends
    from config import Config

    cfg = Config(backend=a.backend)
    thr, mar = backends.thresholds_for(cfg)
    a.threshold = thr if a.threshold is None else a.threshold
    a.margin = mar if a.margin is None else a.margin

    be = None if a.backend == "dlib" else backends.make_backend(cfg, base)

    # cache riêng cho mỗi mô hình để không lẫn vector 128 và 512 chiều
    enc = Encoder(os.path.join(a.dataset, f".enc_cache_{a.backend}.pkl"), be)

    enrolled, tests = load_dataset(a.dataset, enc)

    enc.save()

    if len(enrolled) < 1:
        sys.exit("Cần ít nhất 1 người có thư mục enroll/ chứa ảnh.")

    text = build_report(
        enrolled, tests, a.threshold, a.margin, enc.no_face, enc.multi_face,
        enc.missing, enc.total, a.backend
    )

    os.makedirs(a.out, exist_ok=True)

    path = os.path.join(a.out, f"eval_{datetime.datetime.now():%Y%m%d_%H%M%S}.md")

    with open(path, "w", encoding="utf-8") as f:
        f.write(text)

    print(text)
    print(f"\nĐã lưu: {path}")


if __name__ == "__main__":
    main()
