"""Lưu trữ dữ liệu cho hệ thống điểm danh bằng SQLite.

Thay thế accounts.pkl, dataset.pkl và việc ghi trực tiếp vào Excel.
Excel giờ chỉ là file xuất báo cáo (export_excel).
"""

import datetime
import logging
import os
import pickle
import sqlite3

import numpy as np

import secure

from auth import hash_password, verify_password

log = logging.getLogger(__name__)

ROLE_ADMIN = "admin"
ROLE_USER = "user"

ENCODING_DIM = 128

SLOT_SEP = "|"


def slot_of(day, session=""):
    """Khóa của một buổi điểm danh: 'YYYY-MM-DD' hoặc 'YYYY-MM-DD|Tên ca'."""

    return f"{day}{SLOT_SEP}{session}" if session else day


def split_slot(slot):
    """'2026-10-06|Ca sáng' -> ('2026-10-06', 'Ca sáng')."""

    day, _, session = slot.partition(SLOT_SEP)

    return day, session


def slot_label(slot, with_year=True):
    """Nhãn hiển thị: '06/10/2026' hoặc '06/10/2026 · Ca sáng'."""

    day, session = split_slot(slot)

    fmt = "%d/%m/%Y" if with_year else "%d/%m"

    text = datetime.datetime.strptime(day, "%Y-%m-%d").strftime(fmt)

    return f"{text} · {session}" if session else text


# =========================================================
# CƠ SỞ DỮ LIỆU
# =========================================================
SCHEMA = """
CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT
);

CREATE TABLE IF NOT EXISTS users (
    username      TEXT PRIMARY KEY,
    password_hash TEXT NOT NULL,
    role          TEXT NOT NULL DEFAULT 'user'
);

CREATE TABLE IF NOT EXISTS students (
    student_id TEXT PRIMARY KEY,
    name       TEXT NOT NULL,
    class_name TEXT NOT NULL DEFAULT '',
    faculty    TEXT NOT NULL DEFAULT '',
    active     INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS face_samples (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id TEXT NOT NULL REFERENCES students(student_id),
    encoding   BLOB NOT NULL
    -- cột model (dlib/arcface) được thêm bằng MIGRATIONS
);

CREATE TABLE IF NOT EXISTS attendance (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id TEXT NOT NULL REFERENCES students(student_id),
    day        TEXT NOT NULL,   -- YYYY-MM-DD
    time       TEXT NOT NULL,   -- HH:MM:SS
    distance   REAL,
    status     TEXT NOT NULL DEFAULT 'present',
    method     TEXT NOT NULL DEFAULT 'auto',
    marked_by  TEXT,
    note       TEXT NOT NULL DEFAULT '',
    session    TEXT NOT NULL DEFAULT '',   -- tên ca; '' = cả ngày
    UNIQUE (student_id, day, session)
);

CREATE TABLE IF NOT EXISTS audit_log (
    id     INTEGER PRIMARY KEY AUTOINCREMENT,
    ts     TEXT NOT NULL,      -- YYYY-MM-DD HH:MM:SS
    actor  TEXT,               -- tài khoản thao tác (NULL = hệ thống)
    kind   TEXT NOT NULL,
    detail TEXT NOT NULL DEFAULT ''
);

CREATE INDEX IF NOT EXISTS idx_samples_student ON face_samples(student_id);
CREATE INDEX IF NOT EXISTS idx_attendance_day ON attendance(day);
CREATE INDEX IF NOT EXISTS idx_audit_ts ON audit_log(ts);
"""

# Cột bổ sung cho cơ sở dữ liệu tạo bởi phiên bản cũ (thêm bằng ALTER TABLE
# để không mất dữ liệu đang có)
MIGRATIONS = (
    ("attendance", "status", "TEXT NOT NULL DEFAULT 'present'"),   # present | late
    ("attendance", "method", "TEXT NOT NULL DEFAULT 'auto'"),      # auto | manual
    ("attendance", "marked_by", "TEXT"),
    ("attendance", "note", "TEXT NOT NULL DEFAULT ''"),
    ("students", "consent_at", "TEXT"),
    ("face_samples", "model", "TEXT NOT NULL DEFAULT 'dlib'"),
)

STATUS_PRESENT = "present"
STATUS_LATE = "late"
METHOD_AUTO = "auto"
METHOD_MANUAL = "manual"


def parse_vn_date(text):
    """'30/09/2026' -> '2026-09-30'. Chuỗi rỗng -> None. Sai định dạng -> ValueError."""

    text = (text or "").strip()

    if not text:
        return None

    return datetime.datetime.strptime(text, "%d/%m/%Y").strftime("%Y-%m-%d")


def rate_label(rate):
    """Xếp loại chuyên cần theo tỉ lệ có mặt (%)."""

    if rate >= 90:
        return "Tốt"

    if rate >= 80:
        return "Khá"

    if rate >= 70:
        return "Trung bình"

    return "Cần nhắc nhở"


class Database:

    def __init__(self, path, cipher=None):

        self.path = path
        self.cipher = cipher            # secure.EmbeddingCipher hoặc None

        self.conn = sqlite3.connect(path)
        self.conn.execute("PRAGMA foreign_keys = ON")
        self.conn.execute("PRAGMA busy_timeout = 5000")

        self.conn.executescript(SCHEMA)
        self._migrate()
        self._migrate_sessions()
        self.conn.commit()

    def _migrate(self):
        """Thêm các cột mới vào bảng cũ nếu còn thiếu."""

        for table, column, ddl in MIGRATIONS:

            cols = {
                r[1] for r in
                self.conn.execute(f"PRAGMA table_info({table})")
            }

            if column not in cols:
                self.conn.execute(
                    f"ALTER TABLE {table} ADD COLUMN {column} {ddl}"
                )

    def _migrate_sessions(self):
        """Bảng attendance cũ chỉ cho 1 lượt/ngày; đổi sang 1 lượt/ca/ngày.

        SQLite không sửa được ràng buộc UNIQUE tại chỗ nên dựng lại bảng và
        chép dữ liệu sang (trong một giao dịch).
        """

        cols = {r[1] for r in self.conn.execute("PRAGMA table_info(attendance)")}

        if "session" in cols:
            return

        with self.conn:

            self.conn.executescript("""
                CREATE TABLE attendance_new (
                    id         INTEGER PRIMARY KEY AUTOINCREMENT,
                    student_id TEXT NOT NULL REFERENCES students(student_id),
                    day        TEXT NOT NULL,
                    time       TEXT NOT NULL,
                    distance   REAL,
                    status     TEXT NOT NULL DEFAULT 'present',
                    method     TEXT NOT NULL DEFAULT 'auto',
                    marked_by  TEXT,
                    note       TEXT NOT NULL DEFAULT '',
                    session    TEXT NOT NULL DEFAULT '',
                    UNIQUE (student_id, day, session)
                );
                INSERT INTO attendance_new
                    (id, student_id, day, time, distance, status, method,
                     marked_by, note, session)
                SELECT id, student_id, day, time, distance, status, method,
                       marked_by, note, ''
                FROM attendance;
                DROP TABLE attendance;
                ALTER TABLE attendance_new RENAME TO attendance;
                CREATE INDEX IF NOT EXISTS idx_attendance_day ON attendance(day);
            """)

    def close(self):

        try:
            self.conn.close()
        except sqlite3.Error:
            pass

    # -----------------------------------------------------
    # META
    # -----------------------------------------------------
    def get_meta(self, key):

        row = self.conn.execute(
            "SELECT value FROM meta WHERE key = ?",
            (key,)
        ).fetchone()

        return row[0] if row else None

    def set_meta(self, key, value):

        self.conn.execute(
            "INSERT OR REPLACE INTO meta(key, value) VALUES (?, ?)",
            (key, str(value))
        )
        self.conn.commit()

    # -----------------------------------------------------
    # TÀI KHOẢN
    # -----------------------------------------------------
    def user_exists(self, username):

        row = self.conn.execute(
            "SELECT 1 FROM users WHERE username = ?",
            (username,)
        ).fetchone()

        return row is not None

    def count_users(self):

        return self.conn.execute(
            "SELECT COUNT(*) FROM users"
        ).fetchone()[0]

    def create_user(self, username, password, role=None):
        """Tạo tài khoản. Tài khoản đầu tiên của hệ thống luôn là admin."""

        if self.user_exists(username):
            raise ValueError("Tên đăng nhập đã tồn tại")

        if role is None:
            role = ROLE_ADMIN if self.count_users() == 0 else ROLE_USER

        self.conn.execute(
            "INSERT INTO users(username, password_hash, role) VALUES (?, ?, ?)",
            (username, hash_password(password), role)
        )
        self.conn.commit()

        return role

    def set_password(self, username, new_password):
        """Đổi mật khẩu. Trả về True nếu có tài khoản đó."""

        with self.conn:
            cur = self.conn.execute(
                "UPDATE users SET password_hash = ? WHERE username = ?",
                (hash_password(new_password), username)
            )

        return cur.rowcount > 0

    def check_login(self, username, password):
        """Trả về (True, role) nếu đúng, ngược lại (False, lý do)."""

        row = self.conn.execute(
            "SELECT password_hash, role FROM users WHERE username = ?",
            (username,)
        ).fetchone()

        if row is None:
            return False, "not_found"

        if not verify_password(password, row[0]):
            return False, "wrong_password"

        return True, row[1]

    # -----------------------------------------------------
    # SINH VIÊN + KHUÔN MẶT
    # -----------------------------------------------------
    def get_student(self, student_id):

        row = self.conn.execute(
            "SELECT student_id, name, class_name, faculty, active "
            "FROM students WHERE student_id = ?",
            (student_id,)
        ).fetchone()

        if row is None:
            return None

        return {
            "student_id": row[0],
            "name": row[1],
            "class_name": row[2],
            "faculty": row[3],
            "active": bool(row[4])
        }

    def add_student(
        self, student_id, name, class_name, faculty, encodings,
        created_at=None, consent=False, model="dlib"
    ):
        """Đăng ký sinh viên cùng các mẫu khuôn mặt.

        Nếu mã đã tồn tại nhưng đã bị xóa mềm thì kích hoạt lại và thay mẫu mới.
        Nếu mã đang hoạt động thì báo lỗi.
        consent=True ghi lại thời điểm sinh viên đồng ý thu thập sinh trắc học.
        """

        if not encodings:
            raise ValueError("Cần ít nhất 1 mẫu khuôn mặt")

        existing = self.get_student(student_id)

        if existing is not None and existing["active"]:
            raise ValueError("Mã sinh viên đã tồn tại")

        now = created_at or datetime.datetime.now().isoformat(timespec="seconds")

        consent_at = (
            datetime.datetime.now().isoformat(timespec="seconds")
            if consent else None
        )

        with self.conn:

            if existing is None:
                self.conn.execute(
                    "INSERT INTO students"
                    "(student_id, name, class_name, faculty, active,"
                    " created_at, consent_at)"
                    " VALUES (?, ?, ?, ?, 1, ?, ?)",
                    (student_id, name, class_name, faculty, now, consent_at)
                )
            else:
                # Đăng ký lại sau khi xóa mềm: tính chuyên cần từ ngày đăng ký lại
                self.conn.execute(
                    "UPDATE students SET name = ?, class_name = ?, "
                    "faculty = ?, active = 1, created_at = ?, consent_at = ? "
                    "WHERE student_id = ?",
                    (name, class_name, faculty, now, consent_at, student_id)
                )

            self.conn.execute(
                "DELETE FROM face_samples WHERE student_id = ?",
                (student_id,)
            )

            self._insert_samples(student_id, encodings, model)

    def _pack(self, student_id, vector):
        """Vector -> bytes lưu trong CSDL (mã hóa nếu có cipher)."""

        raw = np.asarray(vector, dtype=np.float64).tobytes()

        if self.cipher is None:
            return raw

        return self.cipher.encrypt(raw, student_id.encode("utf-8"))

    def _unpack(self, student_id, blob):

        if secure.is_encrypted(blob):

            if self.cipher is None:
                raise secure.WrongKeyError(
                    "Cơ sở dữ liệu có vector khuôn mặt đã mã hóa nhưng chưa "
                    "có khóa. Đặt file data.key (và FACE_DB_PASSPHRASE nếu có) "
                    "đúng chỗ, hoặc bật encrypt_embeddings."
                )

            blob = self.cipher.decrypt(blob, student_id.encode("utf-8"))

        return np.frombuffer(blob, dtype=np.float64)

    def _insert_samples(self, student_id, encodings, model="dlib"):

        self.conn.executemany(
            "INSERT INTO face_samples(student_id, encoding, model) VALUES (?, ?, ?)",
            [
                (student_id, self._pack(student_id, e), model)
                for e in encodings
            ]
        )

    def encrypt_existing(self):
        """Mã hóa các vector còn ở dạng thường. Trả về số vector đã mã hóa."""

        if self.cipher is None:
            raise ValueError("Chưa có khóa mã hóa")

        rows = self.conn.execute(
            "SELECT id, student_id, encoding FROM face_samples"
        ).fetchall()

        n = 0

        with self.conn:

            for rid, sid, blob in rows:

                if secure.is_encrypted(blob):
                    continue

                self.conn.execute(
                    "UPDATE face_samples SET encoding = ? WHERE id = ?",
                    (self.cipher.encrypt(blob, sid.encode("utf-8")), rid)
                )

                n += 1

        return n

    def deactivate_student(self, student_id):
        """Xóa mềm: giữ lại lịch sử điểm danh, xóa dữ liệu khuôn mặt."""

        with self.conn:

            self.conn.execute(
                "UPDATE students SET active = 0 WHERE student_id = ?",
                (student_id,)
            )

            self.conn.execute(
                "DELETE FROM face_samples WHERE student_id = ?",
                (student_id,)
            )

    def list_students(self, active_only=True, model=None):
        """model=None: đếm mẫu của mọi mô hình; ngược lại chỉ đếm mẫu của model đó."""

        sql = (
            "SELECT s.student_id, s.name, s.class_name, s.faculty, "
            "(SELECT COUNT(*) FROM face_samples f "
            " WHERE f.student_id = s.student_id"
            + (" AND f.model = ?" if model else "") +
            ") FROM students s"
        )

        if active_only:
            sql += " WHERE s.active = 1"

        sql += " ORDER BY s.name COLLATE NOCASE, s.student_id"

        return [
            {
                "student_id": r[0],
                "name": r[1],
                "class_name": r[2],
                "faculty": r[3],
                "samples": r[4]
            }
            for r in self.conn.execute(sql, (model,) if model else ())
        ]

    def update_student(self, student_id, name, class_name, faculty):
        """Sửa thông tin (không đổi mã). Trả về True nếu có sinh viên đó."""

        with self.conn:
            cur = self.conn.execute(
                "UPDATE students SET name = ?, class_name = ?, faculty = ? "
                "WHERE student_id = ? AND active = 1",
                (name, class_name, faculty, student_id)
            )

        return cur.rowcount > 0

    def sample_count(self, student_id, model=None):

        if model:
            return self.conn.execute(
                "SELECT COUNT(*) FROM face_samples "
                "WHERE student_id = ? AND model = ?",
                (student_id, model)
            ).fetchone()[0]

        return self.conn.execute(
            "SELECT COUNT(*) FROM face_samples WHERE student_id = ?",
            (student_id,)
        ).fetchone()[0]

    def add_samples(self, student_id, encodings, max_samples=15, model="dlib"):
        """Thêm mẫu khuôn mặt; vượt giới hạn thì bỏ các mẫu cũ nhất."""

        student = self.get_student(student_id)

        if student is None or not student["active"]:
            raise ValueError("Sinh viên không tồn tại")

        with self.conn:

            self._insert_samples(student_id, encodings, model)

            self.conn.execute(
                "DELETE FROM face_samples WHERE student_id = ? AND model = ? "
                "AND id NOT IN "
                "(SELECT id FROM face_samples WHERE student_id = ? AND model = ? "
                " ORDER BY id DESC LIMIT ?)",
                (student_id, model, student_id, model, max_samples)
            )

    def load_face_index(self, model="dlib", dim=ENCODING_DIM):
        """Trả về (owner_ids, matrix) của các mẫu thuộc `model`, cho sinh viên
        đang hoạt động. owner_ids[i] là mã sinh viên của mẫu matrix[i].
        """

        rows = self.conn.execute(
            "SELECT f.student_id, f.encoding "
            "FROM face_samples f JOIN students s "
            "ON s.student_id = f.student_id "
            "WHERE s.active = 1 AND f.model = ? ORDER BY f.id",
            (model,)
        ).fetchall()

        owner_ids = [r[0] for r in rows]

        if not rows:
            return owner_ids, np.empty((0, dim))

        matrix = np.vstack(
            [self._unpack(r[0], r[1]) for r in rows]
        )

        return owner_ids, matrix

    # -----------------------------------------------------
    # ĐIỂM DANH
    # -----------------------------------------------------
    def mark_attendance(
        self, student_id, when=None, distance=None,
        status=STATUS_PRESENT, method=METHOD_AUTO, marked_by=None, note="",
        session=""
    ):
        """Ghi điểm danh. Trả về True nếu mới, False nếu hôm nay đã điểm danh.

        status : present | late
        method : auto (nhận diện khuôn mặt) | manual (giảng viên ghi tay)
        session: tên ca ('' = cả ngày). Mỗi sinh viên chỉ 1 lượt cho mỗi ca mỗi ngày.
        """

        when = when or datetime.datetime.now()

        try:
            with self.conn:
                self.conn.execute(
                    "INSERT INTO attendance"
                    "(student_id, day, time, distance, status, method,"
                    " marked_by, note, session)"
                    " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        student_id,
                        when.strftime("%Y-%m-%d"),
                        when.strftime("%H:%M:%S"),
                        None if distance is None else float(distance),
                        status,
                        method,
                        marked_by,
                        note or "",
                        session or ""
                    )
                )
            return True

        except sqlite3.IntegrityError:
            return False

    def remove_attendance(self, student_id, day, session=""):
        """Hủy một lượt điểm danh (ghi nhầm). Trả về True nếu có xóa."""

        with self.conn:
            cur = self.conn.execute(
                "DELETE FROM attendance "
                "WHERE student_id = ? AND day = ? AND session = ?",
                (student_id, day, session or "")
            )

        return cur.rowcount > 0

    def late_map(self):
        """{(student_id, slot)} các lượt đi muộn."""

        return {
            (r[0], slot_of(r[1], r[2]))
            for r in self.conn.execute(
                "SELECT student_id, day, session FROM attendance WHERE status = ?",
                (STATUS_LATE,)
            )
        }

    # -----------------------------------------------------
    # NHẬT KÝ HOẠT ĐỘNG (audit)
    # -----------------------------------------------------
    def log_event(self, kind, detail="", actor=None, when=None):
        """Ghi một sự kiện: đăng nhập, đăng ký/xóa SV, điểm danh tay, khuôn mặt lạ..."""

        when = when or datetime.datetime.now()

        try:
            with self.conn:
                self.conn.execute(
                    "INSERT INTO audit_log(ts, actor, kind, detail)"
                    " VALUES (?, ?, ?, ?)",
                    (
                        when.strftime("%Y-%m-%d %H:%M:%S"),
                        actor,
                        kind,
                        str(detail)[:500]
                    )
                )
        except sqlite3.Error:
            # Nhật ký hỏng không được làm hỏng nghiệp vụ chính
            log.exception("Không ghi được nhật ký")

    def recent_events(self, limit=100, kind=None):

        sql = "SELECT ts, actor, kind, detail FROM audit_log"
        args = []

        if kind:
            sql += " WHERE kind = ?"
            args.append(kind)

        sql += " ORDER BY id DESC LIMIT ?"
        args.append(limit)

        return [
            {"ts": r[0], "actor": r[1], "kind": r[2], "detail": r[3]}
            for r in self.conn.execute(sql, args)
        ]

    def prune_events(self, keep=5000):
        """Chỉ giữ `keep` dòng nhật ký mới nhất."""

        with self.conn:
            self.conn.execute(
                "DELETE FROM audit_log WHERE id NOT IN "
                "(SELECT id FROM audit_log ORDER BY id DESC LIMIT ?)",
                (keep,)
            )

    def attendance_days(self):
        """Các buổi (slot) từng có điểm danh, theo thứ tự thời gian."""

        return [
            slot_of(r[0], r[1]) for r in self.conn.execute(
                "SELECT day, session, MIN(time) FROM attendance "
                "GROUP BY day, session ORDER BY day, MIN(time)"
            )
        ]

    def attendance_map(self):
        """{(student_id, slot): time}"""

        return {
            (r[0], slot_of(r[1], r[3])): r[2]
            for r in self.conn.execute(
                "SELECT student_id, day, time, session FROM attendance"
            )
        }

    def attendance_on(self, day, session=None):
        """Điểm danh của một ngày (YYYY-MM-DD), theo giờ tăng dần.

        session=None: mọi ca trong ngày; ngược lại chỉ ca đó ('' = cả ngày).
        """

        sql = (
            "SELECT a.student_id, a.time, s.name, s.class_name,"
            " a.status, a.method, a.session "
            "FROM attendance a JOIN students s "
            "ON s.student_id = a.student_id "
            "WHERE a.day = ?"
        )
        args = [day]

        if session is not None:
            sql += " AND a.session = ?"
            args.append(session)

        sql += " ORDER BY a.time"

        return [
            {
                "student_id": r[0],
                "time": r[1],
                "name": r[2],
                "class_name": r[3],
                "status": r[4],
                "method": r[5],
                "session": r[6]
            }
            for r in self.conn.execute(sql, args)
        ]

    def apply_retention(self, days, today=None):
        """Xóa điểm danh cũ hơn `days` ngày (days <= 0: không làm gì).

        Trả về số lượt đã xóa. Ghi nhật ký để còn truy vết.
        """

        if days is None or days <= 0:
            return 0

        today = today or datetime.date.today()

        cutoff = (today - datetime.timedelta(days=days)).strftime("%Y-%m-%d")

        with self.conn:
            cur = self.conn.execute(
                "DELETE FROM attendance WHERE day < ?", (cutoff,)
            )

        if cur.rowcount:
            self.log_event(
                "retention_purge",
                f"Xóa {cur.rowcount} lượt điểm danh trước {cutoff} "
                f"(giữ {days} ngày)"
            )

        return cur.rowcount

    # -----------------------------------------------------
    # SAO LƯU
    # -----------------------------------------------------
    def backup(self, backup_dir, keep=7, today=None):
        """Mỗi ngày sao lưu một bản; chỉ giữ `keep` bản mới nhất."""

        os.makedirs(backup_dir, exist_ok=True)

        stamp = (today or datetime.date.today()).strftime("%Y%m%d")

        target = os.path.join(backup_dir, f"diemdanh_{stamp}.db")

        if not os.path.exists(target):

            dst = sqlite3.connect(target)

            try:
                self.conn.backup(dst)
                ok = dst.execute("PRAGMA integrity_check").fetchone()[0]
            finally:
                dst.close()

            # Bản sao hỏng thì xóa đi, không để nó đẩy bản tốt ra khỏi vòng xoay
            if ok != "ok":
                os.remove(target)
                raise sqlite3.DatabaseError(f"Bản sao lưu không toàn vẹn: {ok}")

        files = sorted(
            f for f in os.listdir(backup_dir)
            if f.startswith("diemdanh_") and f.endswith(".db")
        )

        for old in files[:-keep] if keep > 0 else []:
            try:
                os.remove(os.path.join(backup_dir, old))
            except OSError:
                pass

        return target

    # -----------------------------------------------------
    # XUẤT EXCEL
    # -----------------------------------------------------
    def _days_in_range(self, date_from=None, date_to=None):
        """Các ngày có điểm danh, lọc theo khoảng [date_from, date_to] (YYYY-MM-DD)."""

        return [
            d for d in self.attendance_days()
            if (date_from is None or split_slot(d)[0] >= date_from)
            and (date_to is None or split_slot(d)[0] <= date_to)
        ]

    def _enroll_days(self):
        """{student_id: ngày bắt đầu tính chuyên cần (YYYY-MM-DD)}.

        Sinh viên chỉ bị tính vắng từ ngày được đăng ký, không bị trừ oan cho
        các buổi trước đó. Nếu có điểm danh sớm hơn ngày đăng ký (dữ liệu
        nhập từ bản cũ) thì lấy ngày điểm danh đầu tiên.
        """

        first = {
            r[0]: r[1]
            for r in self.conn.execute(
                "SELECT student_id, MIN(day) FROM attendance GROUP BY student_id"
            )
        }

        out = {}

        for sid, created in self.conn.execute(
            "SELECT student_id, created_at FROM students"
        ):
            start = (created or "")[:10] or "0000-00-00"

            if sid in first and first[sid] < start:
                start = first[sid]

            out[sid] = start

        return out

    def statistics(self, date_from=None, date_to=None):
        """Thống kê chuyên cần trong khoảng ngày.

        "Buổi" = một ngày có ít nhất một lượt điểm danh. Mỗi sinh viên chỉ bị
        tính các buổi từ ngày đăng ký trở đi (xem _enroll_days).
        Trả về dict:
          days         : danh sách ngày (YYYY-MM-DD)
          per_student  : [{student_id, name, class_name, faculty, sessions,
                           present, late, absent, rate, absent_days}]
          per_day      : [{day, present, late, total, rate}]
          overall_rate : tỉ lệ chuyên cần trung bình toàn lớp (%)
        """

        students = self.list_students(active_only=True)
        days = self._days_in_range(date_from, date_to)
        marks = self.attendance_map()
        lates = self.late_map()
        enrolled = self._enroll_days()

        per_student = []

        for s in students:

            sid = s["student_id"]

            own_days = [
                d for d in days if split_slot(d)[0] >= enrolled.get(sid, "")
            ]

            absent_days = [d for d in own_days if (sid, d) not in marks]

            present = len(own_days) - len(absent_days)

            late = sum(1 for d in own_days if (sid, d) in lates)

            per_student.append(
                {
                    "student_id": sid,
                    "name": s["name"],
                    "class_name": s["class_name"],
                    "faculty": s["faculty"],
                    "sessions": len(own_days),
                    "present": present,
                    "late": late,
                    "absent": len(absent_days),
                    "rate": (
                        round(100 * present / len(own_days), 1)
                        if own_days else 0.0
                    ),
                    "absent_days": absent_days
                }
            )

        per_day = []

        for d in days:

            roster = [
                s["student_id"] for s in students
                if enrolled.get(s["student_id"], "") <= split_slot(d)[0]
            ]

            present = sum(1 for sid in roster if (sid, d) in marks)
            late = sum(1 for sid in roster if (sid, d) in lates)

            per_day.append(
                {
                    "day": d,
                    "present": present,
                    "late": late,
                    "total": len(roster),
                    "rate": (
                        round(100 * present / len(roster), 1)
                        if roster else 0.0
                    )
                }
            )

        counted = [p["rate"] for p in per_student if p["sessions"] > 0]

        overall = round(sum(counted) / len(counted), 1) if counted else 0.0

        return {
            "days": days,
            "per_student": per_student,
            "per_day": per_day,
            "overall_rate": overall
        }

    def export_excel(self, path, date_from=None, date_to=None):
        """Xuất báo cáo Excel gồm 3 sheet:

        - Diem Danh : mỗi buổi (ngày hoặc ca) một cột, vắng ghi "Vắng"
        - Tong Hop  : chuyên cần theo từng sinh viên
        - Theo Ngay : số người có mặt theo từng buổi

        Trả về (số sinh viên, số ngày).
        """

        from openpyxl import Workbook
        from openpyxl.styles import Alignment, Font, PatternFill
        from openpyxl.utils import get_column_letter

        st = self.statistics(date_from, date_to)
        students = st["per_student"]
        days = st["days"]
        marks = self.attendance_map()
        lates = self.late_map()
        enrolled = self._enroll_days()

        fmt = slot_label

        header_fill = PatternFill("solid", fgColor="1E3A8A")
        header_font = Font(bold=True, color="FFFFFF")
        center = Alignment(horizontal="center", vertical="center")

        def style_header(ws):
            for cell in ws[1]:
                cell.font = header_font
                cell.fill = header_fill
                cell.alignment = center

        def set_widths(ws, widths, default=14):
            for col in range(1, ws.max_column + 1):
                ws.column_dimensions[get_column_letter(col)].width = \
                    widths.get(col, default)

        wb = Workbook()

        # ---------- Sheet 1: ma trận điểm danh ----------
        ws = wb.active
        ws.title = "Diem Danh"

        fixed = ["Mã SV", "Họ và Tên", "Lớp", "Khoa"]

        ws.append(fixed + [fmt(d) for d in days] + ["Có mặt", "Tỉ lệ (%)"])

        absent_font = Font(color="B91C1C")
        late_font = Font(color="B45309")
        na_font = Font(color="9CA3AF")

        for s in students:

            row = [s["student_id"], s["name"], s["class_name"], s["faculty"]]

            for d in days:

                if split_slot(d)[0] < enrolled.get(s["student_id"], ""):
                    row.append("—")        # chưa đăng ký vào ngày đó
                else:
                    row.append(marks.get((s["student_id"], d)) or "Vắng")

            row += [s["present"], s["rate"]]

            ws.append(row)

            for col in range(len(fixed) + 1, len(fixed) + len(days) + 1):

                cell = ws.cell(row=ws.max_row, column=col)

                day = days[col - len(fixed) - 1]

                if cell.value == "Vắng":
                    cell.font = absent_font
                elif cell.value == "—":
                    cell.font = na_font
                elif (s["student_id"], day) in lates:
                    cell.font = late_font          # đi muộn: chữ cam

                cell.alignment = Alignment(horizontal="center")

        style_header(ws)
        set_widths(ws, {1: 14, 2: 28, 3: 14, 4: 26})
        ws.freeze_panes = "E2"

        # ---------- Sheet 2: tổng hợp theo sinh viên ----------
        ws2 = wb.create_sheet("Tong Hop")

        ws2.append(
            ["Mã SV", "Họ và Tên", "Lớp", "Khoa",
             "Số buổi", "Có mặt", "Vắng", "Tỉ lệ (%)", "Xếp loại", "Đi muộn"]
        )

        for s in students:

            ws2.append(
                [
                    s["student_id"], s["name"], s["class_name"], s["faculty"],
                    s["sessions"], s["present"], s["absent"], s["rate"],
                    rate_label(s["rate"]), s["late"]
                ]
            )

        ws2.append([])
        ws2.append(
            ["", "Chuyên cần trung bình toàn lớp", "", "", "", "", "",
             st["overall_rate"], "", ""]
        )

        style_header(ws2)
        set_widths(ws2, {1: 14, 2: 30, 3: 14, 4: 26, 9: 16})
        ws2.freeze_panes = "A2"

        # ---------- Sheet 3: theo ngày ----------
        ws3 = wb.create_sheet("Theo Ngay")

        ws3.append(["Ngày", "Có mặt", "Tổng sinh viên", "Tỉ lệ (%)", "Đi muộn"])

        for p in st["per_day"]:
            ws3.append(
                [fmt(p["day"]), p["present"], p["total"], p["rate"], p["late"]]
            )

        style_header(ws3)
        set_widths(ws3, {1: 16})

        # Chặn "công thức độc hại": openpyxl coi chuỗi bắt đầu bằng "=" là
        # công thức. Họ tên do người dùng nhập, nên ép mọi ô văn bản về chuỗi.
        for sheet in wb.worksheets:
            for row in sheet.iter_rows():
                for cell in row:
                    if cell.data_type == "f":
                        cell.data_type = "s"

        wb.save(path)

        return len(students), len(days)

    # -----------------------------------------------------
    # CHUYỂN DỮ LIỆU TỪ BẢN CŨ (pkl + xlsx)
    # -----------------------------------------------------
    def migrate_legacy(self, base_dir):
        """Nhập accounts.pkl, dataset.pkl, diemdanh.xlsx của phiên bản cũ.

        Chỉ chạy một lần (đánh dấu trong bảng meta). Không xóa file cũ.
        Trả về dict thống kê.
        """

        stats = {"users": 0, "students": 0, "attendance": 0}

        if self.get_meta("legacy_migrated"):
            return stats

        accounts_file = os.path.join(base_dir, "accounts.pkl")
        dataset_file = os.path.join(base_dir, "dataset.pkl")
        excel_file = os.path.join(base_dir, "diemdanh.xlsx")

        # ---- tài khoản ----
        accounts = _load_pickle(accounts_file)

        if isinstance(accounts, dict) and accounts:

            has_admin = any(
                str(u).lower().startswith("admin") for u in accounts
            )

            for i, (username, password) in enumerate(accounts.items()):

                if self.user_exists(username):
                    continue

                is_admin = (
                    str(username).lower().startswith("admin")
                    if has_admin else i == 0
                )

                self.create_user(
                    username,
                    str(password),
                    ROLE_ADMIN if is_admin else ROLE_USER
                )

                stats["users"] += 1

        # ---- sinh viên + khuôn mặt ----
        data = _load_pickle(dataset_file)

        key_to_id = {}

        if isinstance(data, dict):

            names = list(data.get("names", []))
            encs = list(data.get("encodings", []))
            n = min(len(names), len(encs))

            classes = (list(data.get("classes", [])) + [""] * n)[:n]
            faculties = (list(data.get("faculties", [])) + [""] * n)[:n]

            for i in range(n):

                student_id = f"SV{i + 1:03d}"

                while self.get_student(student_id) is not None:
                    student_id += "_"

                self.add_student(
                    student_id,
                    names[i],
                    classes[i] or "",
                    faculties[i] or "",
                    [encs[i]]
                )

                key_to_id[(names[i], classes[i] or "")] = student_id
                stats["students"] += 1

        # ---- lịch sử điểm danh trong Excel ----
        if os.path.exists(excel_file):

            try:
                stats["attendance"] = self._migrate_excel(
                    excel_file,
                    key_to_id
                )
            except Exception as e:
                log.warning("Không đọc được Excel cũ: %s", e)

        self.set_meta("legacy_migrated", "1")

        return stats

    def _migrate_excel(self, excel_file, key_to_id):

        from openpyxl import load_workbook

        year = datetime.datetime.fromtimestamp(
            os.path.getmtime(excel_file)
        ).year

        ws = load_workbook(excel_file).active

        header = [c.value for c in ws[1]]

        # Bản cũ: Họ và Tên | Lớp | Khoa | Buổi 1 ...
        has_class = len(header) > 1 and header[1] == "Lớp"
        first_time_col = 3 if has_class else 1

        count = 0
        next_id = len(key_to_id) + 1

        for row in ws.iter_rows(min_row=2, values_only=True):

            name = row[0]

            if not name:
                continue

            lop = (row[1] or "") if has_class else ""
            khoa = (row[2] or "") if has_class else ""

            sid = key_to_id.get((name, lop))

            if sid is None:
                # Có lịch sử nhưng không còn dữ liệu khuôn mặt -> lưu ở
                # trạng thái đã xóa mềm để không mất lịch sử
                sid = f"SV{next_id:03d}"
                next_id += 1

                now = datetime.datetime.now().isoformat(timespec="seconds")

                self.conn.execute(
                    "INSERT OR IGNORE INTO students"
                    "(student_id, name, class_name, faculty, active, created_at)"
                    " VALUES (?, ?, ?, ?, 0, ?)",
                    (sid, name, lop, khoa, now)
                )
                self.conn.commit()

                key_to_id[(name, lop)] = sid

            for value in row[first_time_col:]:

                if not value:
                    continue

                try:
                    when = datetime.datetime.strptime(
                        f"{value} {year}",
                        "%H:%M:%S %d/%m %Y"
                    )
                except ValueError:
                    continue

                if self.mark_attendance(sid, when):
                    count += 1

        return count


def _load_pickle(path):

    if not os.path.exists(path):
        return None

    try:
        with open(path, "rb") as f:
            return pickle.load(f)

    except Exception as e:
        log.warning("Không đọc được %s: %s", path, e)
        return None
