"""Logic điểm danh, tách hẳn khỏi giao diện để kiểm thử được.

Giao diện chỉ làm 3 việc:
  1. đưa kết quả nhận diện vào  engine.process(dets)
  2. đọc trạng thái để vẽ        engine.faces, engine.current_student, ...
  3. lấy thông báo cần hiện      for ev in engine.pop_events(): ...

Các sự kiện (tuple):
  ("status", kind, "Tiêu đề\\nMô tả")      kind: info | success | error
  ("attendance", student_id, name, class, "HH:MM:SS")
  ("capture_finished", ok, title, message)
"""

import datetime
import logging
import sqlite3
import time
from collections import deque


import re

import numpy as np

import backends
import recognizer
from db import (
    METHOD_AUTO, METHOD_MANUAL, STATUS_LATE, STATUS_PRESENT
)
from liveness import BlinkDetector, ChallengeLiveness
from recognizer import face_area
from tracker import Tracker

log = logging.getLogger(__name__)

CAPTURE_POSES = (
    "Nhìn thẳng vào camera",
    "Xoay nhẹ đầu sang trái",
    "Xoay nhẹ đầu sang phải",
    "Ngẩng đầu nhẹ",
    "Cúi đầu nhẹ",
)

# Tên ngắn của từng động tác, hiện cạnh tên người trên khung hình
CHALLENGE_SHORT = {
    "blink": "chớp mắt",
    "turn_left": "quay trái",
    "turn_right": "quay phải",
    "open_mouth": "há miệng",
}

STUDENT_ID_RE = re.compile(r"^[A-Za-z0-9_\-]{3,20}$")


def valid_student_id(sid):
    return bool(STUDENT_ID_RE.match(sid or ""))


def valid_name(name):
    name = (name or "").strip()
    return 0 < len(name) <= 100 and all(ord(c) >= 32 for c in name)


def parse_hhmm(text):
    """'07:30' -> số phút từ 0h (450). Rỗng hoặc sai định dạng -> None."""

    m = re.match(r"^\s*(\d{1,2}):(\d{2})\s*$", text or "")

    if not m:
        return None

    h, mi = int(m.group(1)), int(m.group(2))

    return h * 60 + mi if h < 24 and mi < 60 else None


def parse_timetable(text):
    """'Ca sáng|07:00|11:30;Ca chiều|13:00|17:00' -> [(tên, phút_bắt_đầu, phút_kết_thúc)].

    Mục sai định dạng bị bỏ qua (ghi cảnh báo) thay vì làm hỏng cả chương trình.
    """

    out = []

    for part in (text or "").split(";"):

        if not part.strip():
            continue

        bits = [b.strip() for b in part.split("|")]

        if len(bits) != 3:
            log.warning("timetable: bỏ qua mục sai định dạng %r", part)
            continue

        name, start, end = bits[0], parse_hhmm(bits[1]), parse_hhmm(bits[2])

        if not name or start is None or end is None or end <= start:
            log.warning("timetable: bỏ qua mục không hợp lệ %r", part)
            continue

        out.append((name, start, end))

    return sorted(out, key=lambda x: x[1])


class PersonState:
    """Mọi thứ cần nhớ riêng cho MỘT người đang đứng trước camera."""

    def __init__(self, cfg, stable=None, blink=None, challenge=None):

        self.stable = stable or recognizer.StableIdentity(
            cfg.confirm_window, cfg.confirm_votes
        )
        self.blink = blink or BlinkDetector()
        self.challenge = challenge or ChallengeLiveness(
            steps=cfg.challenge_steps,
            timeout=cfg.challenge_timeout,
            yaw_threshold=cfg.challenge_yaw,
            mar_threshold=cfg.challenge_mar
        )
        self.spoof = deque(maxlen=max(1, cfg.antispoof_frames))
        self.owner = None

    def reset_liveness(self):

        self.blink.reset()
        self.challenge.reset()
        self.spoof.clear()


# Tỉ lệ mẫu mới phải khớp với sinh viên đích khi "thêm mẫu mặt"
APPEND_MIN_MATCH_RATIO = 0.6


class Engine:

    def __init__(self, database, cfg, clock=time.time):

        self.db = database
        self.cfg = cfg
        self.clock = clock

        # Mô hình nhận diện đang dùng: vector của các mô hình khác nhau không so sánh được
        self.model = cfg.backend
        self.dim = 512 if cfg.backend == "arcface" else 128

        self.stable = recognizer.StableIdentity(
            cfg.confirm_window,
            cfg.confirm_votes
        )
        self.blink = BlinkDetector()

        # Chế độ thử thách ngẫu nhiên (chống video quay sẵn)
        self.challenge_mode = cfg.liveness_mode == "challenge"
        self.challenge = ChallengeLiveness(
            steps=cfg.challenge_steps,
            timeout=cfg.challenge_timeout,
            yaw_threshold=cfg.challenge_yaw,
            mar_threshold=cfg.challenge_mar
        )

        # Trạng thái của khuôn mặt chính (lớn nhất). Dùng chung các đối tượng ở trên.
        self._pstate = PersonState(
            cfg, stable=self.stable, blink=self.blink, challenge=self.challenge
        )

        # Nhiều người cùng lúc: mỗi khuôn mặt phụ có PersonState riêng
        self.tracker = Tracker(lambda: PersonState(cfg)) if cfg.max_faces > 1 else None

        # Thời khóa biểu (rỗng = cả ngày là một buổi)
        self._timetable = parse_timetable(cfg.timetable)
        self._session = ""

        # Giờ vào lớp (phút từ 0h) để xác định đi muộn; None = không tính
        self._class_start = parse_hhmm(cfg.class_start)

        # Tài khoản đang thao tác, ghi vào nhật ký (giao diện gán sau khi đăng nhập)
        self.actor = None

        # Theo dõi khuôn mặt lạ / thử thách thất bại để ghi nhật ký có giới hạn
        self._unknown_since = None
        self._last_unknown_log = float("-inf")
        self._live_fail_logged = set()

        # Có thể bật/tắt lúc chạy từ giao diện
        self.require_liveness = cfg.require_liveness
        self.auto_attendance = cfg.auto_attendance

        self.events = deque()

        self.capture = None
        self._capture_msg = None

        self._blink_owner = None
        self._hint = None

        self.reload()

    # =====================================================
    # DỮ LIỆU
    # =====================================================
    def reload(self):
        """Nạp lại sinh viên, mẫu khuôn mặt và danh sách đã điểm danh hôm nay."""

        self.students = {
            s["student_id"]: s
            for s in self.db.list_students()
        }

        self.face_owner_ids, self.face_matrix = self.db.load_face_index(
            self.model, self.dim
        )

        # Sinh viên chưa có mẫu của mô hình đang dùng (vd. vừa đổi dlib -> arcface):
        # họ không thể được nhận diện cho tới khi thu mẫu lại.
        self.unenrolled = [
            s["student_id"]
            for s in self.db.list_students(model=self.model)
            if s["samples"] == 0
        ]

        self.stable.reset()
        self._reset_liveness()
        self._blink_owner = None
        self._hint = None
        self._unknown_since = None
        self._live_fail_logged = set()

        if self.tracker is not None:
            self.tracker.reset()

        self.faces = []
        self.encodings = []
        self.current_student = None
        self.pending_student = None
        self.current_distance = None

        now = self.clock()

        self._day = self._day_of(now)
        self._session = self._session_at(now)
        self._load_marked()

    def _day_of(self, now):

        return datetime.datetime.fromtimestamp(now).strftime("%Y-%m-%d")

    def _session_at(self, now):
        """Tên ca đang diễn ra ('' nếu không dùng thời khóa biểu, None nếu ngoài giờ)."""

        if not self._timetable:
            return ""

        t = datetime.datetime.fromtimestamp(now)

        minutes = t.hour * 60 + t.minute + t.second / 60.0

        early = self.cfg.session_early_minutes

        for name, start, end in self._timetable:
            if start - early <= minutes <= end:
                return name

        return None

    def _session_start(self, name):

        for n, start, _end in self._timetable:
            if n == name:
                return start

        return None

    def _load_marked(self):

        if self._session is None:
            self.marked_today = set()
        else:
            self.marked_today = {
                r["student_id"]
                for r in self.db.attendance_on(self._day, self._session)
            }

    def _roll_day(self, now):
        """Cập nhật ngày/ca hiện tại; đổi ngày hoặc đổi ca thì nạp lại ai đã điểm danh."""

        day = self._day_of(now)
        session = self._session_at(now)

        if day != self._day:
            self._live_fail_logged = set()

        if day != self._day or session != self._session:

            self._day = day
            self._session = session
            self._load_marked()

    def today_log(self):
        """Điểm danh hôm nay (để hiện lại trong danh sách sau khi mở app)."""

        return self.db.attendance_on(self._day_of(self.clock()))

    # =====================================================
    # SỰ KIỆN
    # =====================================================
    def pop_events(self):

        out = list(self.events)

        self.events.clear()

        return out

    def _status(self, kind, text):

        self.events.append(("status", kind, text))

    def _hint_once(self, key, kind, text):
        # Một gợi ý chỉ hiện 1 lần cho tới khi tình huống thay đổi
        if self._hint != key:
            self._hint = key
            self._status(kind, text)

    # =====================================================
    # CHỚP MẮT
    # =====================================================
    def _reset_liveness(self):

        self._pstate.reset_liveness()

    def _spoof_ok(self, st):
        """Điểm "người thật" trung bình của mô hình chống giả mạo thụ động đạt ngưỡng?"""

        if not self.cfg.antispoof_enable:
            return True

        if len(st.spoof) < st.spoof.maxlen:
            return False

        return sum(st.spoof) / len(st.spoof) >= self.cfg.antispoof_threshold

    def _live_ok(self, st, now):

        if not self.require_liveness:
            return True

        if not self._spoof_ok(st):
            return False

        if self.challenge_mode:
            return st.challenge.recently_passed(now, self.cfg.liveness_window)

        return st.blink.recently_blinked(now, self.cfg.liveness_window)

    def liveness_ok(self, now=None):

        now = self.clock() if now is None else now

        return self._live_ok(self._pstate, now)

    def liveness_prompt(self, st=None):
        """Câu hướng dẫn hiện cho người đang đứng trước camera."""

        st = st or self._pstate

        if self.cfg.antispoof_enable and not self._spoof_ok(st):
            if len(st.spoof) < st.spoof.maxlen:
                return "Giữ yên khuôn mặt"

            return "Hãy dùng khuôn mặt thật, không dùng ảnh/màn hình"

        if self.challenge_mode:
            return st.challenge.prompt or "Giữ yên khuôn mặt"

        return "Hãy chớp mắt một lần"

    def _liveness_short(self, st=None):

        st = st or self._pstate

        if self.cfg.antispoof_enable and not self._spoof_ok(st):
            return "giữ yên"

        if self.challenge_mode:
            return CHALLENGE_SHORT.get(st.challenge.current, "giữ yên")

        return CHALLENGE_SHORT["blink"]

    def _live_update(self, st, face, cur, now):
        """Đưa số đo của một khuôn mặt vào bộ kiểm tra người thật của nó."""

        if face.get("spoof") is not None:
            st.spoof.append(face["spoof"])

            self._check_spoof_suspect(st, cur)

        if not self.challenge_mode:

            if face["ear"] is not None:
                st.blink.update(face["ear"], now)

            return

        # Thử thách chỉ bắt đầu khi đã biết là ai và người đó còn cần điểm danh
        if cur is None or cur in self.marked_today or not self.require_liveness:
            return

        ch = st.challenge

        if (
            ch.passed_at is not None
            and not ch.recently_passed(now, self.cfg.liveness_window)
        ):
            ch.reset()           # đã hết hiệu lực mà chưa điểm danh: làm lại

        before = ch.failures

        ch.update(now, face["ear"], face.get("mar"), face.get("yaw"))

        if ch.failures > before:
            self._on_challenge_failed(cur, ch.failures)

    def _check_spoof_suspect(self, st, cur):
        """Ghi nhật ký (một lần/ngày/người) khi điểm "người thật" thấp kéo dài."""

        if (
            cur is None
            or not self.cfg.antispoof_enable
            or len(st.spoof) < st.spoof.maxlen
        ):
            return

        mean = sum(st.spoof) / len(st.spoof)

        key = (self._day, cur, "spoof")

        if mean < self.cfg.antispoof_threshold and key not in self._live_fail_logged:

            self._live_fail_logged.add(key)

            self.db.log_event(
                "spoof_suspect",
                f"{cur}: điểm người thật {mean:.2f} < {self.cfg.antispoof_threshold}",
                self.actor
            )

    def _on_challenge_failed(self, sid, failures):

        key = (self._day, sid)

        if failures >= 2 and key not in self._live_fail_logged:

            self._live_fail_logged.add(key)

            self.db.log_event(
                "liveness_failed",
                f"{sid} không hoàn thành thử thách ({failures} lần liên tiếp)",
                self.actor
            )

    def process(self, dets):
        """Xử lý một lần nhận diện: dets = [{"loc","enc","ear"}, ...]."""

        now = self.clock()

        self._roll_day(now)

        threshold, margin = backends.thresholds_for(self.cfg)

        faces = []

        for d in dets:

            sid, dist = recognizer.match_face(
                self.face_matrix,
                self.face_owner_ids,
                d["enc"],
                threshold,
                margin
            )

            faces.append(
                {
                    "loc": d["loc"],
                    "enc": d["enc"],
                    "ear": d.get("ear"),
                    "mar": d.get("mar"),
                    "yaw": d.get("yaw"),
                    "spoof": d.get("spoof"),
                    "quality": d.get("quality"),
                    "sid": sid,
                    "dist": dist,
                    "label": "",
                    "known": False
                }
            )

        self.encodings = [f["enc"] for f in faces]

        if not faces:

            self.stable.reset()
            self._reset_liveness()
            self._blink_owner = None
            self._hint = None
            self._unknown_since = None

            if self.tracker is not None:
                self.tracker.update([], now)

            self.current_student = None
            self.pending_student = None
            self.current_distance = None
            self.faces = []

            self._handle_capture(now)

            return

        # Người chính là khuôn mặt lớn nhất trong khung hình
        primary = max(faces, key=lambda f: face_area(f["loc"]))

        confirmed = self.stable.add(primary["sid"])

        # Chỉ tin kết quả đã xác nhận khi khuôn mặt hiện tại cũng khớp,
        # tránh điểm danh nhầm lúc có người khác bước vào thay
        if confirmed is not None and primary["sid"] == confirmed:
            cur = confirmed
        else:
            cur = None

        self.current_student = cur
        self.pending_student = None if cur else primary["sid"]
        self.current_distance = primary["dist"]

        if cur is not None:

            if self._blink_owner is not None and self._blink_owner != cur:
                self._reset_liveness()

            self._blink_owner = cur

        self._live_update(self._pstate, primary, cur, now)

        self._track_unknown(primary, now)

        self._label_faces(faces, primary, cur, now)

        self.faces = faces

        self._handle_capture(now)

        if (
            self.capture is None
            and self.auto_attendance
            and cur is not None
        ):
            self._auto_attendance(cur, now)

        if self.tracker is not None:
            self._process_others(faces, primary, now)

    def _process_others(self, faces, primary, now):
        """Điểm danh các khuôn mặt PHỤ (không phải lớn nhất), mỗi người một trạng thái.

        Chỉ khi cfg.max_faces > 1, không đang đăng ký, và đang trong ca điểm danh.
        """

        tracks = self.tracker.update([f["loc"] for f in faces], now)

        if self.capture is not None:
            return

        ranked = sorted(
            range(len(faces)),
            key=lambda i: face_area(faces[i]["loc"]),
            reverse=True
        )[: self.cfg.max_faces]

        for i in ranked:

            f = faces[i]

            if f is primary:
                continue

            st = tracks[i].state

            confirmed = st.stable.add(f["sid"])

            cur = confirmed if (confirmed is not None and f["sid"] == confirmed) else None

            if cur is None:
                f["label"] = "Đang xác nhận…" if f["sid"] is not None else "Chưa đăng ký"
                continue

            if st.owner is not None and st.owner != cur:
                st.reset_liveness()

            st.owner = cur

            self._live_update(st, f, cur, now)

            student = self.students.get(cur)

            f["known"] = True
            f["label"] = student["name"] if student else cur

            if cur in self.marked_today or not self.auto_attendance:
                continue

            if self._session is None:
                continue

            if self._live_ok(st, now):
                self._mark(cur, now, f["dist"])
            else:
                f["label"] += " · " + self._liveness_short(st)

    def _track_unknown(self, primary, now):
        """Ghi nhật ký khi có người lạ đứng trước camera (giới hạn tần suất)."""

        unknown = (
            primary["sid"] is None
            and self.capture is None
            and len(self.face_owner_ids) > 0
        )

        if not unknown:
            self._unknown_since = None
            return

        if self._unknown_since is None:
            self._unknown_since = now
            return

        if (
            now - self._unknown_since >= 3.0
            and now - self._last_unknown_log >= self.cfg.unknown_log_seconds
        ):

            self._last_unknown_log = now

            d = primary["dist"]

            self.db.log_event(
                "unknown_face",
                "Khuôn mặt không khớp ai"
                + ("" if d is None else f" (khoảng cách gần nhất {d:.3f})"),
                self.actor
            )

    def _label_faces(self, faces, primary, cur, now):

        for f in faces:

            student = self.students.get(f["sid"])

            if f is primary:

                if cur is not None and student:

                    f["known"] = True
                    f["label"] = student["name"]

                    if (
                        cur not in self.marked_today
                        and not self.liveness_ok(now)
                    ):
                        f["label"] += " · " + self._liveness_short()

                elif f["sid"] is not None:
                    f["label"] = "Đang xác nhận…"

                else:
                    f["label"] = "Chưa đăng ký"

            else:

                if student:
                    f["known"] = True
                    f["label"] = student["name"]
                else:
                    f["label"] = "Chưa đăng ký"

    # =====================================================
    # ĐIỂM DANH
    # =====================================================
    def _outside_hours(self):

        self._hint_once(
            ("outside",),
            "info",
            "Ngoài giờ điểm danh\nChưa đến (hoặc đã hết) ca học"
        )

    def _auto_attendance(self, sid, now):

        if sid in self.marked_today:
            return

        if self._session is None:
            self._outside_hours()
            return

        if not self.liveness_ok(now):

            self._hint_once(
                (sid, "live", self.liveness_prompt()),
                "info",
                "Xác nhận người thật\n" + self.liveness_prompt()
            )

            return

        self._mark(sid, now)

    def manual_attendance(self):
        """Người dùng bấm nút Điểm danh."""

        now = self.clock()

        if self.capture is not None:

            self._status(
                "info",
                "Đang đăng ký\nHoàn tất thu mẫu trước"
            )

            return

        if not self.faces:

            self._status("error", "Không thấy ai\ntrong camera!")

            return

        if self._session is None:

            self._status(
                "info",
                "Ngoài giờ điểm danh\nChưa đến (hoặc đã hết) ca học"
            )

            return

        sid = self.current_student

        if sid is None:

            if self.pending_student is not None:
                self._status(
                    "info",
                    "Đang xác nhận\nGiữ yên khuôn mặt thêm 1 giây"
                )
            else:
                self._status(
                    "error",
                    "Thất bại:\nKhuôn mặt chưa đăng ký!"
                )

            return

        if sid in self.marked_today:

            self._status(
                "info",
                f"{self.students[sid]['name']}\nđã điểm danh hôm nay rồi!"
            )

            return

        if not self.liveness_ok(now):

            self._status(
                "info",
                "Xác nhận người thật\n"
                + self.liveness_prompt() + ", rồi bấm lại"
            )

            return

        self._mark(sid, now)

    def _mark(self, sid, now, distance=None):

        student = self.students[sid]

        if distance is None:
            distance = self.current_distance

        when = datetime.datetime.fromtimestamp(now)

        status = self._attendance_status(when)

        try:
            inserted = self.db.mark_attendance(
                sid,
                when,
                distance,
                status=status,
                method=METHOD_AUTO,
                marked_by=self.actor,
                session=self._session or ""
            )

        except sqlite3.Error as e:

            log.exception("Không ghi được điểm danh")

            self._status(
                "error",
                f"Lỗi cơ sở dữ liệu\n{e}"
            )

            return

        self.marked_today.add(sid)

        if inserted:

            self.events.append(
                (
                    "attendance",
                    sid,
                    student["name"],
                    student["class_name"],
                    when.strftime("%H:%M:%S")
                )
            )

            self._status(
                "success",
                f"Điểm danh thành công:\n{student['name']}"
                + (" (đi muộn)" if status == STATUS_LATE else "")
            )

        else:

            self._status(
                "info",
                f"{student['name']}\nđã điểm danh hôm nay rồi!"
            )

    def _attendance_status(self, when):
        """present hoặc late, theo giờ vào lớp trong cấu hình."""

        start = self._class_start

        if self._timetable:
            start = self._session_start(self._session)

        if start is None:
            return STATUS_PRESENT

        minutes = when.hour * 60 + when.minute + when.second / 60.0

        if minutes > start + self.cfg.late_after_minutes:
            return STATUS_LATE

        return STATUS_PRESENT

    # =====================================================
    # ĐIỂM DANH THỦ CÔNG (dự phòng, có ghi nhật ký)
    # =====================================================
    def mark_manual(self, sid, note=""):
        """Giảng viên ghi có mặt khi nhận diện không dùng được (đeo khẩu trang,
        camera hỏng...). Mọi lượt đều lưu người ghi + lý do. None nếu thành công."""

        student = self.students.get(sid)

        if student is None:
            return "Không tìm thấy sinh viên này."

        if not (note or "").strip():
            return "Cần nhập lý do khi điểm danh thủ công."

        now = self.clock()

        self._roll_day(now)

        if self._session is None:
            return "Đang ngoài giờ các ca học, không thể điểm danh."

        if sid in self.marked_today:
            return f"{student['name']} đã điểm danh hôm nay rồi."

        when = datetime.datetime.fromtimestamp(now)

        try:
            inserted = self.db.mark_attendance(
                sid,
                when,
                None,
                status=self._attendance_status(when),
                method=METHOD_MANUAL,
                marked_by=self.actor,
                note=note.strip(),
                session=self._session or ""
            )
        except sqlite3.Error as e:
            log.exception("Không ghi được điểm danh thủ công")
            return f"Lỗi cơ sở dữ liệu: {e}"

        self.marked_today.add(sid)

        if not inserted:
            return f"{student['name']} đã điểm danh hôm nay rồi."

        self.db.log_event(
            "attendance_manual",
            f"{sid} {student['name']}: {note.strip()}",
            self.actor
        )

        self.events.append(
            (
                "attendance",
                sid,
                student["name"],
                student["class_name"],
                when.strftime("%H:%M:%S")
            )
        )

        self._status(
            "success",
            f"Điểm danh thủ công:\n{student['name']}"
        )

        return None

    def unmark_today(self, sid):
        """Hủy lượt điểm danh hôm nay của sinh viên (ghi nhầm). None nếu thành công."""

        now = self.clock()

        self._roll_day(now)

        student = self.students.get(sid)

        name = student["name"] if student else sid

        if self._session is None:
            return "Đang ngoài giờ các ca học."

        if not self.db.remove_attendance(sid, self._day, self._session):
            return f"{name} chưa điểm danh hôm nay."

        self.marked_today.discard(sid)

        self.db.log_event(
            "attendance_removed",
            f"{sid} {name} ngày {self._day}",
            self.actor
        )

        self._status("info", f"Đã hủy điểm danh:\n{name}")

        return None

    # =====================================================
    # QUẢN LÝ SINH VIÊN
    # =====================================================
    def update_student(self, sid, name, lop, khoa):

        ok = self.db.update_student(sid, name, lop, khoa)

        if ok:
            self.db.log_event("student_updated", sid, self.actor)

        self.reload()

        return ok

    def delete_student(self, sid):

        self.db.deactivate_student(sid)

        self.db.log_event("student_deleted", sid, self.actor)

        self.reload()

    # =====================================================
    # ĐĂNG KÝ / THÊM MẪU MẶT
    # =====================================================
    def check_can_capture(self):
        """Trả về None nếu có thể thu mẫu, ngược lại là lý do (chuỗi)."""

        if self.capture is not None:
            return "Đang thu mẫu, hãy hoàn tất hoặc hủy trước."

        if len(self.encodings) == 0:
            return (
                "Không tìm thấy khuôn mặt nào!\n"
                "Vui lòng nhìn thẳng vào camera."
            )

        if len(self.encodings) > 1:
            return (
                "Có nhiều hơn 1 người trong camera!\n"
                "Vui lòng chỉ để 1 người."
            )

        return None

    def check_can_register(self):

        err = self.check_can_capture()

        if err:
            return err

        if self.current_student is not None:

            s = self.students[self.current_student]

            return (
                "Khuôn mặt này đã được đăng ký:\n"
                f"{s['name']} - {s['student_id']} - {s['class_name']}"
            )

        return None

    def start_register(self, sid, name, lop, khoa, consent=False):
        """Bắt đầu thu mẫu cho sinh viên mới. Trả về None hoặc lỗi (chuỗi).

        consent=True: sinh viên đã đồng ý cho thu thập dữ liệu sinh trắc học
        (thời điểm đồng ý được lưu cùng hồ sơ).
        """

        err = self.check_can_register()

        if err:
            return err

        if not valid_student_id(sid):
            return (
                "Mã sinh viên chỉ gồm chữ, số, '-' hoặc '_' "
                "(từ 3 đến 20 ký tự)."
            )

        if not valid_name(name):
            return "Họ tên không hợp lệ (tối đa 100 ký tự, không có ký tự điều khiển)."

        existing = self.db.get_student(sid)

        if existing is not None and existing["active"]:
            return f"Mã {sid} đã thuộc về {existing['name']}!"

        self._begin_capture(
            "new",
            (sid, name, lop, khoa),
            self.cfg.samples_per_person,
            consent
        )

        return None

    def start_add_samples(self, sid):
        """Bắt đầu thu thêm mẫu cho sinh viên đã có."""

        err = self.check_can_capture()

        if err:
            return err

        student = self.students.get(sid)

        if student is None:
            return "Không tìm thấy sinh viên này."

        room = self.cfg.max_samples - self.db.sample_count(sid, self.model)

        if room <= 0:
            return (
                f"{student['name']} đã đủ {self.cfg.max_samples} mẫu, "
                "không cần thêm."
            )

        self._begin_capture(
            "append",
            (
                sid,
                student["name"],
                student["class_name"],
                student["faculty"]
            ),
            min(self.cfg.samples_per_person, room)
        )

        return None

    # -----------------------------------------------------
    # ĐĂNG KÝ BẰNG ẢNH TẢI LÊN (không cần camera)
    # -----------------------------------------------------
    MIN_UPLOAD_SAMPLES = 1

    def _prepare_upload(self, paths, encode_fn):
        """Mã hóa các ảnh, loại ảnh xấu và ảnh nghi là NGƯỜI KHÁC.

        Trả về (samples, notes). Ảnh nào bị loại đều có dòng giải thích.
        """

        notes, good = [], []

        for path in paths:

            name = path.replace("\\", "/").rsplit("/", 1)[-1]

            try:
                r = encode_fn(path)
            except Exception as e:
                log.exception("Lỗi khi mã hóa ảnh")
                notes.append(f"{name}: lỗi xử lý ({e})")
                continue

            if r["enc"] is None:
                notes.append(f"{name}: {r['problem']}")
                continue

            why = self._quality_problem(r.get("quality"))

            if why:
                notes.append(f"{name}: {why}")
                continue

            good.append((name, r["enc"]))

        thr = backends.thresholds_for(self.cfg)[0]

        # Các ảnh của CÙNG một người phải giống nhau; ảnh lạc sang người khác
        # (nhầm thư mục, nhầm ảnh) bị loại thay vì làm hỏng hồ sơ.
        if len(good) >= 2:

            vecs = np.vstack([e for _, e in good])
            dist = np.linalg.norm(vecs[:, None, :] - vecs[None, :, :], axis=2)
            np.fill_diagonal(dist, np.inf)

            if len(good) == 2:
                keep = [0, 1] if dist[0, 1] <= thr else []
            else:
                # chấp nhận ảnh nếu giống ít nhất một nửa các ảnh còn lại
                need = max(1, (len(good) - 1) // 2)
                keep = [
                    i for i in range(len(good))
                    if int((dist[i] <= thr).sum()) >= need
                ]

            for i, (name, _) in enumerate(good):
                if i not in keep:
                    notes.append(f"{name}: không giống các ảnh còn lại (nghi là người khác)")

            good = [good[i] for i in keep]

        return [e for _, e in good], notes

    def enroll_from_images(self, sid, name, lop, khoa, paths, encode_fn, consent=False):
        """Đăng ký người mới từ ảnh. Trả về (lỗi hoặc None, ghi chú)."""

        if self.capture is not None:
            return "Đang thu mẫu bằng camera, hãy hoàn tất hoặc hủy trước.", []

        if not valid_student_id(sid):
            return (
                "Mã sinh viên chỉ gồm chữ, số, '-' hoặc '_' "
                "(từ 3 đến 20 ký tự)."
            ), []

        if not valid_name(name):
            return "Họ tên không hợp lệ (tối đa 100 ký tự, không có ký tự điều khiển).", []

        existing = self.db.get_student(sid)

        if existing is not None and existing["active"]:
            return f"Mã {sid} đã thuộc về {existing['name']}!", []

        samples, notes = self._prepare_upload(paths, encode_fn)

        samples = samples[: self.cfg.max_samples]

        if len(samples) < self.MIN_UPLOAD_SAMPLES:
            return (
                f"Chỉ có {len(samples)} ảnh dùng được, cần ít nhất "
                f"{self.MIN_UPLOAD_SAMPLES}."
            ), notes

        if len(samples) < 3:
            notes.append(
                f"Lưu ý: mới có {len(samples)} mẫu nên nhận diện sẽ kém ổn định. "
                "Hãy dùng 'Thêm mẫu mặt' (camera) hoặc 'Thêm mẫu từ ảnh' để bổ sung."
            )

        self._finish_new(sid, name, lop, khoa, samples, consent)

        if self.events and self.events[-1][0] == "capture_finished" and self.events[-1][1]:
            self.db.log_event(
                "enroll_from_images", f"{sid} ({len(samples)} ảnh)", self.actor
            )

        return None, notes

    def add_samples_from_images(self, sid, paths, encode_fn):
        """Thêm mẫu cho người đã có từ ảnh. Trả về (lỗi hoặc None, ghi chú)."""

        if self.capture is not None:
            return "Đang thu mẫu bằng camera, hãy hoàn tất hoặc hủy trước.", []

        student = self.students.get(sid)

        if student is None:
            return "Không tìm thấy sinh viên này.", []

        room = self.cfg.max_samples - self.db.sample_count(sid, self.model)

        if room <= 0:
            return f"{student['name']} đã đủ {self.cfg.max_samples} mẫu.", []

        samples, notes = self._prepare_upload(paths, encode_fn)

        samples = samples[:room]

        if not samples:
            return "Không có ảnh nào dùng được.", notes

        self._finish_append(sid, student["name"], samples)

        if self.events and self.events[-1][0] == "capture_finished" and self.events[-1][1]:
            self.db.log_event(
                "add_samples_from_images", f"{sid} ({len(samples)} ảnh)", self.actor
            )

        return None, notes

    def _begin_capture(self, mode, info, total, consent=False):

        self.capture = {
            "mode": mode,
            "info": info,
            "total": total,
            "consent": consent,
            "samples": [],
            "last": 0.0,
            "started": self.clock()
        }

        self._capture_msg = None

        self._status(
            "info",
            f"Đang thu mẫu 0/{total}\n{CAPTURE_POSES[0]}"
        )

    def cancel_capture(self, message="Đã hủy đăng ký"):

        if self.capture is None:
            return

        self.capture = None
        self._capture_msg = None

        self._status("error", message)

    def _capture_status(self, text):
        # Chỉ báo khi nội dung đổi, tránh làm lại bộ đếm mỗi lần nhận diện
        if text != self._capture_msg:

            self._capture_msg = text

            self._status("info", text)

    def _handle_capture(self, now):

        cap = self.capture

        if cap is None:
            return

        if now - cap["started"] > self.cfg.capture_timeout:

            self.cancel_capture("Hết thời gian đăng ký")

            return

        total = cap["total"]
        done = len(cap["samples"])

        if len(self.faces) != 1:

            self._capture_status(
                f"Đang thu mẫu {done}/{total}\n"
                "Chỉ để 1 người trong khung hình"
            )

            return

        face = self.faces[0]

        top, right, bottom, left = face["loc"]

        if right - left < self.cfg.min_face_width:

            self._capture_status(
                f"Đang thu mẫu {done}/{total}\n"
                "Hãy lại gần camera hơn"
            )

            return

        problem = self._quality_problem(face.get("quality"))

        if problem:

            self._capture_status(
                f"Đang thu mẫu {done}/{total}\n{problem}"
            )

            return

        if now - cap["last"] < self.cfg.capture_interval:
            return

        cap["samples"].append(face["enc"])
        cap["last"] = now

        done = len(cap["samples"])

        if done >= total:

            self._finish_capture()

            return

        self._capture_status(
            f"Đã thu {done}/{total}\n"
            f"Tiếp theo: {CAPTURE_POSES[done % len(CAPTURE_POSES)]}"
        )

    def _quality_problem(self, q):
        """Lý do ảnh không đủ tốt để làm mẫu (None nếu đạt hoặc không đo được).

        Mẫu mờ/tối/ngược sáng làm sai lệch cả quá trình nhận diện sau này nên
        phải loại ngay lúc đăng ký.
        """

        if not q:
            return None

        cfg = self.cfg

        bright = q.get("bright")
        sharp = q.get("sharp")

        if bright is not None and bright < cfg.min_brightness:
            return "Ánh sáng quá tối, hãy ra nơi sáng hơn"

        if bright is not None and bright > cfg.max_brightness:
            return "Ánh sáng quá chói hoặc ngược sáng"

        if sharp is not None and sharp < cfg.min_sharpness:
            return "Ảnh bị mờ, hãy giữ yên khuôn mặt"

        return None

    def _finish_capture(self):

        cap = self.capture

        self.capture = None
        self._capture_msg = None

        sid, name, lop, khoa = cap["info"]
        samples = cap["samples"]

        if cap["mode"] == "new":
            self._finish_new(
                sid, name, lop, khoa, samples, cap.get("consent", False)
            )
        else:
            self._finish_append(sid, name, samples)

    def _reject(self, title, message, status):

        self.events.append(("capture_finished", False, title, message))

        self._status("error", status)

    def _finish_new(self, sid, name, lop, khoa, samples, consent=False):

        # Chặn đăng ký trùng một người đã có (kể cả dưới tên/mã khác)
        for enc in samples:

            other, _ = recognizer.match_face(
                self.face_matrix,
                self.face_owner_ids,
                enc,
                *backends.thresholds_for(self.cfg)
            )

            if other is not None:

                s = self.students.get(other)

                who = f"{s['name']} ({other})" if s else other

                self._reject(
                    "Đã đăng ký",
                    f"Khuôn mặt này giống với {who}.\n"
                    "Không thể đăng ký thêm một lần nữa.",
                    "Đăng ký bị từ chối\nTrùng khuôn mặt"
                )

                return

        try:
            self.db.add_student(
                sid, name, lop, khoa, samples, consent=consent,
                model=self.model
            )

        except (ValueError, sqlite3.Error) as e:

            log.exception("Không lưu được sinh viên")

            self._reject(
                "Lỗi",
                f"Không lưu được: {e}",
                "Đăng ký thất bại"
            )

            return

        self.db.log_event(
            "student_registered",
            f"{sid} {name} ({len(samples)} mẫu)",
            self.actor
        )

        self.reload()

        self.events.append(
            (
                "capture_finished",
                True,
                "Thành công",
                "Đã đăng ký thành công!\n\n"
                f"{name}\nMã SV: {sid}\nLớp: {lop}\nKhoa: {khoa}\n"
                f"Số mẫu khuôn mặt: {len(samples)}"
            )
        )

        self._status("success", f"Đăng ký thành công:\n{name}")

    def _finish_append(self, sid, name, samples):

        # Mẫu mới phải thật sự là của người đó, tránh gắn nhầm khuôn mặt
        ok = 0

        for enc in samples:

            d = recognizer.distance_to_student(
                self.face_matrix,
                self.face_owner_ids,
                enc,
                sid
            )

            if d is not None and d <= backends.thresholds_for(self.cfg)[0]:
                ok += 1

        # Sinh viên chưa có mẫu của mô hình hiện tại (vừa đổi mô hình nhận diện):
        # không có gì để đối chiếu, chỉ cần các mẫu không trùng ai khác
        reenroll = self.db.sample_count(sid, self.model) == 0

        if reenroll:

            for enc in samples:

                other, _ = recognizer.match_face(
                    self.face_matrix,
                    self.face_owner_ids,
                    enc,
                    *backends.thresholds_for(self.cfg)
                )

                if other is not None and other != sid:

                    self._reject(
                        "Trùng khuôn mặt",
                        f"Khuôn mặt này đã thuộc về {other}.",
                        "Thêm mẫu bị từ chối\nTrùng người khác"
                    )

                    return

            ok = len(samples)

        if ok < APPEND_MIN_MATCH_RATIO * len(samples):

            self._reject(
                "Không khớp",
                f"Khuôn mặt trong camera không khớp với {name}.\n"
                "Mẫu mới không được lưu.",
                "Thêm mẫu bị từ chối\nKhông khớp người"
            )

            return

        try:
            self.db.add_samples(
                sid, samples, self.cfg.max_samples, model=self.model
            )

        except (ValueError, sqlite3.Error) as e:

            log.exception("Không lưu được mẫu mặt")

            self._reject("Lỗi", f"Không lưu được: {e}", "Thêm mẫu thất bại")

            return

        self.db.log_event(
            "samples_added",
            f"{sid} {name} (+{len(samples)} mẫu)",
            self.actor
        )

        self.reload()

        total = self.db.sample_count(sid, self.model)

        self.events.append(
            (
                "capture_finished",
                True,
                "Thành công",
                f"Đã thêm {len(samples)} mẫu cho {name}.\n"
                f"Tổng số mẫu hiện có: {total}"
            )
        )

        self._status("success", f"Đã thêm mẫu:\n{name}")