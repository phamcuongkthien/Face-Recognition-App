"""Băm mật khẩu và chống dò mật khẩu."""

import hashlib
import hmac
import secrets
import time

PBKDF2_ITERATIONS = 200_000


def hash_password(password, iterations=PBKDF2_ITERATIONS):
    """Trả về chuỗi 'pbkdf2$iterations$salt_hex$hash_hex'."""

    salt = secrets.token_bytes(16)

    digest = hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        salt,
        iterations
    )

    return f"pbkdf2${iterations}${salt.hex()}${digest.hex()}"


def verify_password(password, stored):

    try:
        scheme, iterations, salt_hex, hash_hex = stored.split("$")

        if scheme != "pbkdf2":
            return False

        digest = hashlib.pbkdf2_hmac(
            "sha256",
            password.encode("utf-8"),
            bytes.fromhex(salt_hex),
            int(iterations)
        )

        return hmac.compare_digest(digest.hex(), hash_hex)

    except (ValueError, TypeError):
        return False


class LoginThrottle:
    """Khóa tạm một tên đăng nhập sau nhiều lần sai liên tiếp."""

    def __init__(self, max_attempts=5, lock_seconds=30, clock=time.monotonic):

        self.max_attempts = max_attempts
        self.lock_seconds = lock_seconds
        self.clock = clock

        self._fails = {}
        self._locked_until = {}

    def seconds_locked(self, username):
        """Số giây còn bị khóa (0 nếu không bị khóa)."""

        until = self._locked_until.get(username)

        if until is None:
            return 0

        remain = until - self.clock()

        if remain <= 0:
            self._locked_until.pop(username, None)
            self._fails.pop(username, None)
            return 0

        return int(remain) + 1

    def failure(self, username):

        n = self._fails.get(username, 0) + 1
        self._fails[username] = n

        if n >= self.max_attempts:
            self._locked_until[username] = self.clock() + self.lock_seconds

    def success(self, username):

        self._fails.pop(username, None)
        self._locked_until.pop(username, None)
