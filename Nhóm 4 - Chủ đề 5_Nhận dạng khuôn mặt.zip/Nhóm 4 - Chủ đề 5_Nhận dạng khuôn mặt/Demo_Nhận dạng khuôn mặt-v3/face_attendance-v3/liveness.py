"""Phát hiện chớp mắt để giảm rủi ro dùng ảnh tĩnh qua mặt camera.

Lưu ý: chớp mắt chặn được ảnh in / ảnh trên màn hình, nhưng KHÔNG chặn được
video quay sẵn có chớp mắt. Muốn an toàn hơn cần camera chiều sâu hoặc mô hình
chống giả mạo chuyên dụng.
"""

from collections import deque
import math
import random


def _dist(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])


def eye_aspect_ratio(pts):
    """EAR từ 6 điểm của một mắt (thứ tự như dlib/face_recognition).

    Mắt mở ~0.25-0.35, mắt nhắm < 0.15.
    """

    if len(pts) != 6:
        return None

    horizontal = _dist(pts[0], pts[3])

    if horizontal <= 0:
        return None

    return (_dist(pts[1], pts[5]) + _dist(pts[2], pts[4])) / (2.0 * horizontal)


def face_ear(landmarks):
    """EAR trung bình hai mắt từ dict landmarks của face_recognition."""

    values = []

    for key in ("left_eye", "right_eye"):

        pts = landmarks.get(key)

        if pts:
            v = eye_aspect_ratio(pts)

            if v is not None:
                values.append(v)

    return sum(values) / len(values) if values else None


def mouth_aspect_ratio(landmarks):
    """Độ há miệng = khoảng mở môi trong / chiều rộng miệng.

    Dùng các điểm môi trong của dlib (top_lip[8:11], bottom_lip[8:11]).
    Miệng ngậm ~0.0-0.1, há miệng rõ rệt > 0.35.
    """

    top = landmarks.get("top_lip")
    bottom = landmarks.get("bottom_lip")

    if not top or not bottom or len(top) < 12 or len(bottom) < 12:
        return None

    width = _dist(top[0], top[6])

    if width <= 0:
        return None

    # 3 cặp điểm môi trong đối diện nhau: (62,66) (61,67) (63,65)
    gaps = (
        _dist(top[9], bottom[9]),
        _dist(top[10], bottom[8]),
        _dist(top[8], bottom[10]),
    )

    return (sum(gaps) / 3.0) / width


def head_yaw(landmarks):
    """Ước lượng quay đầu trái/phải từ vị trí mũi so với hai mắt.

    Trả về số có dấu đã chuẩn hóa theo khoảng cách hai mắt:
      ~0 = nhìn thẳng, > 0 = đầu quay về phía phải khung hình,
      < 0 = quay về phía trái khung hình (khung hình đã lật gương,
      nên khớp với bên trái/phải của chính người dùng).
    """

    nose = landmarks.get("nose_tip")
    left = landmarks.get("left_eye")
    right = landmarks.get("right_eye")

    if not nose or not left or not right:
        return None

    def center(pts):
        return (
            sum(p[0] for p in pts) / len(pts),
            sum(p[1] for p in pts) / len(pts),
        )

    cl, cr = center(left), center(right)

    eye_dist = _dist(cl, cr)

    if eye_dist <= 0:
        return None

    nose_x = sum(p[0] for p in nose) / len(nose)

    return (nose_x - (cl[0] + cr[0]) / 2.0) / eye_dist


def face_pose(landmarks):
    """Gộp các chỉ số dùng cho kiểm tra người thật: ear, mar, yaw."""

    return {
        "ear": face_ear(landmarks),
        "mar": mouth_aspect_ratio(landmarks),
        "yaw": head_yaw(landmarks),
    }


class BlinkDetector:
    """Nhận ra một cú chớp mắt từ chuỗi giá trị EAR theo thời gian.

    Dùng ngưỡng tương đối (so với mức EAR mắt mở gần đây của chính người đó)
    nên không phụ thuộc kích thước mắt hay độ phân giải camera.
    """

    def __init__(
        self,
        history=30,
        drop_ratio=0.75,
        min_baseline=0.15,
        max_closed_seconds=0.9,
        min_history=6
    ):

        self.history = deque(maxlen=history)
        self.drop_ratio = drop_ratio
        self.min_baseline = min_baseline
        self.max_closed_seconds = max_closed_seconds
        self.min_history = min_history

        self.reset()

    def reset(self):

        self.history.clear()
        self._closed_since = None
        self.last_blink = None
        self.blink_count = 0

    def _baseline(self):

        if len(self.history) < self.min_history:
            return None

        ordered = sorted(self.history)

        return ordered[int(0.75 * (len(ordered) - 1))]

    def update(self, ear, now):
        """Thêm một mẫu EAR. Trả về True nếu vừa hoàn tất một cú chớp mắt."""

        baseline = self._baseline()

        closed = (
            baseline is not None
            and baseline >= self.min_baseline
            and ear < baseline * self.drop_ratio
        )

        blinked = False

        if closed:

            if self._closed_since is None:
                self._closed_since = now

            elif now - self._closed_since > self.max_closed_seconds:
                # "Nhắm" quá lâu: thực ra là tư thế/ánh sáng đã đổi (cúi đầu,
                # nheo mắt...) chứ không phải chớp mắt -> học lại đường cơ sở
                self.history.clear()
                self.history.append(ear)
                self._closed_since = None

        else:

            if self._closed_since is not None:

                if now - self._closed_since <= self.max_closed_seconds:
                    self.last_blink = now
                    self.blink_count += 1
                    blinked = True

                self._closed_since = None

        # Không đưa mẫu "mắt nhắm" vào đường cơ sở để nó không bị kéo thấp
        if not closed:
            self.history.append(ear)

        return blinked

    def recently_blinked(self, now, within):

        return (
            self.last_blink is not None
            and now - self.last_blink <= within
        )


# =========================================================
# THỬ THÁCH NGẪU NHIÊN (challenge-response)
# =========================================================
CHALLENGE_TEXT = {
    "blink": "Hãy chớp mắt một lần",
    "turn_left": "Hãy quay đầu sang TRÁI",
    "turn_right": "Hãy quay đầu sang PHẢI",
    "open_mouth": "Hãy há miệng",
}

DEFAULT_POOL = ("turn_left", "turn_right", "open_mouth", "blink")


class ChallengeLiveness:
    """Bắt người trước camera làm một chuỗi động tác NGẪU NHIÊN.

    Khác với chỉ chớp mắt, video quay sẵn không biết trước hệ thống sẽ yêu cầu
    động tác gì nên rất khó vượt qua. Mỗi lần xác minh gồm `steps` động tác
    khác nhau rút ngẫu nhiên từ `pool`; mỗi động tác phải được làm SAU khi
    được yêu cầu và trong `timeout` giây, nếu không sẽ bị đổi chuỗi mới.

    Lưu ý: ngưỡng yaw / mar là giá trị phổ biến, cần hiệu chỉnh lại trên
    camera thật của lớp học (xem config.example.json).
    """

    def __init__(
        self,
        pool=DEFAULT_POOL,
        steps=2,
        timeout=8.0,
        yaw_threshold=0.22,
        mar_threshold=0.35,
        hold=2,
        rng=None
    ):

        self.pool = tuple(p for p in pool if p in CHALLENGE_TEXT) or DEFAULT_POOL
        self.steps = max(1, min(steps, len(self.pool)))
        self.timeout = timeout
        self.yaw_threshold = yaw_threshold
        self.mar_threshold = mar_threshold
        self.hold = max(1, hold)
        self.rng = rng or random.Random()

        self.blink = BlinkDetector()

        self.reset()

    def reset(self):

        self.blink.reset()

        self.sequence = []
        self.index = 0
        self.issued_at = None
        self.passed_at = None
        self.failures = 0
        self._streak = 0

    # -----------------------------------------------------
    @property
    def current(self):
        """Động tác đang yêu cầu (None nếu chưa bắt đầu hoặc đã xong)."""

        if self.passed_at is not None or self.index >= len(self.sequence):
            return None

        return self.sequence[self.index]

    @property
    def prompt(self):

        cur = self.current

        if cur is None:
            return ""

        text = CHALLENGE_TEXT[cur]

        if len(self.sequence) > 1:
            text += f"  ({self.index + 1}/{len(self.sequence)})"

        return text

    def _new_sequence(self, now):

        self.sequence = self.rng.sample(self.pool, self.steps)
        self.index = 0
        self.issued_at = now
        self._streak = 0

    def _met(self, challenge, now, ear, mar, yaw):

        if challenge == "turn_left":
            return yaw is not None and yaw <= -self.yaw_threshold

        if challenge == "turn_right":
            return yaw is not None and yaw >= self.yaw_threshold

        if challenge == "open_mouth":
            return mar is not None and mar >= self.mar_threshold

        if challenge == "blink":
            return (
                self.blink.last_blink is not None
                and self.blink.last_blink >= self.issued_at
            )

        return False

    # -----------------------------------------------------
    def update(self, now, ear=None, mar=None, yaw=None):
        """Đưa một lần đo của khuôn mặt chính vào. True nếu vừa hoàn tất chuỗi."""

        if ear is not None:
            self.blink.update(ear, now)

        if self.passed_at is not None:
            return False

        if not self.sequence:
            self._new_sequence(now)

        if now - self.issued_at > self.timeout:
            # Quá hạn: đổi chuỗi khác để không đoán trước được
            self.failures += 1
            self._new_sequence(now)
            return False

        if not self._met(self.current, now, ear, mar, yaw):
            self._streak = 0
            return False

        self._streak += 1

        if self._streak < self.hold and self.current != "blink":
            return False

        self.index += 1
        self.issued_at = now
        self._streak = 0

        if self.index >= len(self.sequence):
            self.passed_at = now
            return True

        return False

    def recently_passed(self, now, within):

        return (
            self.passed_at is not None
            and now - self.passed_at <= within
        )
