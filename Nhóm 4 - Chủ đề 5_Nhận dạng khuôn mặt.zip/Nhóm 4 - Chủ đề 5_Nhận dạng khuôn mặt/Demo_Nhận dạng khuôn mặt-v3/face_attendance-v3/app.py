"""Giao diện chính (tkinter). Mọi logic điểm danh nằm trong engine.py."""

import datetime
import logging
import os
import sqlite3
import time
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, filedialog

import numpy as np
from PIL import Image, ImageTk, ImageDraw

import db
import secure
import theme
import vision
from auth import LoginThrottle
from config import Config
from engine import Engine

log = logging.getLogger(__name__)


# =========================================================
# ĐƯỜNG DẪN
# =========================================================
# Luôn lưu file dữ liệu cạnh file script, không phụ thuộc thư mục đang chạy terminal
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

DB_FILE = os.path.join(BASE_DIR, "diemdanh.db")
EXPORT_DIR = os.path.join(BASE_DIR, "exports")
BACKUP_DIR = os.path.join(BASE_DIR, "backups")


# =========================================================
# DANH SÁCH KHOA
# =========================================================
FACULTIES = [
    "Công nghệ thông tin",
    "Kinh tế",
    "Điện - Điện tử",
    "Cơ khí",
    "Ngoại ngữ",
    "Sư phạm",
    "Y - Dược",
    "Luật",
    "Khác",
]



# =========================================================
# ĐĂNG KÝ TÀI KHOẢN
# =========================================================
class AccountRegisterDialog(theme.BaseDialog):

    def __init__(self, parent, database):

        super().__init__(
            parent,
            "Tạo tài khoản",
            "Tài khoản dùng để đăng nhập vào hệ thống điểm danh.",
            width=440,
            ok_text="Đăng ký",
            ok_style="success"
        )

        self.db = database

        f_user = theme.FormField(self.body, "Tên đăng nhập")
        f_pass = theme.FormField(self.body, "Mật khẩu", show="•")
        f_confirm = theme.FormField(self.body, "Nhập lại mật khẩu", show="•")

        for field in (f_user, f_pass, f_confirm):
            field.pack(fill="x", pady=(0, 12))

        self.var_username = f_user.var
        self.var_password = f_pass.var
        self.var_confirm = f_confirm.var

        f_user.focus_entry()
        self.finish()

    def submit(self):

        username = self.var_username.get().strip()
        password = self.var_password.get()
        confirm = self.var_confirm.get()

        if not username or not password or not confirm:
            messagebox.showwarning(
                "Thiếu thông tin",
                "Vui lòng nhập đầy đủ thông tin!",
                parent=self
            )
            return

        if len(username) < 3:
            messagebox.showwarning(
                "Tên đăng nhập",
                "Tên đăng nhập phải có ít nhất 3 ký tự!",
                parent=self
            )
            return

        if len(password) < 6:
            messagebox.showwarning(
                "Mật khẩu",
                "Mật khẩu phải có ít nhất 6 ký tự!",
                parent=self
            )
            return

        if password != confirm:
            messagebox.showwarning(
                "Mật khẩu",
                "Mật khẩu nhập lại không khớp!",
                parent=self
            )
            return

        if self.db.user_exists(username):
            messagebox.showwarning(
                "Trùng tài khoản",
                "Tên đăng nhập này đã tồn tại!",
                parent=self
            )
            return

        self.result = (
            username,
            password
        )

        self.destroy()


# =========================================================
# HỘP THOẠI ĐỔI MẬT KHẨU
# =========================================================
class ChangePasswordDialog(theme.BaseDialog):

    def __init__(self, parent):

        super().__init__(
            parent,
            "Đổi mật khẩu",
            "Nhập mật khẩu hiện tại và mật khẩu mới (tối thiểu 6 ký tự).",
            width=440,
            ok_text="Đổi mật khẩu",
            ok_style="primary"
        )

        f_old = theme.FormField(self.body, "Mật khẩu hiện tại", show="•")
        f_new = theme.FormField(self.body, "Mật khẩu mới", show="•")
        f_confirm = theme.FormField(self.body, "Nhập lại mật khẩu mới", show="•")

        for field in (f_old, f_new, f_confirm):
            field.pack(fill="x", pady=(0, 12))

        self.var_old = f_old.var
        self.var_new = f_new.var
        self.var_confirm = f_confirm.var

        f_old.focus_entry()
        self.finish()

    def submit(self):

        old = self.var_old.get()
        new = self.var_new.get()
        confirm = self.var_confirm.get()

        if not old or not new or not confirm:
            messagebox.showwarning(
                "Thiếu thông tin",
                "Vui lòng nhập đầy đủ thông tin!",
                parent=self
            )
            return

        if len(new) < 6:
            messagebox.showwarning(
                "Mật khẩu",
                "Mật khẩu mới phải có ít nhất 6 ký tự!",
                parent=self
            )
            return

        if new != confirm:
            messagebox.showwarning(
                "Mật khẩu",
                "Mật khẩu nhập lại không khớp!",
                parent=self
            )
            return

        self.result = (old, new)

        self.destroy()


# =========================================================
# ĐĂNG NHẬP
# =========================================================
class LoginPage:

    def __init__(self, root, database, on_login, throttle):

        self.root = root
        self.db = database
        self.on_login = on_login
        self.throttle = throttle

        self.build_ui()

    # -----------------------------------------------------
    # GIAO DIỆN ĐĂNG NHẬP
    # -----------------------------------------------------
    def build_ui(self):

        self.clear_window()

        self.root.title("Đăng nhập - Hệ thống điểm danh")
        self.root.configure(bg=theme.SURFACE)
        self.root.minsize(780, 500)

        theme.center_on_screen(self.root, 920, 580)

        # ---------------- Bên trái: thương hiệu ----------------
        left = tk.Frame(self.root, bg=theme.NAVY, width=380)
        left.pack(side="left", fill="y")
        left.pack_propagate(False)

        tk.Label(
            left,
            text="Face Recognition Attendance System",
            bg=theme.NAVY,
            fg=theme.NAVY_MUTED,
            font=(theme.FONT, 9)
        ).pack(side="bottom", pady=20)

        brand = tk.Frame(left, bg=theme.NAVY)
        brand.pack(expand=True, anchor="w", padx=44)

        theme.logo(brand, 72).pack(anchor="w")

        tk.Label(
            brand,
            text="HỆ THỐNG\nĐIỂM DANH",
            bg=theme.NAVY,
            fg="#FFFFFF",
            font=(theme.FONT, 26, "bold"),
            justify="left"
        ).pack(anchor="w", pady=(22, 8))

        tk.Label(
            brand,
            text="Nhận diện khuôn mặt, ghi nhận chuyên cần\ntự động và xuất dữ liệu ra Excel.",
            bg=theme.NAVY,
            fg=theme.NAVY_MUTED,
            font=(theme.FONT, 11),
            justify="left"
        ).pack(anchor="w")

        for text in (
            "Điểm danh chỉ với một cú nhấp",
            "Quản lý danh sách đăng ký khuôn mặt",
            "Lưu kết quả vào file Excel"
        ):
            row = tk.Frame(brand, bg=theme.NAVY)
            row.pack(anchor="w", pady=(10, 0))

            tk.Label(
                row,
                text="✓",
                bg=theme.NAVY,
                fg=theme.ACCENT,
                font=(theme.FONT, 11, "bold")
            ).pack(side="left", padx=(0, 10))

            tk.Label(
                row,
                text=text,
                bg=theme.NAVY,
                fg="#FFFFFF",
                font=(theme.FONT, 10)
            ).pack(side="left")

        # ---------------- Bên phải: form ----------------
        right = tk.Frame(self.root, bg=theme.SURFACE)
        right.pack(side="left", fill="both", expand=True)

        form = tk.Frame(right, bg=theme.SURFACE)
        form.place(relx=0.5, rely=0.5, anchor="center", width=340)

        tk.Label(
            form,
            text="Chào mừng trở lại",
            bg=theme.SURFACE,
            fg=theme.TEXT,
            font=(theme.FONT, 22, "bold"),
            anchor="w"
        ).pack(fill="x")

        tk.Label(
            form,
            text="Đăng nhập để bắt đầu điểm danh",
            bg=theme.SURFACE,
            fg=theme.MUTED,
            font=(theme.FONT, 11),
            anchor="w"
        ).pack(fill="x", pady=(2, 24))

        f_user = theme.FormField(form, "Tên đăng nhập")
        f_user.pack(fill="x", pady=(0, 14))

        f_pass = theme.FormField(form, "Mật khẩu", show="•")
        f_pass.pack(fill="x")

        self.username_var = f_user.var
        self.password_var = f_pass.var

        theme.RoundedButton(
            form,
            "ĐĂNG NHẬP",
            self.login,
            "primary",
            12,
            48
        ).pack(fill="x", pady=(24, 18))

        tk.Label(
            form,
            text="Chưa có tài khoản?",
            bg=theme.SURFACE,
            fg=theme.MUTED,
            font=(theme.FONT, 10)
        ).pack(pady=(0, 8))

        theme.RoundedButton(
            form,
            "Tạo tài khoản mới",
            self.register_account,
            "secondary",
            11,
            44
        ).pack(fill="x")

        f_user.focus_entry()

        self.root.bind(
            "<Return>",
            lambda e: self.login()
        )

    def clear_window(self):

        for widget in self.root.winfo_children():
            widget.destroy()

    def login(self):

        username = self.username_var.get().strip()
        password = self.password_var.get()

        if not username or not password:

            messagebox.showwarning(
                "Thiếu thông tin",
                "Vui lòng nhập tên đăng nhập và mật khẩu!"
            )

            return

        locked = self.throttle.seconds_locked(username)

        if locked:

            self.db.log_event("login_locked", username)

            messagebox.showwarning(
                "Tạm khóa",
                "Nhập sai quá nhiều lần.\n"
                f"Vui lòng thử lại sau {locked} giây."
            )

            return

        ok, info = self.db.check_login(username, password)

        if not ok:

            self.throttle.failure(username)

            self.db.log_event("login_failed", username)

            # Không tiết lộ là sai tên hay sai mật khẩu
            messagebox.showerror(
                "Đăng nhập thất bại",
                "Tên đăng nhập hoặc mật khẩu không đúng!"
            )

            return

        self.throttle.success(username)

        self.db.log_event("login_ok", username, username)

        self.root.unbind("<Return>")

        self.on_login(username, info)

    def register_account(self):

        dialog = AccountRegisterDialog(
            self.root,
            self.db
        )

        self.root.wait_window(dialog)

        if not dialog.result:
            return

        username, password = dialog.result

        try:
            role = self.db.create_user(username, password)

        except ValueError as e:
            messagebox.showerror("Lỗi", str(e))
            return

        note = (
            "\n\nĐây là tài khoản đầu tiên nên được cấp quyền quản trị."
            if role == db.ROLE_ADMIN else ""
        )

        messagebox.showinfo(
            "Thành công",
            "Đăng ký tài khoản thành công!\n\n"
            f"Tên đăng nhập: {username}{note}"
        )

        self.username_var.set(username)
        self.password_var.set("")



# =========================================================
# HỘP THOẠI ĐĂNG KÝ KHUÔN MẶT
# =========================================================
class RegisterDialog(theme.BaseDialog):

    def __init__(
        self, parent, title="Đăng ký khuôn mặt",
        subtitle="Điền thông tin để gắn với khuôn mặt đang hiển thị trên camera."
    ):

        super().__init__(
            parent,
            title,
            subtitle,
            width=440,
            ok_text="Tiếp tục" if "ảnh" in title else "Đăng ký",
            ok_style="success"
        )

        f_id = theme.FormField(self.body, "Mã sinh viên")
        f_name = theme.FormField(self.body, "Họ và tên")
        f_class = theme.FormField(self.body, "Lớp")
        f_faculty = theme.FormField(self.body, "Khoa", values=FACULTIES)

        for field in (f_id, f_name, f_class, f_faculty):
            field.pack(fill="x", pady=(0, 12))

        self.var_id = f_id.var
        self.var_name = f_name.var
        self.var_class = f_class.var
        self.var_faculty = f_faculty.var

        f_id.focus_entry()
        self.finish()

    def submit(self):

        sid = self.var_id.get().strip().upper()
        name = self.var_name.get().strip()
        lop = self.var_class.get().strip().upper()
        khoa = self.var_faculty.get().strip()

        if not sid or not name or not lop or not khoa:

            messagebox.showwarning(
                "Thiếu thông tin",
                "Vui lòng nhập đầy đủ Mã SV, Họ tên, Lớp và Khoa!",
                parent=self
            )

            return

        self.result = (
            sid,
            name.title(),
            lop,
            khoa
        )

        self.destroy()



# =========================================================
# HỘP THOẠI SỬA THÔNG TIN
# =========================================================
class EditStudentDialog(theme.BaseDialog):

    def __init__(self, parent, student):

        super().__init__(
            parent,
            "Sửa thông tin",
            f"Mã SV: {student['student_id']} (không thể đổi)",
            420,
            "Lưu"
        )

        f_name = theme.FormField(self.body, "Họ và tên")
        f_class = theme.FormField(self.body, "Lớp")
        f_faculty = theme.FormField(self.body, "Khoa", values=FACULTIES)

        for field in (f_name, f_class, f_faculty):
            field.pack(fill="x", pady=(0, 12))

        self.var_name = f_name.var
        self.var_class = f_class.var
        self.var_faculty = f_faculty.var

        self.var_name.set(student["name"])
        self.var_class.set(student["class_name"])
        self.var_faculty.set(student["faculty"])

        f_name.focus_entry()
        self.finish()

    def submit(self):

        name = self.var_name.get().strip()
        lop = self.var_class.get().strip().upper()
        khoa = self.var_faculty.get().strip()

        if not name or not lop or not khoa:

            messagebox.showwarning(
                "Thiếu thông tin",
                "Vui lòng nhập đầy đủ Họ tên, Lớp và Khoa!",
                parent=self
            )

            return

        self.result = (name.title(), lop, khoa)

        self.destroy()


# =========================================================
# HỘP THOẠI CHỌN MỘT SINH VIÊN
# =========================================================
class PickerDialog(theme.BaseDialog):

    def __init__(self, parent, title, subtitle, options, ok_text, ok_style):

        super().__init__(
            parent,
            title,
            subtitle,
            440,
            ok_text,
            ok_style
        )

        field = theme.FormField(
            self.body,
            "Chọn sinh viên",
            values=options
        )

        field.pack(fill="x", pady=(0, 12))

        self.combo = field.entry
        self.combo.current(0)

        self.finish()

    def submit(self):

        idx = self.combo.current()

        if idx < 0:

            messagebox.showwarning(
                "Chưa chọn",
                "Vui lòng chọn một sinh viên trong danh sách!",
                parent=self
            )

            return

        self.result = idx

        self.destroy()


# =========================================================
# CỬA SỔ THỐNG KÊ & BÁO CÁO
# =========================================================
class StatsWindow:

    CHART_MAX_DAYS = 30
    LOW_RATE = 70          # dưới mức này tô đỏ, cần nhắc nhở

    def __init__(self, parent, database, export_dir):

        self.parent = parent
        self.db = database
        self.export_dir = export_dir
        self.stats = None

        self.win = tk.Toplevel(parent)
        self.win.title("Thống kê & Báo cáo chuyên cần")
        self.win.configure(bg=theme.BG)
        self.win.minsize(880, 620)

        theme.center_on_parent(self.win, parent, 980, 700)

        self.var_from = tk.StringVar()
        self.var_to = tk.StringVar()

        self.build_ui()
        self.refresh()

    # -----------------------------------------------------
    def exists(self):

        try:
            return bool(self.win.winfo_exists())
        except tk.TclError:
            return False

    def focus(self):

        self.win.deiconify()
        self.win.lift()
        self.win.focus_force()

    def close(self):

        try:
            self.win.destroy()
        except tk.TclError:
            pass

    # -----------------------------------------------------
    def build_ui(self):

        win = self.win

        tk.Label(
            win,
            text="Thống kê & Báo cáo chuyên cần",
            bg=theme.BG,
            fg=theme.TEXT,
            font=(theme.FONT, 18, "bold"),
            anchor="w"
        ).pack(fill="x", padx=24, pady=(20, 0))

        tk.Label(
            win,
            text='Một "buổi" là một ngày có ít nhất một lượt điểm danh. '
                 "Để trống ô ngày để xem toàn bộ.",
            bg=theme.BG,
            fg=theme.MUTED,
            font=(theme.FONT, 10),
            anchor="w"
        ).pack(fill="x", padx=24, pady=(2, 12))

        # ---- bộ lọc ngày ----
        flt = tk.Frame(win, bg=theme.BG)
        flt.pack(fill="x", padx=24)

        for text, var in (("Từ ngày", self.var_from), ("Đến ngày", self.var_to)):

            tk.Label(
                flt,
                text=text,
                bg=theme.BG,
                fg=theme.MUTED,
                font=(theme.FONT, 10)
            ).pack(side="left", padx=(0, 6))

            ttk.Entry(
                flt,
                textvariable=var,
                width=12
            ).pack(side="left", padx=(0, 14))

        for text, cmd, style in (
            ("Áp dụng", self.refresh, "primary"),
            ("Hôm nay", lambda: self.set_last_days(1), "secondary"),
            ("7 ngày", lambda: self.set_last_days(7), "secondary"),
            ("Tất cả", self.clear_range, "secondary"),
        ):
            theme.RoundedButton(
                flt, text, cmd, style, 10, 34, 8, 90
            ).pack(side="left", padx=(0, 8))

        # ---- các ô tổng hợp ----
        cards = tk.Frame(win, bg=theme.BG)
        cards.pack(fill="x", padx=24, pady=14)
        cards.columnconfigure((0, 1, 2, 3), weight=1, uniform="cards")

        self.lbl_students = self.make_card(cards, 0, "SINH VIÊN")
        self.lbl_days = self.make_card(cards, 1, "SỐ BUỔI")
        self.lbl_rate = self.make_card(cards, 2, "CHUYÊN CẦN TB")
        self.lbl_low = self.make_card(cards, 3, "CẦN NHẮC NHỞ")

        # ---- hai tab: theo sinh viên / theo ngày ----
        notebook = ttk.Notebook(win)
        notebook.pack(fill="both", expand=True, padx=24)

        tab_students = tk.Frame(notebook, bg=theme.SURFACE)
        tab_days = tk.Frame(notebook, bg=theme.SURFACE)

        notebook.add(tab_students, text="  Theo sinh viên  ")
        notebook.add(tab_days, text="  Theo ngày  ")

        self.tree_students = self.make_tree(
            tab_students,
            (
                ("sid", "Mã SV", 90, "w"),
                ("name", "Họ tên", 220, "w"),
                ("cls", "Lớp", 90, "w"),
                ("present", "Có mặt", 70, "center"),
                ("absent", "Vắng", 70, "center"),
                ("rate", "Tỉ lệ", 80, "center"),
                ("label", "Xếp loại", 120, "center"),
            )
        )

        self.tree_students.tag_configure("low", foreground=theme.DANGER)

        tab_days.rowconfigure(0, weight=1)
        tab_days.rowconfigure(1, weight=1)
        tab_days.columnconfigure(0, weight=1)

        self.chart = tk.Canvas(
            tab_days,
            bg=theme.SURFACE,
            height=210,
            highlightthickness=0
        )
        self.chart.grid(row=0, column=0, sticky="nsew", padx=8, pady=8)
        self.chart.bind("<Configure>", lambda e: self.draw_chart())

        day_frame = tk.Frame(tab_days, bg=theme.SURFACE)
        day_frame.grid(row=1, column=0, sticky="nsew")

        self.tree_days = self.make_tree(
            day_frame,
            (
                ("day", "Ngày", 140, "w"),
                ("present", "Có mặt", 100, "center"),
                ("total", "Tổng SV", 100, "center"),
                ("rate", "Tỉ lệ", 100, "center"),
            )
        )

        # ---- chân trang ----
        foot = tk.Frame(win, bg=theme.BG)
        foot.pack(fill="x", padx=24, pady=14)

        self.lbl_range = tk.Label(
            foot,
            text="",
            bg=theme.BG,
            fg=theme.MUTED,
            font=(theme.FONT, 10),
            anchor="w"
        )
        self.lbl_range.pack(side="left")

        theme.RoundedButton(
            foot,
            "⇩  Xuất báo cáo Excel",
            self.export,
            "success",
            11,
            40,
            8,
            200
        ).pack(side="right")

    def make_card(self, parent, col, caption):

        box = tk.Frame(
            parent,
            bg=theme.SURFACE,
            highlightthickness=1,
            highlightbackground=theme.BORDER
        )
        box.grid(row=0, column=col, sticky="ew", padx=(0 if col == 0 else 8, 0))

        value = tk.Label(
            box,
            text="0",
            bg=theme.SURFACE,
            fg=theme.PRIMARY,
            font=(theme.FONT, 22, "bold")
        )
        value.pack(pady=(12, 0))

        tk.Label(
            box,
            text=caption,
            bg=theme.SURFACE,
            fg=theme.MUTED,
            font=(theme.FONT, 9, "bold")
        ).pack(pady=(0, 12))

        return value

    def make_tree(self, parent, columns):

        frame = tk.Frame(parent, bg=theme.SURFACE)
        frame.pack(fill="both", expand=True)
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)

        tree = ttk.Treeview(
            frame,
            columns=[c[0] for c in columns],
            show="headings",
            selectmode="browse"
        )

        for key, title, width, anchor in columns:
            tree.heading(key, text=title, anchor=anchor)
            tree.column(key, width=width, anchor=anchor)

        scroll = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scroll.set)

        tree.grid(row=0, column=0, sticky="nsew")
        scroll.grid(row=0, column=1, sticky="ns")

        return tree

    # -----------------------------------------------------
    # LỌC NGÀY
    # -----------------------------------------------------
    def set_last_days(self, n):

        today = datetime.date.today()

        start = today - datetime.timedelta(days=n - 1)

        self.var_from.set(start.strftime("%d/%m/%Y"))
        self.var_to.set(today.strftime("%d/%m/%Y"))

        self.refresh()

    def clear_range(self):

        self.var_from.set("")
        self.var_to.set("")

        self.refresh()

    def read_range(self):
        """Trả về (từ, đến) dạng YYYY-MM-DD hoặc None nếu nhập sai."""

        try:
            d_from = db.parse_vn_date(self.var_from.get())
            d_to = db.parse_vn_date(self.var_to.get())

        except ValueError:

            messagebox.showwarning(
                "Ngày không hợp lệ",
                "Nhập ngày theo dạng dd/mm/yyyy, ví dụ 30/09/2026.",
                parent=self.win
            )

            return None

        if d_from and d_to and d_from > d_to:

            messagebox.showwarning(
                "Khoảng ngày không hợp lệ",
                "Ngày bắt đầu phải trước hoặc bằng ngày kết thúc.",
                parent=self.win
            )

            return None

        return d_from, d_to

    # -----------------------------------------------------
    # HIỂN THỊ
    # -----------------------------------------------------
    def refresh(self):

        rng = self.read_range()

        if rng is None:
            return

        self.range = rng

        st = self.db.statistics(*rng)

        self.stats = st

        per_student = st["per_student"]

        n_low = sum(1 for p in per_student if p["rate"] < self.LOW_RATE)

        self.lbl_students.config(text=str(len(per_student)))
        self.lbl_days.config(text=str(len(st["days"])))
        self.lbl_rate.config(text=f"{st['overall_rate']:.1f}%")
        self.lbl_low.config(
            text=str(n_low),
            fg=theme.DANGER if n_low else theme.SUCCESS
        )

        self.tree_students.delete(*self.tree_students.get_children())

        # Người chuyên cần thấp nhất lên đầu để dễ chú ý
        for p in sorted(per_student, key=lambda p: (p["rate"], p["name"])):

            self.tree_students.insert(
                "",
                "end",
                values=(
                    p["student_id"],
                    p["name"],
                    p["class_name"] or "—",
                    p["present"],
                    p["absent"],
                    f"{p['rate']:.1f}%",
                    db.rate_label(p["rate"])
                ),
                tags=("low",) if p["rate"] < self.LOW_RATE else ()
            )

        self.tree_days.delete(*self.tree_days.get_children())

        for p in reversed(st["per_day"]):

            self.tree_days.insert(
                "",
                "end",
                values=(
                    db.slot_label(p["day"]),
                    p["present"],
                    p["total"],
                    f"{p['rate']:.1f}%"
                )
            )

        d_from, d_to = rng

        self.lbl_range.config(
            text="Phạm vi: "
                 + (d_from and self.fmt(d_from) or "đầu")
                 + " → "
                 + (d_to and self.fmt(d_to) or "nay")
        )

        self.draw_chart()

    @staticmethod
    def fmt(day):

        return datetime.datetime.strptime(
            day, "%Y-%m-%d"
        ).strftime("%d/%m/%Y")

    def draw_chart(self):
        """Biểu đồ cột: tỉ lệ có mặt theo ngày (tối đa 30 ngày gần nhất)."""

        c = self.chart

        c.delete("all")

        if not self.stats:
            return

        days = self.stats["per_day"][-self.CHART_MAX_DAYS:]

        w = max(int(c.winfo_width()), 400)
        h = max(int(c.winfo_height()), 150)

        left, right, top, bottom = 44, 16, 16, 30

        if not days:

            c.create_text(
                w / 2,
                h / 2,
                text="Chưa có dữ liệu điểm danh trong khoảng này",
                fill=theme.MUTED,
                font=(theme.FONT, 11)
            )

            return

        plot_w = w - left - right
        plot_h = h - top - bottom

        # Đường lưới 0 / 50 / 100 %
        for pct in (0, 50, 100):

            y = top + plot_h * (1 - pct / 100)

            c.create_line(left, y, w - right, y, fill=theme.BORDER)

            c.create_text(
                left - 6,
                y,
                text=f"{pct}%",
                anchor="e",
                fill=theme.MUTED,
                font=(theme.FONT, 8)
            )

        slot = plot_w / len(days)
        bar_w = min(slot * 0.6, 48)

        for i, p in enumerate(days):

            cx = left + slot * (i + 0.5)
            y = top + plot_h * (1 - p["rate"] / 100)

            c.create_rectangle(
                cx - bar_w / 2,
                y,
                cx + bar_w / 2,
                top + plot_h,
                fill=(
                    theme.DANGER if p["rate"] < self.LOW_RATE
                    else theme.PRIMARY
                ),
                outline=""
            )

            c.create_text(
                cx,
                y - 8,
                text=f"{p['rate']:.0f}%",
                fill=theme.TEXT,
                font=(theme.FONT, 8)
            )

            # Chỉ ghi nhãn ngày cho một số cột nếu quá nhiều
            if len(days) <= 12 or i % max(len(days) // 10, 1) == 0:

                c.create_text(
                    cx,
                    h - bottom + 14,
                    text=db.slot_label(p["day"], with_year=False).split(" ")[0],
                    fill=theme.MUTED,
                    font=(theme.FONT, 8)
                )

    # -----------------------------------------------------
    # XUẤT BÁO CÁO
    # -----------------------------------------------------
    def export(self):

        rng = self.read_range()

        if rng is None:
            return

        path = os.path.join(
            self.export_dir,
            datetime.datetime.now().strftime("baocao_%Y%m%d_%H%M%S.xlsx")
        )

        try:

            os.makedirs(self.export_dir, exist_ok=True)

            n_students, n_days = self.db.export_excel(path, *rng)

        except Exception as e:

            log.exception("Không xuất được báo cáo")

            messagebox.showerror(
                "Lỗi",
                f"Không xuất được báo cáo: {e}",
                parent=self.win
            )

            return

        messagebox.showinfo(
            "Thành công",
            f"Đã xuất báo cáo:\n{path}\n\n"
            f"{n_students} sinh viên · {n_days} buổi\n"
            "Gồm 3 sheet: Diem Danh, Tong Hop, Theo Ngay.",
            parent=self.win
        )


# =========================================================
# MÀN HÌNH ĐIỂM DANH
# =========================================================
class FaceRecognitionApp:

    def __init__(self, root, username, role, database, cfg, on_logout):

        self.root = root
        self.username = username
        self.role = role
        self.db = database
        self.cfg = cfg
        self.on_logout = on_logout

        self.engine = Engine(database, cfg)
        self.engine.actor = username

        self.root.title("Hệ thống Điểm Danh Khuôn Mặt")
        self.root.configure(bg=theme.BG)
        self.root.minsize(1000, 740)

        theme.center_on_screen(self.root, 1140, 790)

        self.font_label = theme.load_font(15, bold=True)
        self.font_badge = theme.load_font(12, bold=True)

        # Cờ điều khiển các vòng lặp after()
        self.running = True
        self.frame_job = None
        self.status_job = None

        # Trạng thái giao diện
        self.log_count = 0
        self._info_key = None
        self._last_fid = -1
        self._last_rid = -1
        self._small_w = None
        self._dirty = True
        self._cam_msg = False
        self._started = time.time()

        self.var_auto = tk.BooleanVar(value=self.engine.auto_attendance)
        self.var_live = tk.BooleanVar(value=self.engine.require_liveness)

        self.build_ui()
        self.load_today_log()

        # Camera + nhận diện chạy ở luồng riêng
        self.detector = self.build_detector(cfg)

        self.pipeline = vision.VisionPipeline(
            lambda: vision.open_camera(
                cfg.camera_index,
                cfg.frame_width,
                cfg.frame_height
            ),
            self.detector
        )

        self.pipeline.start()

        self.root.protocol(
            "WM_DELETE_WINDOW",
            self.on_closing
        )

        # Chế độ kiosk: toàn màn hình cho máy đặt cố định ở cửa lớp
        if cfg.kiosk:
            try:
                self.root.attributes("-fullscreen", True)
            except tk.TclError:
                log.warning("Hệ điều hành không hỗ trợ toàn màn hình")

        self.tick()

        self.warn_unenrolled()

    def warn_unenrolled(self):
        """Báo nếu có sinh viên chưa có mẫu của mô hình nhận diện đang dùng."""

        missing = self.engine.unenrolled

        if not missing:
            return

        names = ", ".join(
            self.engine.students[m]["name"] for m in missing[:5]
            if m in self.engine.students
        )

        messagebox.showwarning(
            "Cần thu mẫu lại",
            f"{len(missing)} sinh viên chưa có mẫu khuôn mặt cho mô hình "
            f"'{self.engine.model}' nên sẽ KHÔNG được nhận diện:\n{names}"
            + ("…" if len(missing) > 5 else "") +
            "\n\nDùng nút 'Thêm mẫu mặt' để thu lại cho từng người."
        )

    def build_detector(self, cfg):
        """Bộ nhận diện theo cấu hình: mô hình (dlib/arcface), chống giả mạo, số mặt."""

        import backends

        backend = backends.make_backend(cfg, BASE_DIR)

        spoof = None

        if cfg.antispoof_enable:

            try:
                import antispoof

                model_dir = cfg.antispoof_dir

                if not os.path.isabs(model_dir):
                    model_dir = os.path.join(BASE_DIR, model_dir)

                spoof = antispoof.PassiveAntiSpoof(model_dir)

            except Exception as e:

                log.exception("Không bật được chống giả mạo thụ động")

                # Không được âm thầm bỏ qua: tắt hẳn để engine không chờ điểm mãi
                cfg.antispoof_enable = False

                messagebox.showwarning(
                    "Chống giả mạo thụ động",
                    f"Không tải được mô hình: {e}\n\n"
                    "Hệ thống chạy tiếp mà KHÔNG có lớp này "
                    "(vẫn có chớp mắt/thử thách).\n"
                    "Chạy: python tools/get_models.py"
                )

        return vision.FaceDetector(
            cfg.detect_scale,
            backend=backend,
            antispoof=spoof,
            max_faces=cfg.max_faces
        )

    def build_ui(self):

        # ---------------- Header ----------------
        header_right = theme.build_header(
            self.root,
            "Hệ thống điểm danh tự động bằng nhận diện khuôn mặt",
            "Nhận diện tự động · Chống ảnh giả bằng chớp mắt · Báo cáo Excel"
        )

        theme.RoundedButton(
            header_right,
            "Đăng xuất",
            self.logout,
            "danger",
            10,
            36,
            8,
            104
        ).pack(side="right", padx=(20, 0))

        theme.RoundedButton(
            header_right,
            "Đổi mật khẩu",
            self.change_password,
            "secondary",
            10,
            36,
            8,
            130
        ).pack(side="right", padx=(20, 0))

        user_box = tk.Frame(header_right, bg=theme.NAVY)
        user_box.pack(side="right", padx=(20, 0))

        user_avatar = theme.Avatar(user_box, 36, bg=theme.NAVY)
        user_avatar.set(theme.initials(self.username), theme.PRIMARY)
        user_avatar.pack(side="left", padx=(0, 10))

        tk.Label(
            user_box,
            text=f"{self.username}  ·  "
                 f"{'Quản trị' if self.role == db.ROLE_ADMIN else 'Giảng viên'}",
            bg=theme.NAVY,
            fg="#FFFFFF",
            font=(theme.FONT, 10, "bold")
        ).pack(side="left")

        theme.ClockWidget(header_right).pack(side="right")

        # ---------------- Vùng chính ----------------
        main = tk.Frame(self.root, bg=theme.BG)
        main.pack(fill="both", expand=True, padx=24, pady=20)

        main.columnconfigure(0, weight=1)
        main.columnconfigure(1, weight=0)
        main.rowconfigure(0, weight=1)

        # ---------------- Camera ----------------
        cam_card = theme.Card(main, pady=14)
        cam_card.grid(row=0, column=0, sticky="nsew", padx=(0, 20))

        cam_head = tk.Frame(cam_card.body, bg=theme.SURFACE)
        cam_head.pack(fill="x", pady=(0, 10))

        tk.Label(
            cam_head,
            text="CAMERA TRỰC TIẾP",
            bg=theme.SURFACE,
            fg=theme.MUTED,
            font=(theme.FONT, 9, "bold")
        ).pack(side="left")

        tk.Label(
            cam_head,
            text="Nhìn thẳng vào camera để nhận diện tốt nhất",
            bg=theme.SURFACE,
            fg=theme.MUTED,
            font=(theme.FONT, 9)
        ).pack(side="right")

        cam_box = tk.Frame(cam_card.body, bg=theme.CAMERA_BG)
        cam_box.pack(expand=True, fill="both")
        cam_box.pack_propagate(False)

        self.cam_label = tk.Label(cam_box, bg=theme.CAMERA_BG)
        self.cam_label.pack(expand=True, fill="both")

        # ---------------- Bên phải ----------------
        right = tk.Frame(main, bg=theme.BG, width=380)
        right.grid(row=0, column=1, sticky="ns")
        right.pack_propagate(False)

        # Trạng thái
        self.status = theme.StatusBanner(right)
        self.status.pack(fill="x")
        self.status.set("idle", "Sẵn sàng", "Đưa khuôn mặt vào khung hình")

        # Người đang nhận diện
        person = theme.Card(right, title="Người đang nhận diện")
        person.pack(fill="x", pady=14)

        person_row = tk.Frame(person.body, bg=theme.SURFACE)
        person_row.pack(fill="x")

        self.avatar = theme.Avatar(person_row, 60)
        self.avatar.pack(side="left", padx=(0, 14))

        person_text = tk.Frame(person_row, bg=theme.SURFACE)
        person_text.pack(side="left", fill="x", expand=True)

        self.lbl_name = tk.Label(
            person_text,
            text="Chưa nhận diện",
            bg=theme.SURFACE,
            fg=theme.TEXT,
            font=(theme.FONT, 15, "bold"),
            anchor="w"
        )
        self.lbl_name.pack(fill="x")

        self.lbl_class = tk.Label(
            person_text,
            text="Lớp: —",
            bg=theme.SURFACE,
            fg=theme.MUTED,
            font=(theme.FONT, 10),
            anchor="w"
        )
        self.lbl_class.pack(fill="x", pady=(2, 0))

        self.lbl_faculty = tk.Label(
            person_text,
            text="Khoa: —",
            bg=theme.SURFACE,
            fg=theme.MUTED,
            font=(theme.FONT, 10),
            anchor="w"
        )
        self.lbl_faculty.pack(fill="x")

        self.lbl_state = tk.Label(
            person_text,
            text="",
            bg=theme.SURFACE,
            fg=theme.MUTED,
            font=(theme.FONT, 10, "bold"),
            anchor="w"
        )
        self.lbl_state.pack(fill="x", pady=(2, 0))

        # Tùy chọn
        opts = tk.Frame(right, bg=theme.BG)
        opts.pack(fill="x", pady=(0, 10))

        for text, var, cmd in (
            (
                "Tự động điểm danh khi nhận ra",
                self.var_auto,
                self.on_toggle_auto
            ),
            (
                "Yêu cầu xác nhận người thật (chống ảnh/video giả)",
                self.var_live,
                self.on_toggle_live
            ),
        ):
            tk.Checkbutton(
                opts,
                text=text,
                variable=var,
                command=cmd,
                bg=theme.BG,
                fg=theme.TEXT,
                activebackground=theme.BG,
                activeforeground=theme.TEXT,
                selectcolor="#FFFFFF",
                font=(theme.FONT, 10),
                anchor="w",
                cursor="hand2",
                highlightthickness=0,
                bd=0
            ).pack(fill="x")

        # Nút chức năng
        theme.RoundedButton(
            right,
            "✔  Điểm danh",
            self.mark_attendance,
            "success",
            13,
            52
        ).pack(fill="x")

        btn_row = tk.Frame(right, bg=theme.BG)
        btn_row.pack(fill="x", pady=(10, 0))
        btn_row.columnconfigure((0, 1), weight=1, uniform="actions")

        buttons_spec = (
            (0, 0, "＋  Đăng ký", self.register_face, "primary"),
            (0, 1, "◎  Thêm mẫu mặt", self.add_samples, "secondary"),
            (1, 0, "✎  Sửa thông tin", self.edit_student, "secondary"),
            (1, 1, "✖  Xóa", self.delete_face, "danger"),
            (2, 0, "✋  Điểm danh thủ công", self.manual_mark, "secondary"),
            (2, 1, "↶  Hủy điểm danh", self.undo_mark, "danger"),
            (3, 0, "🖼  Đăng ký từ ảnh", self.register_from_images, "secondary"),
            (3, 1, "🖼  Thêm mẫu từ ảnh", self.add_samples_from_images, "secondary"),
        )

        for r, c, text, cmd, style in buttons_spec:

            theme.RoundedButton(
                btn_row,
                text,
                cmd,
                style,
                11,
                44
            ).grid(
                row=r,
                column=c,
                sticky="ew",
                padx=(0, 5) if c == 0 else (5, 0),
                pady=(0, 0) if r == 0 else (10, 0)
            )

        report_row = tk.Frame(right, bg=theme.BG)
        report_row.pack(fill="x", pady=(10, 0))
        report_row.columnconfigure((0, 1, 2), weight=1, uniform="reports")

        theme.RoundedButton(
            report_row,
            "▤  Thống kê",
            self.open_stats,
            "primary",
            11,
            44
        ).grid(row=0, column=0, sticky="ew", padx=(0, 4))

        theme.RoundedButton(
            report_row,
            "⇩  Xuất Excel",
            self.export_excel,
            "secondary",
            11,
            44
        ).grid(row=0, column=1, sticky="ew", padx=4)

        theme.RoundedButton(
            report_row,
            "☰  Nhật ký",
            self.open_audit,
            "secondary",
            11,
            44
        ).grid(row=0, column=2, sticky="ew", padx=(4, 0))

        # Lịch sử điểm danh trong phiên
        log_card = theme.Card(right, pady=12)
        log_card.pack(fill="both", expand=True, pady=(14, 0))

        log_head = tk.Frame(log_card.body, bg=theme.SURFACE)
        log_head.pack(fill="x", pady=(0, 8))

        tk.Label(
            log_head,
            text="ĐIỂM DANH HÔM NAY",
            bg=theme.SURFACE,
            fg=theme.MUTED,
            font=(theme.FONT, 9, "bold")
        ).pack(side="left")

        self.log_total = tk.Label(
            log_head,
            text="0 lượt",
            bg=theme.SURFACE,
            fg=theme.PRIMARY,
            font=(theme.FONT, 9, "bold")
        )
        self.log_total.pack(side="right")

        table = tk.Frame(log_card.body, bg=theme.SURFACE)
        table.pack(fill="both", expand=True)
        table.rowconfigure(0, weight=1)
        table.columnconfigure(0, weight=1)

        self.tree = ttk.Treeview(
            table,
            columns=("time", "name", "cls"),
            show="headings",
            selectmode="browse",
            height=4
        )

        for col, title, width, anchor in (
            ("time", "Giờ", 80, "w"),
            ("name", "Họ tên", 150, "w"),
            ("cls", "Lớp", 70, "w")
        ):
            self.tree.heading(col, text=title, anchor=anchor)
            self.tree.column(col, width=width, anchor=anchor)

        self.tree.tag_configure("odd", background=theme.SURFACE_ALT)
        self.tree.tag_configure("even", background="#FFFFFF")

        scroll = ttk.Scrollbar(
            table,
            orient="vertical",
            command=self.tree.yview
        )
        self.tree.configure(yscrollcommand=scroll.set)

        self.tree.grid(row=0, column=0, sticky="nsew")
        scroll.grid(row=0, column=1, sticky="ns")

        self.log_empty = tk.Label(
            self.tree,
            text="Chưa có lượt điểm danh nào",
            bg="#FFFFFF",
            fg=theme.MUTED,
            font=(theme.FONT, 10)
        )
        self.log_empty.place(relx=0.5, rely=0.55, anchor="center")

    # =====================================================
    # STATUS

    # =====================================================
    # TRẠNG THÁI
    # =====================================================
    def set_status(self, text, kind="info"):

        title, _, sub = text.partition("\n")

        self.status.set(
            kind,
            title.rstrip(":"),
            sub
        )

        if self.status_job is not None:

            try:
                self.root.after_cancel(self.status_job)
            except tk.TclError:
                pass

            self.status_job = None

        # Tự trở về trạng thái sẵn sàng sau 5 giây
        self.status_job = self.root.after(
            5000,
            self.reset_status
        )

    def reset_status(self):

        self.status_job = None

        if not self.running:
            return

        try:
            self.status.set(
                "idle",
                "Sẵn sàng",
                "Đưa khuôn mặt vào khung hình"
            )
        except tk.TclError:
            pass

    # =====================================================
    # THÔNG TIN NGƯỜI ĐANG NHẬN DIỆN

    # =====================================================
    # THÔNG TIN NGƯỜI ĐANG NHẬN DIỆN
    # =====================================================
    def set_info(
        self,
        name="—",
        lop="—",
        khoa="—",
        sid="",
        state="",
        state_fg=None
    ):

        key = (name, lop, khoa, sid, state, state_fg)

        # Chỉ vẽ lại khi có thay đổi (hàm này được gọi liên tục)
        if key == self._info_key:
            return

        self._info_key = key

        known = name != "—"

        if known:
            self.avatar.set(theme.initials(name), theme.PRIMARY)
        else:
            self.avatar.set("?", theme.BORDER, theme.MUTED)

        self.lbl_name.config(
            text=name if known else "Chưa nhận diện"
        )

        self.lbl_class.config(
            text=(
                f"Mã SV: {sid}  ·  Lớp: {lop or '—'}"
                if known else "Lớp: —"
            )
        )

        self.lbl_faculty.config(
            text=f"Khoa: {khoa or '—'}" if known else "Khoa: —"
        )

        self.lbl_state.config(
            text=state,
            fg=state_fg or theme.MUTED
        )

    def refresh_info(self):

        e = self.engine

        student = e.students.get(e.current_student)

        if not student:

            self.set_info()

            return

        sid = student["student_id"]

        if sid in e.marked_today:
            state, color = "✓ Đã điểm danh hôm nay", theme.SUCCESS

        elif e.require_liveness and not e.liveness_ok():
            state, color = "● Hãy chớp mắt để xác nhận", theme.PRIMARY

        else:
            state, color = "● Sẵn sàng điểm danh", theme.PRIMARY

        self.set_info(
            student["name"],
            student["class_name"],
            student["faculty"],
            sid,
            state,
            color
        )

    # =====================================================
    # LỊCH SỬ ĐIỂM DANH HÔM NAY
    # =====================================================
    def add_log(self, name, lop, time_str):

        self.log_count += 1

        self.log_empty.place_forget()

        self.tree.insert(
            "",
            0,
            values=(time_str, name, lop or "—"),
            tags=("odd" if self.log_count % 2 else "even",)
        )

        self.log_total.config(
            text=f"{self.log_count} lượt"
        )

    def load_today_log(self):
        """Hiện lại những người đã điểm danh hôm nay (sau khi mở lại app)."""

        for row in self.engine.today_log():
            self.add_log(row["name"], row["class_name"], row["time"])

    # =====================================================
    # VÒNG LẶP GIAO DIỆN (~30 khung/giây)
    # =====================================================
    def tick(self):

        if not self.running:
            return

        try:
            self._tick()

        except Exception:
            log.exception("Lỗi trong vòng cập nhật giao diện")

        if self.running:

            self.frame_job = self.root.after(
                33,
                self.tick
            )

    def _tick(self):

        frame, fid = self.pipeline.get_frame()
        rid, result = self.pipeline.get_result()

        # Có kết quả nhận diện mới -> đưa cho engine xử lý
        if result is not None and rid != self._last_rid:

            self._last_rid = rid
            self._small_w = result["small_w"]

            self.engine.process(result["dets"])

            self._dirty = True

        self.drain_events()

        self.refresh_info()

        if (
            frame is None
            or not self.pipeline.camera_ok
        ):

            if time.time() - self._started > 3:
                self.show_camera_message("Không có tín hiệu camera")

            return

        # Chỉ vẽ lại khi có khung hình mới hoặc kết quả mới
        if fid == self._last_fid and not self._dirty:
            return

        self._last_fid = fid
        self._dirty = False

        self.render(frame)

    def show_camera_message(self, text):

        if self._cam_msg:
            return

        self._cam_msg = True
        self._last_fid = -1

        self.cam_label.imgtk = None

        self.cam_label.config(
            image="",
            text=text,
            fg="#94A3B8",
            font=(theme.FONT, 13)
        )

    def render(self, frame):

        # frame đã được lật gương sẵn ở luồng camera, dạng BGR
        pil_image = Image.fromarray(
            np.ascontiguousarray(frame[:, :, ::-1])
        )

        # Thu phóng về đúng kích thước hiển thị TRƯỚC khi vẽ
        # để nét vẽ và chữ luôn sắc nét
        lbl_w = self.cam_label.winfo_width()
        lbl_h = self.cam_label.winfo_height()

        if lbl_w > 10 and lbl_h > 10:

            scale = min(
                lbl_w / pil_image.width,
                lbl_h / pil_image.height
            )

            pil_image = pil_image.resize(
                (
                    max(int(pil_image.width * scale), 1),
                    max(int(pil_image.height * scale), 1)
                ),
                Image.BILINEAR
            )

        small_w = self._small_w or max(
            int(frame.shape[1] * self.cfg.detect_scale),
            1
        )

        # Quy đổi từ ảnh nhỏ (dùng để nhận diện) sang ảnh hiển thị
        k = pil_image.width / small_w

        draw = ImageDraw.Draw(pil_image)

        for f in self.engine.faces:

            top, right, bottom, left = f["loc"]

            theme.draw_face_box(
                draw,
                left * k,
                top * k,
                right * k,
                bottom * k,
                f["label"],
                f["known"],
                self.font_label,
                pil_image.size
            )

        theme.draw_live_badge(draw, self.font_badge)

        imgtk = ImageTk.PhotoImage(image=pil_image)

        self.cam_label.imgtk = imgtk

        if self._cam_msg:
            self._cam_msg = False
            self.cam_label.config(text="")

        self.cam_label.configure(image=imgtk)

    # =====================================================
    # SỰ KIỆN TỪ ENGINE
    # =====================================================
    def drain_events(self):

        for ev in self.engine.pop_events():

            kind = ev[0]

            if kind == "status":
                self.set_status(ev[2], ev[1])

            elif kind == "attendance":
                self.add_log(ev[2], ev[3], ev[4])

            elif kind == "capture_finished":
                # Hiện hộp thoại ngoài vòng lặp để video không bị đứng
                self.root.after(
                    10,
                    lambda ok=ev[1], t=ev[2], m=ev[3]:
                        self.show_result(ok, t, m)
                )

    def show_result(self, ok, title, message):

        if not self.running:
            return

        if ok:
            messagebox.showinfo(title, message)
        else:
            messagebox.showwarning(title, message)

    # =====================================================
    # TÙY CHỌN
    # =====================================================
    def on_toggle_auto(self):

        self.engine.auto_attendance = self.var_auto.get()

        self.set_status(
            "Tự động điểm danh: "
            + ("BẬT" if self.engine.auto_attendance else "TẮT"),
            "info"
        )

    def on_toggle_live(self):

        self.engine.require_liveness = self.var_live.get()

        self.set_status(
            "Xác nhận người thật: "
            + ("BẬT" if self.engine.require_liveness else "TẮT"),
            "info"
        )

    # =====================================================
    # CÁC NÚT CHỨC NĂNG
    # =====================================================
    def mark_attendance(self):

        self.engine.manual_attendance()

        self.drain_events()

    def _confirm_cancel_capture(self):
        """Nếu đang thu mẫu thì hỏi hủy. Trả về True nếu đang thu mẫu."""

        if self.engine.capture is None:
            return False

        if messagebox.askyesno(
            "Đang thu mẫu",
            "Hủy việc thu mẫu đang thực hiện?"
        ):
            self.engine.cancel_capture("Đã hủy thu mẫu")

            self.drain_events()

        return True

    def register_face(self):

        if self._confirm_cancel_capture():
            return

        err = self.engine.check_can_register()

        if err:

            messagebox.showwarning("Cảnh báo", err)

            return

        dlg = RegisterDialog(self.root)

        self.root.wait_window(dlg)

        if not dlg.result:
            return

        # Khuôn mặt là dữ liệu sinh trắc học nhạy cảm: phải được đồng ý trước
        if not messagebox.askyesno(
            "Đồng ý thu thập dữ liệu",
            f"{dlg.result[1]} (Mã SV: {dlg.result[0]}) có đồng ý cho hệ thống "
            "thu thập và lưu đặc trưng khuôn mặt để điểm danh không?\n\n"
            "• Chỉ lưu vector đặc trưng, KHÔNG lưu ảnh khuôn mặt.\n"
            "• Có thể yêu cầu xóa dữ liệu bất cứ lúc nào."
        ):
            self.set_status("Đã hủy đăng ký\nChưa có sự đồng ý", "info")
            return

        err = self.engine.start_register(*dlg.result, consent=True)

        if err:
            messagebox.showwarning("Không thể đăng ký", err)

        self.drain_events()

    def _pick_student(self, title, subtitle, ok_text, ok_style):
        """Hiện hộp chọn sinh viên. Trả về dict sinh viên hoặc None."""

        students = self.db.list_students()

        if not students:

            messagebox.showinfo(
                "Thông báo",
                "Chưa có ai đăng ký trong hệ thống."
            )

            return None

        options = [
            f"{s['name']}  -  {s['student_id']}  -  {s['class_name']}"
            f"  ({s['samples']} mẫu)"
            for s in students
        ]

        dlg = PickerDialog(
            self.root,
            title,
            subtitle,
            options,
            ok_text,
            ok_style
        )

        self.root.wait_window(dlg)

        if dlg.result is None:
            return None

        return students[dlg.result]

    def add_samples(self):

        if self._confirm_cancel_capture():
            return

        err = self.engine.check_can_capture()

        if err:

            messagebox.showwarning("Cảnh báo", err)

            return

        target = self._pick_student(
            "Thêm mẫu khuôn mặt",
            "Chọn người đang đứng trước camera. Hệ thống sẽ thu thêm "
            "mẫu ở các góc mặt khác nhau để nhận diện chính xác hơn.",
            "Bắt đầu",
            "primary"
        )

        if target is None:
            return

        err = self.engine.start_add_samples(target["student_id"])

        if err:
            messagebox.showwarning("Không thể thêm mẫu", err)

        self.drain_events()

    # ---------- đăng ký bằng ảnh tải lên ----------
    def _encode_file(self, path):

        return vision.encode_image_file(
            path,
            self.detector.backend,
            min_face=80
        )

    def _pick_images(self, title):

        return filedialog.askopenfilenames(
            parent=self.root,
            title=title,
            filetypes=[("Ảnh", "*.jpg *.jpeg *.png *.bmp"), ("Tất cả", "*.*")]
        )

    @staticmethod
    def _notes_text(notes):

        if not notes:
            return ""

        return "\n\nLý do từng ảnh:\n" + "\n".join(notes[:12]) + (
            "\n..." if len(notes) > 12 else ""
        )

    def _show_upload_notes(self, notes):

        if notes:
            messagebox.showinfo(
                "Ảnh bị bỏ qua",
                "Các ảnh sau không dùng được:\n\n" + "\n".join(notes[:15])
                + ("\n..." if len(notes) > 15 else "")
            )

    def register_from_images(self):

        if self._confirm_cancel_capture():
            return

        dlg = RegisterDialog(
            self.root,
            "Đăng ký từ ảnh",
            "Điền thông tin rồi chọn 3-10 ảnh chân dung của người này "
            "(mỗi ảnh một mặt, nhìn rõ, nhiều góc/ánh sáng)."
        )

        self.root.wait_window(dlg)

        if not dlg.result:
            return

        if not messagebox.askyesno(
            "Đồng ý thu thập dữ liệu",
            f"{dlg.result[1]} (Mã SV: {dlg.result[0]}) có đồng ý cho hệ thống "
            "thu thập và lưu đặc trưng khuôn mặt từ ảnh này để điểm danh không?\n\n"
            "• Chỉ lưu vector đặc trưng, KHÔNG lưu ảnh.\n"
            "• Có thể yêu cầu xóa dữ liệu bất cứ lúc nào."
        ):
            return

        paths = self._pick_images(f"Chọn ảnh của {dlg.result[1]}")

        if not paths:
            return

        self.set_status("Đang xử lý ảnh...", "info")
        self.root.update_idletasks()

        err, notes = self.engine.enroll_from_images(
            *dlg.result, paths, self._encode_file, consent=True
        )

        if err:
            messagebox.showwarning(
                "Không thể đăng ký", err + self._notes_text(notes)
            )
            notes = []

        self.drain_events()
        self._show_upload_notes(notes)

    def add_samples_from_images(self):

        if self._confirm_cancel_capture():
            return

        target = self._pick_student(
            "Thêm mẫu từ ảnh",
            "Chọn người rồi chọn các ảnh chân dung của họ.",
            "Chọn ảnh",
            "primary"
        )

        if target is None:
            return

        paths = self._pick_images(f"Chọn ảnh của {target['name']}")

        if not paths:
            return

        self.set_status("Đang xử lý ảnh...", "info")
        self.root.update_idletasks()

        err, notes = self.engine.add_samples_from_images(
            target["student_id"], paths, self._encode_file
        )

        if err:
            messagebox.showwarning(
                "Không thể thêm mẫu", err + self._notes_text(notes)
            )
            notes = []

        self.drain_events()
        self._show_upload_notes(notes)

    def manual_mark(self):
        """Điểm danh thủ công khi nhận diện không dùng được (có ghi lý do)."""

        if self._confirm_cancel_capture():
            return

        target = self._pick_student(
            "Điểm danh thủ công",
            "Chỉ dùng khi nhận diện bằng khuôn mặt không được "
            "(khẩu trang, camera hỏng...). Lượt này được ghi nhật ký.",
            "Tiếp tục",
            "primary"
        )

        if target is None:
            return

        note = simpledialog.askstring(
            "Lý do",
            f"Lý do điểm danh thủ công cho {target['name']}:",
            parent=self.root
        )

        if note is None:
            return

        err = self.engine.mark_manual(target["student_id"], note)

        if err:
            messagebox.showwarning("Không thể điểm danh", err)

        self.drain_events()

    def undo_mark(self):
        """Hủy lượt điểm danh hôm nay bị ghi nhầm (chỉ quản trị)."""

        if not self._require_admin():
            return

        today = self.engine.today_log()

        if not today:
            messagebox.showinfo("Thông báo", "Hôm nay chưa có ai điểm danh.")
            return

        by_id = {r["student_id"]: r for r in today}

        students = [
            s for s in self.db.list_students() if s["student_id"] in by_id
        ]

        if not students:
            messagebox.showinfo("Thông báo", "Không có lượt nào để hủy.")
            return

        options = [
            f"{s['name']}  -  {s['student_id']}  -  "
            f"{by_id[s['student_id']]['time']}"
            for s in students
        ]

        dlg = PickerDialog(
            self.root,
            "Hủy điểm danh",
            "Chọn lượt điểm danh HÔM NAY cần hủy (ghi nhầm).",
            options,
            "Hủy lượt này",
            "danger"
        )

        self.root.wait_window(dlg)

        if dlg.result is None:
            return

        target = students[dlg.result]

        if not messagebox.askyesno(
            "Xác nhận",
            f"Hủy điểm danh hôm nay của\n{target['name']}?"
        ):
            return

        err = self.engine.unmark_today(target["student_id"])

        if err:
            messagebox.showwarning("Không thể hủy", err)
            return

        self.reload_today_log()
        self.drain_events()

    def reload_today_log(self):

        for item in self.tree.get_children():
            self.tree.delete(item)

        self.log_count = 0
        self.log_total.config(text="0 lượt")
        self.log_empty.place(relx=0.5, rely=0.55, anchor="center")

        self.load_today_log()

    def open_audit(self):
        """Xem nhật ký hoạt động gần đây (chỉ quản trị)."""

        if not self._require_admin():
            return

        win = tk.Toplevel(self.root)
        win.title("Nhật ký hoạt động")
        win.configure(bg=theme.BG)
        win.minsize(760, 420)

        theme.center_on_parent(win, self.root, 860, 520)

        labels = {
            "login_ok": "Đăng nhập",
            "login_failed": "Đăng nhập sai",
            "login_locked": "Bị khóa tạm",
            "student_registered": "Đăng ký SV",
            "samples_added": "Thêm mẫu mặt",
            "student_updated": "Sửa thông tin",
            "student_deleted": "Xóa SV",
            "attendance_manual": "Điểm danh thủ công",
            "attendance_removed": "Hủy điểm danh",
            "unknown_face": "Khuôn mặt lạ",
            "liveness_failed": "Nghi giả mạo",
            "export_excel": "Xuất Excel",
        }

        tree = ttk.Treeview(
            win,
            columns=("ts", "actor", "kind", "detail"),
            show="headings"
        )

        for col, title, width in (
            ("ts", "Thời gian", 150),
            ("actor", "Tài khoản", 100),
            ("kind", "Sự kiện", 150),
            ("detail", "Chi tiết", 420),
        ):
            tree.heading(col, text=title, anchor="w")
            tree.column(col, width=width, anchor="w")

        scroll = ttk.Scrollbar(win, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scroll.set)

        tree.pack(side="left", fill="both", expand=True, padx=(12, 0), pady=12)
        scroll.pack(side="right", fill="y", pady=12, padx=(0, 12))

        for ev in self.db.recent_events(300):
            tree.insert(
                "",
                "end",
                values=(
                    ev["ts"],
                    ev["actor"] or "—",
                    labels.get(ev["kind"], ev["kind"]),
                    ev["detail"]
                )
            )

    def _require_admin(self):

        if self.role == db.ROLE_ADMIN:
            return True

        messagebox.showwarning(
            "Không đủ quyền",
            "Chức năng này chỉ dành cho tài khoản quản trị."
        )

        return False

    def edit_student(self):

        if not self._require_admin():
            return

        target = self._pick_student(
            "Sửa thông tin",
            "Chọn sinh viên cần sửa họ tên, lớp hoặc khoa.",
            "Tiếp tục",
            "primary"
        )

        if target is None:
            return

        dlg = EditStudentDialog(self.root, target)

        self.root.wait_window(dlg)

        if not dlg.result:
            return

        try:
            self.engine.update_student(target["student_id"], *dlg.result)

        except sqlite3.Error as e:

            log.exception("Không sửa được sinh viên")

            messagebox.showerror("Lỗi", f"Không lưu được: {e}")

            return

        self.set_status(f"Đã cập nhật:\n{dlg.result[0]}", "success")

    def delete_face(self):

        if not self._require_admin():
            return

        target = self._pick_student(
            "Xóa đăng ký",
            "Dữ liệu khuôn mặt sẽ bị xóa. "
            "Lịch sử điểm danh vẫn được giữ lại.",
            "Xóa",
            "danger"
        )

        if target is None:
            return

        if not messagebox.askyesno(
            "Xác nhận",
            f"Bạn chắc chắn muốn xóa\n"
            f"{target['name']} - {target['student_id']}?"
        ):
            return

        try:
            self.engine.delete_student(target["student_id"])

        except sqlite3.Error as e:

            log.exception("Không xóa được sinh viên")

            messagebox.showerror("Lỗi", f"Không xóa được: {e}")

            return

        self.set_status(f"Đã xóa:\n{target['name']}", "info")

        messagebox.showinfo(
            "Thành công",
            f"Đã xóa đăng ký của {target['name']}"
        )

    def change_password(self):

        dlg = ChangePasswordDialog(self.root)

        self.root.wait_window(dlg)

        if not dlg.result:
            return

        old, new = dlg.result

        ok, _ = self.db.check_login(self.username, old)

        if not ok:

            messagebox.showerror(
                "Lỗi",
                "Mật khẩu hiện tại không đúng!"
            )

            return

        self.db.set_password(self.username, new)

        self.set_status("Đã đổi mật khẩu", "success")

        messagebox.showinfo(
            "Thành công",
            "Đã đổi mật khẩu. Lần đăng nhập sau hãy dùng mật khẩu mới."
        )

    def open_stats(self):

        win = getattr(self, "stats_win", None)

        if win is not None and win.exists():
            win.focus()
            return

        self.stats_win = StatsWindow(self.root, self.db, EXPORT_DIR)

    def export_excel(self):

        path = os.path.join(
            EXPORT_DIR,
            datetime.datetime.now().strftime("diemdanh_%Y%m%d_%H%M%S.xlsx")
        )

        try:

            os.makedirs(EXPORT_DIR, exist_ok=True)

            n_students, n_days = self.db.export_excel(path)

            self.db.log_event(
                "export_excel",
                os.path.basename(path),
                self.username
            )

        except Exception as e:

            log.exception("Không xuất được Excel")

            messagebox.showerror(
                "Lỗi",
                f"Không xuất được Excel: {e}"
            )

            return

        self.set_status(
            f"Đã xuất Excel\n{n_students} sinh viên · {n_days} ngày",
            "success"
        )

        messagebox.showinfo(
            "Thành công",
            f"Đã xuất báo cáo:\n{path}\n\n"
            f"{n_students} sinh viên · {n_days} ngày điểm danh"
        )

    # =====================================================
    # ĐÓNG / ĐĂNG XUẤT
    # =====================================================
    def shutdown(self):

        self.running = False

        for job in (self.frame_job, self.status_job):

            if job is not None:

                try:
                    self.root.after_cancel(job)
                except tk.TclError:
                    pass

        self.frame_job = None
        self.status_job = None

        win = getattr(self, "stats_win", None)

        if win is not None:
            win.close()

        self.pipeline.stop()

    def logout(self):

        confirm = messagebox.askyesno(
            "Đăng xuất",
            "Bạn có chắc chắn muốn đăng xuất?"
        )

        if not confirm:
            return

        # Dừng camera và các vòng lặp
        self.shutdown()

        # Xóa giao diện điểm danh
        for widget in self.root.winfo_children():
            widget.destroy()

        if self.cfg.kiosk:
            try:
                self.root.attributes("-fullscreen", False)
            except tk.TclError:
                pass

        # Quay về đăng nhập
        self.on_logout()

    def on_closing(self):

        self.shutdown()

        self.root.destroy()


# =========================================================
# CHƯƠNG TRÌNH
# =========================================================
class Application:

    def __init__(self):

        self.root = tk.Tk()

        theme.setup_styles(self.root)

        self.root.report_callback_exception = self.on_tk_error
        self._error_shown = False

        self.cfg = Config.load(BASE_DIR)

        try:
            cipher = secure.make_cipher(self.cfg, BASE_DIR)

        except Exception as e:

            log.exception("Không tạo được khóa mã hóa")

            if isinstance(e, ImportError):
                hint = ("Thiếu thư viện 'cryptography'.\n"
                        "Mở terminal và chạy:  pip install cryptography\n"
                        "(hoặc pip install -r requirements.txt) rồi mở lại.")
            else:
                hint = str(e)

            messagebox.showerror("Khóa mã hóa", hint)

            raise SystemExit(1)

        self.db = db.Database(DB_FILE, cipher=cipher)

        # Mã hóa các vector còn ở dạng thường (dữ liệu từ bản cũ)
        if cipher is not None:

            try:
                n = self.db.encrypt_existing()

                if n:
                    log.info("Đã mã hóa %d vector khuôn mặt", n)
                    self.db.log_event("encrypt_embeddings", f"{n} vector")

            except Exception:
                log.exception("Không mã hóa được dữ liệu cũ")

        # Xóa điểm danh quá hạn lưu giữ (nếu cấu hình)
        try:
            self.db.apply_retention(self.cfg.retention_days)

        except Exception:
            log.exception("Không áp dụng được chính sách lưu giữ")

        # Nhập dữ liệu từ bản cũ (pkl + xlsx) một lần duy nhất
        try:
            stats = self.db.migrate_legacy(
                os.path.join(BASE_DIR, "legacy_data")
            )

            if any(stats.values()):
                log.info("Đã chuyển dữ liệu cũ sang SQLite: %s", stats)

        except Exception:
            log.exception("Không chuyển được dữ liệu cũ")

        # Mỗi ngày sao lưu cơ sở dữ liệu một lần
        try:
            self.db.backup(BACKUP_DIR, self.cfg.backup_keep)

        except Exception:
            log.exception("Không sao lưu được cơ sở dữ liệu")

        try:
            self.db.prune_events(self.cfg.audit_keep)

        except Exception:
            log.exception("Không dọn được nhật ký")

        self.throttle = LoginThrottle(
            self.cfg.login_max_attempts,
            self.cfg.login_lock_seconds
        )

        self.current_app = None
        self.current_username = None

        self.show_login()

        self.root.mainloop()

        self.db.close()

    def on_tk_error(self, exc, val, tb):

        log.error("Lỗi chưa xử lý trong giao diện", exc_info=(exc, val, tb))

        # Chỉ báo một lần, tránh hiện dồn dập nếu lỗi lặp lại
        if not self._error_shown:

            self._error_shown = True

            messagebox.showerror(
                "Lỗi không mong muốn",
                f"{val}\n\nChi tiết đã được ghi vào logs/app.log"
            )

    def show_login(self):

        self.current_app = None

        LoginPage(
            self.root,
            self.db,
            self.login_success,
            self.throttle
        )

    def login_success(self, username, role):

        self.current_username = username

        # Xóa toàn bộ giao diện đăng nhập trước khi vào màn hình điểm danh
        for widget in self.root.winfo_children():
            widget.destroy()

        self.current_app = FaceRecognitionApp(
            self.root,
            username,
            role,
            self.db,
            self.cfg,
            self.logout_success
        )

    def logout_success(self):

        self.current_app = None
        self.current_username = None

        self.root.protocol(
            "WM_DELETE_WINDOW",
            self.root.destroy
        )

        self.show_login()