"""Camera và nhận diện chạy ở luồng riêng, giao diện chỉ việc lấy kết quả mới nhất.

  luồng 1 (capture): đọc camera liên tục -> giữ khung hình mới nhất
  luồng 2 (detect) : lấy khung mới nhất -> tìm mặt + mã hóa -> giữ kết quả mới nhất
  giao diện        : mỗi ~30ms lấy khung hình + kết quả mới nhất để vẽ

Nhờ vậy hình camera luôn mượt dù nhận diện chậm.
"""

import logging
import sys
import threading

import numpy as np

import liveness
from recognizer import face_area

log = logging.getLogger(__name__)


class VisionPipeline:

    def __init__(self, open_camera, detect, flip=True, reopen_every=2.0):
        """
        open_camera: hàm không tham số trả về đối tượng giống cv2.VideoCapture
        detect     : hàm nhận khung BGR, trả về
                     {"dets": [{"loc","enc","ear"}...], "small_w", "small_h"}
        """

        self._open = open_camera
        self._detect = detect
        self._flip = flip
        self._reopen_every = reopen_every

        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._threads = []

        self._frame = None
        self._frame_id = 0
        self._result = None
        self._result_id = 0
        self._camera_ok = False

    # -----------------------------------------------------
    def start(self):

        self._stop.clear()

        self._threads = [
            threading.Thread(
                target=self._capture_loop,
                name="capture",
                daemon=True
            ),
            threading.Thread(
                target=self._detect_loop,
                name="detect",
                daemon=True
            ),
        ]

        for t in self._threads:
            t.start()

    def stop(self):

        self._stop.set()

        for t in self._threads:
            t.join(timeout=3)

        self._threads = []

    # -----------------------------------------------------
    @property
    def camera_ok(self):
        return self._camera_ok

    def get_frame(self):
        """(khung BGR mới nhất hoặc None, số thứ tự khung)."""

        with self._lock:
            return self._frame, self._frame_id

    def get_result(self):
        """(số thứ tự kết quả, kết quả nhận diện mới nhất hoặc None)."""

        with self._lock:
            return self._result_id, self._result

    # -----------------------------------------------------
    def _capture_loop(self):

        cap = None
        fails = 0

        try:

            while not self._stop.is_set():

                if cap is None:

                    try:
                        cap = self._open()
                    except Exception:
                        log.exception("Lỗi khi mở camera")
                        cap = None

                    if cap is None or not cap.isOpened():

                        if cap is not None:
                            cap.release()

                        cap = None
                        self._camera_ok = False

                        self._stop.wait(self._reopen_every)

                        continue

                    log.info("Đã mở camera")
                    fails = 0

                ret, frame = cap.read()

                if not ret or frame is None:

                    fails += 1

                    if fails >= 30:
                        log.warning("Mất tín hiệu camera, thử mở lại")
                        self._camera_ok = False
                        cap.release()
                        cap = None

                    self._stop.wait(0.03)

                    continue

                fails = 0
                self._camera_ok = True

                if self._flip:
                    frame = np.ascontiguousarray(frame[:, ::-1])

                with self._lock:
                    self._frame = frame
                    self._frame_id += 1

                self._stop.wait(0.001)

        finally:

            if cap is not None:
                try:
                    cap.release()
                except Exception:
                    pass

            self._camera_ok = False

    def _detect_loop(self):

        last_id = -1

        while not self._stop.is_set():

            frame, fid = self.get_frame()

            if frame is None or fid == last_id:
                self._stop.wait(0.01)
                continue

            last_id = fid

            try:
                result = self._detect(frame)

            except Exception:
                log.exception("Lỗi khi nhận diện khuôn mặt")
                self._stop.wait(0.2)
                continue

            with self._lock:
                self._result = result
                self._result_id += 1


# =========================================================
# TRIỂN KHAI THẬT (dùng OpenCV + face_recognition)
# =========================================================
def open_camera(index, width, height):

    import cv2

    # DirectShow mở camera trên Windows nhanh hơn hẳn backend mặc định
    backend = cv2.CAP_DSHOW if sys.platform.startswith("win") else cv2.CAP_ANY

    cap = cv2.VideoCapture(index, backend)

    if cap.isOpened():
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)

    return cap


def face_quality(gray_small, loc):
    """Độ nét + độ sáng của vùng mặt (ảnh xám đã thu nhỏ).

    sharp : phương sai Laplacian, càng thấp càng mờ
    bright: độ sáng trung bình 0-255
    Trả về None nếu vùng mặt quá nhỏ để đo.
    """

    # Đo chất lượng chỉ là phụ trợ: lỗi ở đây không được làm hỏng nhận diện
    try:
        import cv2

        top, right, bottom, left = loc

        h, w = gray_small.shape[:2]

        crop = gray_small[
            max(top, 0):min(bottom, h),
            max(left, 0):min(right, w)
        ]

        if crop.shape[0] < 8 or crop.shape[1] < 8:
            return None

        return {
            "sharp": float(cv2.Laplacian(crop, cv2.CV_64F).var()),
            "bright": float(crop.mean())
        }

    except Exception:
        log.exception("Không đo được chất lượng ảnh")
        return None


class FaceDetector:
    """Tìm mặt + mã hóa trên ảnh thu nhỏ.

    Mỗi khuôn mặt có thêm chỉ số chất lượng ảnh. Với `max_faces` khuôn mặt lớn
    nhất còn có ear (mắt), mar (miệng), yaw (quay đầu) để kiểm tra người thật,
    và spoof (xác suất người thật 0-1) nếu có mô hình chống giả mạo thụ động.
    """

    def __init__(
        self, scale=0.5, with_ear=True, backend=None, antispoof=None,
        max_faces=1
    ):

        import backends

        self.scale = scale
        self.with_ear = with_ear
        self.backend = backend or backends.DlibBackend()
        self.antispoof = antispoof
        self.max_faces = max(1, max_faces)

    def __call__(self, frame_bgr):

        import cv2
        import face_recognition as fr

        small = cv2.resize(frame_bgr, (0, 0), fx=self.scale, fy=self.scale)

        rgb_small = np.ascontiguousarray(small[:, :, ::-1])

        locations = fr.face_locations(rgb_small)

        inv = 1.0 / self.scale

        def to_full(loc):
            t, r, b, l = loc
            return (int(t * inv), int(r * inv), int(b * inv), int(l * inv))

        rgb_full = None

        if self.backend.needs_full_res and locations:
            # Căn chỉnh khuôn mặt cần độ phân giải gốc, ảnh thu nhỏ quá thô
            rgb_full = np.ascontiguousarray(frame_bgr[:, :, ::-1])
            encodings = self.backend.encode(
                rgb_full, [to_full(loc) for loc in locations]
            )
        else:
            encodings = self.backend.encode(rgb_small, locations)

        gray_small = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)

        dets = [
            {
                "loc": loc,
                "enc": enc,
                "ear": None,
                "mar": None,
                "yaw": None,
                "spoof": None,
                "quality": face_quality(gray_small, loc)
            }
            for loc, enc in zip(locations, encodings)
            if enc is not None          # không căn chỉnh được -> bỏ qua khuôn mặt đó
        ]

        if not dets:
            return {
                "dets": dets,
                "small_w": small.shape[1],
                "small_h": small.shape[0]
            }

        biggest = sorted(
            dets, key=lambda d: face_area(d["loc"]), reverse=True
        )[: self.max_faces]

        if self.with_ear:

            full_locs = [to_full(d["loc"]) for d in biggest]

            if rgb_full is None:
                # Mắt rất nhỏ nên lấy điểm mốc trên ảnh gốc cho chính xác
                rgb_full = np.ascontiguousarray(frame_bgr[:, :, ::-1])

            marks = fr.face_landmarks(rgb_full, full_locs)

            for det, mk in zip(biggest, marks):
                pose = liveness.face_pose(mk)
                det["ear"] = pose["ear"]
                det["mar"] = pose["mar"]
                det["yaw"] = pose["yaw"]

        if self.antispoof is not None:

            for det in biggest:

                t, r, b, l = to_full(det["loc"])

                try:
                    det["spoof"] = self.antispoof.real_probability(
                        frame_bgr, [l, t, r, b]
                    )
                except Exception:
                    log.exception("Lỗi mô hình chống giả mạo")

        return {
            "dets": dets,
            "small_w": small.shape[1],
            "small_h": small.shape[0]
        }


def encode_image_file(path, backend, min_face=90, max_side=1600):
    """Tạo vector khuôn mặt từ MỘT file ảnh (đăng ký bằng ảnh tải lên).

    Trả về {"enc", "problem", "quality"}: enc=None kèm problem (chuỗi) nếu ảnh
    không dùng được. Chỉ nhận ảnh có ĐÚNG một khuôn mặt, đủ lớn.
    Đọc bằng imdecode nên đường dẫn có dấu tiếng Việt vẫn mở được trên Windows.
    """

    import cv2
    import face_recognition as fr

    def fail(msg):
        return {"enc": None, "problem": msg, "quality": None}

    try:
        data = np.fromfile(path, dtype=np.uint8)
        img = cv2.imdecode(data, cv2.IMREAD_COLOR)
    except Exception:
        img = None

    if img is None:
        return fail("Không đọc được file ảnh")

    h, w = img.shape[:2]

    if max(h, w) > max_side:
        k = max_side / float(max(h, w))
        img = cv2.resize(img, (0, 0), fx=k, fy=k, interpolation=cv2.INTER_AREA)

    rgb = np.ascontiguousarray(img[:, :, ::-1])

    locs = fr.face_locations(rgb)

    if not locs:
        return fail("Không thấy khuôn mặt")

    if len(locs) > 1:
        return fail(f"Có {len(locs)} khuôn mặt trong ảnh (chỉ nhận ảnh 1 người)")

    top, right, bottom, left = locs[0]

    if right - left < min_face:
        return fail(f"Khuôn mặt quá nhỏ ({right - left}px), cần ít nhất {min_face}px")

    enc = backend.encode(rgb, locs)[0]

    if enc is None:
        return fail("Không căn chỉnh được khuôn mặt (nghiêng/che quá nhiều)")

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # Độ nét đo trên mặt đã thu về cỡ ~ khuôn mặt từ camera để dùng chung ngưỡng
    face = gray[top:bottom, left:right]
    side = 100
    face = cv2.resize(face, (side, side), interpolation=cv2.INTER_AREA)

    return {
        "enc": enc,
        "problem": None,
        "quality": face_quality(face, (0, side, side, 0))
    }