# Đánh giá hệ thống điểm danh khuôn mặt và các cải tiến

## 1. Điểm mạnh của hệ thống gốc
- Kiến trúc tách lớp: `engine.py` (nghiệp vụ) không phụ thuộc giao diện/camera nên kiểm thử được (94 test gốc).
- Nhận diện thận trọng: ngưỡng khoảng cách 0,5 + biên 0,04 giữa hai người + xác nhận ≥ 4/6 khung + khuôn mặt hiện tại phải trùng người đã xác nhận.
- Đa luồng (capture / detect / UI) nên hình mượt.
- SQLite có ràng buộc UNIQUE(student_id, day), giao dịch, sao lưu mỗi ngày; mật khẩu PBKDF2 có muối, khóa tạm khi nhập sai.
- Chống trùng khi đăng ký (một khuôn mặt không đăng ký được hai lần), xóa mềm giữ lịch sử, phân quyền admin/giảng viên.
- Chạy cục bộ trên CPU, không cần máy chủ; lưu vector đặc trưng chứ không lưu ảnh (tốt cho riêng tư).

## 2. Thiếu sót tìm thấy và cách xử lý

| # | Thiếu sót | Mức | Xử lý trong bản này |
|---|---|---|---|
| 1 | Chống giả mạo chỉ bằng chớp mắt: video quay sẵn vẫn qua được | Cao | Thêm chế độ **thử thách ngẫu nhiên** (`liveness_mode: challenge`): chuỗi động tác ngẫu nhiên quay trái/phải, há miệng, chớp mắt; phải làm sau khi được yêu cầu, quá hạn thì đổi chuỗi |
| 2 | Thống kê sai: sinh viên đăng ký muộn bị tính vắng cả các buổi trước khi vào | Cao (sai số liệu) | Chỉ tính từ ngày đăng ký (hoặc buổi điểm danh đầu tiên nếu dữ liệu nhập từ bản cũ); Excel ghi "—" |
| 3 | Excel: họ tên bắt đầu bằng "=" bị openpyxl ghi thành **công thức** (formula injection) | Cao (bảo mật) | Ép mọi ô về dạng chuỗi |
| 4 | Không có nhật ký hoạt động: không biết ai đăng nhập sai, ai sửa/xóa sinh viên, có người lạ trước camera | Trung bình | Bảng `audit_log` + màn hình **Nhật ký** (admin); ghi khuôn mặt lạ có giới hạn tần suất, nghi giả mạo, đăng nhập |
| 5 | Chỉ điểm danh được bằng nhận diện: đeo khẩu trang/camera hỏng thì không điểm danh được | Trung bình | **Điểm danh thủ công** bắt buộc nhập lý do + lưu người ghi; **Hủy điểm danh** khi ghi nhầm (admin) |
| 6 | Không phân biệt đi muộn | Trung bình | `class_start` + `late_after_minutes`; trạng thái `late`, hiện trong Excel và thống kê |
| 7 | Mẫu đăng ký có thể mờ/tối/ngược sáng, làm giảm độ chính xác mãi về sau | Trung bình | Kiểm tra độ nét và độ sáng khi thu mẫu, báo người dùng chỉnh |
| 8 | Thu dữ liệu sinh trắc học không có bước đồng ý (README tự nhắc nhưng app không thực hiện) | Trung bình (pháp lý) | Hộp thoại đồng ý khi đăng ký, lưu `consent_at` |
| 9 | Không kiểm tra định dạng mã SV/họ tên | Thấp | Mã 3–20 ký tự chữ/số/-/_, họ tên ≤ 100 ký tự, không ký tự điều khiển |
| 10 | Bản sao lưu không được kiểm tra có đọc được không | Thấp | `PRAGMA integrity_check` sau khi sao lưu |
| 11 | CSDL cũ không có cột mới | — | Tự nâng cấp bằng `ALTER TABLE`, không mất dữ liệu (đã thử trên `diemdanh.db` của bạn) |

## 3. So sánh với hệ thống điểm danh khuôn mặt truyền thống

"Truyền thống" ở đây là kiểu phổ biến trong giáo trình/dự án mẫu dùng `face_recognition` (quyết định theo một khung hình, không đăng nhập, lưu CSV/Excel, không chống giả) và các thiết bị thương mại.

| Tiêu chí | Truyền thống | Hệ thống của bạn (gốc) | Sau cải tiến |
|---|---|---|---|
| Quyết định nhận diện | 1 khung hình | Ngưỡng + biên + bỏ phiếu 4/6 | Giữ nguyên |
| Chống ảnh in/màn hình | Không | Chớp mắt | Chớp mắt hoặc chuỗi thử thách |
| Chống video quay sẵn | Không (thiết bị thương mại dùng camera 3D/IR) | Không | Có (chế độ challenge), chưa chống deepfake trực tiếp/mặt nạ 3D |
| Lưu trữ | CSV/Excel/pkl | SQLite, giao dịch, sao lưu | + kiểm tra sao lưu, migration |
| Tài khoản & phân quyền | Thường không | Có, băm mật khẩu | + nhật ký đăng nhập |
| Truy vết (audit) | Không | Không | Có |
| Trường hợp ngoại lệ (khẩu trang, lỗi) | Không có lối thoát | Chỉ còn cách điểm danh bằng mặt | Điểm danh thủ công có lý do, hủy lượt ghi nhầm |
| Đi muộn | Thường có | Không | Có |
| Chất lượng mẫu đăng ký | Thường không kiểm | Không | Có |
| Thống kê/báo cáo | Ít khi có | Có, nhưng sai với SV vào muộn | Đúng theo ngày đăng ký |
| Đồng ý sinh trắc học | Hiếm | Không | Có |
| Nhiều người cùng lúc | Thường có | Chỉ khuôn mặt lớn nhất | Chưa (xem mục 4) |
| Nhiều ca/ngày, thời khóa biểu | Thiết bị thương mại có | Không | Chưa |
| Nhiều máy dùng chung dữ liệu | Thiết bị thương mại có | Không | Chưa |

## 4. Còn thiếu (chưa làm, cần ưu tiên theo thứ tự)
1. **Hiệu chỉnh trên camera thật**: ngưỡng `challenge_yaw`, `challenge_mar`, `min_sharpness`, `match_threshold` mới được kiểm bằng dữ liệu giả lập. Cần đo FAR/FRR trên dữ liệu lớp thật trước khi bật `challenge` làm mặc định. Giao diện mới cũng chưa chạy thử vì môi trường làm việc không có Tkinter và camera.
2. **Điểm danh nhiều người cùng lúc**: cần theo dõi từng khuôn mặt (tracking) và đo người thật riêng cho từng người.
3. **Nhiều ca trong ngày / thời khóa biểu / học phần**: cần đổi ràng buộc UNIQUE sang (student_id, day, session) và thêm bảng lớp học phần.
4. **Mã hóa cơ sở dữ liệu** (vector khuôn mặt hiện lưu thô), chính sách xóa dữ liệu theo thời hạn (Nghị định 13/2023/NĐ-CP coi dữ liệu sinh trắc học là dữ liệu nhạy cảm).
5. **Chống giả mạo mức cao** (mô hình anti-spoofing CNN hoặc camera IR/chiều sâu) nếu dùng cho thi cử.
6. Mô hình Client-Server để nhiều máy dùng chung dữ liệu.

## 5. Phiên bản 3: những gì đã làm (đối chiếu mục 4)

- Đo lường: `tools/evaluate.py` (FAR/FRR/EER, `--backend dlib|arcface`), `tools/eval_spoof.py` (APCER/BPCER).
- Chống giả mạo thụ động MiniFASNet, kết hợp với thử thách ngẫu nhiên.
- Backend ArcFace (w600k_mbf) cạnh dlib; vector lưu kèm tên mô hình.
- Theo dõi nhiều khuôn mặt (IoU tracker), mỗi người có trạng thái xác minh riêng.
- Nhiều ca/ngày (timetable), mã hóa AES-256-GCM vector khuôn mặt, tự xóa dữ liệu quá hạn, kiosk, API chỉ-đọc.
- 230 bài kiểm thử tự động, gồm thử nghiệm với mô hình thật trên ảnh mẫu.

## 6. Giới hạn trung thực

- Chưa được kiểm thử trên camera thật, giao diện Tkinter, hay ảnh tấn công thật (ảnh in, video phát lại).
- Ngưỡng ArcFace và chống giả mạo là giá trị khởi đầu, phải hiệu chỉnh bằng dữ liệu của chính lớp học.
- Không có hệ thống nào "hoàn hảo": camera RGB đơn không chặn được mọi tấn công (mặt nạ, video giả tạo bằng AI).
  Nếu cần an toàn cao, dùng thêm camera hồng ngoại/chiều sâu hoặc giám sát có người.
- Mất `data.key` = mất toàn bộ vector khuôn mặt, phải đăng ký lại.
- Dữ liệu `reports/eval_20261107_172310.md` trước đó nghi ngờ gán nhãn sai; cần thu lại dữ liệu sạch.
