# Hệ thống điểm danh tự động bằng nhận diện khuôn mặt

## Cài đặt và chạy
```
pip install -r requirements.txt
python main.py
```
Dữ liệu cũ của bạn (tài khoản, sinh viên, lịch sử điểm danh) đã nằm sẵn trong `diemdanh.db`.

## Cấu trúc
| File | Vai trò |
|---|---|
| `main.py` | Điểm vào, cấu hình log, kiểm tra thư viện |
| `app.py` | Toàn bộ giao diện (tkinter) |
| `engine.py` | Logic điểm danh: xác nhận nhiều khung, chớp mắt, thu mẫu, đăng ký |
| `vision.py` | Camera + nhận diện chạy ở luồng riêng (giao diện không bị giật) |
| `recognizer.py` | So khớp khuôn mặt, xác nhận ổn định |
| `liveness.py` | Chống giả mạo: chớp mắt (EAR) và thử thách ngẫu nhiên (quay đầu, há miệng) |
| `db.py` | SQLite: tài khoản, sinh viên, mẫu mặt, điểm danh, xuất Excel, sao lưu |
| `auth.py` | Băm mật khẩu PBKDF2, khóa tạm khi nhập sai nhiều lần |
| `config.py` | Cấu hình (ghi đè bằng `config.json`, xem `config.example.json`) |
| `theme.py` | Giao diện dùng chung |
| `tests/` | 135 test tự động |

## Cách hoạt động
- **Điểm danh tự động:** đứng trước camera, khi hệ thống nhận ra bạn ổn định qua nhiều khung hình
  và bạn chớp mắt một lần thì tự ghi điểm danh. Nút **Điểm danh** vẫn dùng được như phương án dự phòng.
  Mỗi người chỉ điểm danh 1 lần/ngày.
- **Đăng ký:** nhập Mã SV, họ tên, lớp, khoa rồi làm theo hướng dẫn trên màn hình (5 mẫu ở các góc đầu khác nhau).
  **Thêm mẫu mặt** để bổ sung cho người đã có (mẫu mới phải thật sự khớp với người đó).
- **Phân quyền:** tài khoản đầu tiên của hệ thống là quản trị (sửa, xóa). Tài khoản tạo thêm là giảng viên
  (đăng ký, thêm mẫu, điểm danh, xuất Excel).
- **Xóa:** xóa mềm, dữ liệu khuôn mặt bị xóa nhưng lịch sử điểm danh được giữ lại.
- **Thống kê & Báo cáo:** nút **Thống kê** mở cửa sổ lọc theo khoảng ngày, hiện số sinh viên, số buổi, chuyên cần trung bình,
  số người cần nhắc nhở (dưới 70%), bảng theo sinh viên, bảng và biểu đồ theo ngày. "Buổi" là một ngày có ít nhất một lượt điểm danh.
- **Xuất Excel:** file mới trong `exports/` gồm 3 sheet: `Diem Danh` (mỗi ngày một cột, vắng ghi "Vắng"),
  `Tong Hop` (chuyên cần và xếp loại từng sinh viên), `Theo Ngay` (số người có mặt mỗi ngày).
- **Sao lưu:** mỗi ngày một bản `diemdanh.db` vào `backups/` (được kiểm tra toàn vẹn), giữ 7 bản gần nhất.
- **Log:** `logs/app.log`.

## Tính năng bổ sung (phiên bản 2)
- **Chống video giả bằng thử thách ngẫu nhiên:** đặt `"liveness_mode": "challenge"`. Hệ thống yêu cầu
  `challenge_steps` động tác ngẫu nhiên khác nhau (quay trái, quay phải, há miệng, chớp mắt); video quay sẵn
  không biết trước động tác nên không qua được. Mặc định vẫn là `blink`; chỉ chuyển sang `challenge` sau khi
  đã thử và chỉnh `challenge_yaw`, `challenge_mar` trên camera thật của lớp.
- **Đi muộn:** đặt `"class_start": "07:30"` và `late_after_minutes`; ai điểm danh sau mốc này được ghi "đi muộn"
  (chữ cam trong Excel, có cột "Đi muộn" ở sheet Tong Hop và Theo Ngay).
- **Điểm danh thủ công** (khẩu trang, camera hỏng...): bắt buộc nhập lý do, lưu người ghi. **Hủy điểm danh** (quản trị) khi ghi nhầm.
- **Nhật ký hoạt động** (nút ☰, quản trị): đăng nhập đúng/sai/bị khóa, đăng ký/sửa/xóa sinh viên, điểm danh thủ công,
  khuôn mặt lạ trước camera, nghi giả mạo, xuất Excel.
- **Chất lượng ảnh khi đăng ký:** từ chối mẫu quá mờ, quá tối hoặc ngược sáng (`min_sharpness`, `min_brightness`, `max_brightness`).
- **Đồng ý sinh trắc học:** khi đăng ký phải xác nhận sinh viên đồng ý; thời điểm đồng ý được lưu.
- **Thống kê công bằng:** sinh viên mới vào không bị tính vắng các buổi trước ngày đăng ký (Excel ghi "—").
- **An toàn dữ liệu:** kiểm tra mã SV/họ tên khi đăng ký; Excel không còn chạy công thức do tên bắt đầu bằng "=".
- CSDL cũ tự động được nâng cấp (thêm cột), không mất dữ liệu.

## Chỉnh cấu hình
Copy `config.example.json` thành `config.json` và sửa những giá trị cần đổi, ví dụ:
```
{"match_threshold": 0.45, "camera_index": 1, "require_liveness": false}
```

## Kiểm thử (không cần camera)
```
python -m unittest discover -s tests -t .
```

## Giới hạn cần biết
- Chỉ chớp mắt chặn được **ảnh tĩnh** nhưng **không chặn được video quay sẵn**. Chế độ `challenge` chặn được video
  quay sẵn nhưng vẫn **chưa** chống được người thật dùng video deepfake tương tác trực tiếp hay mặt nạ 3D;
  mức an toàn cao hơn cần camera chiều sâu/hồng ngoại hoặc mô hình anti-spoofing chuyên dụng.
- Mỗi lần chỉ điểm danh khuôn mặt **lớn nhất** trong khung hình (từng người bước lên lần lượt).
- Đơn vị thống kê là ngày, chưa có thời khóa biểu hay chia nhiều buổi trong một ngày.
- Ngưỡng nhận diện (`match_threshold`, `match_margin`) là giá trị mặc định chung, nên đo lại bằng dữ liệu thật của lớp.
- Dữ liệu khuôn mặt là dữ liệu sinh trắc học nhạy cảm: giữ `diemdanh.db` và `backups/` cẩn thận,
  và chỉ thu thập khi người dùng đồng ý.

## Phiên bản 3 (tất cả TÙY CHỌN, mặc định giữ hành vi cũ)

| Tính năng | Bật bằng (config.json) | Cần làm trước |
|---|---|---|
| Nhận diện ArcFace 512 chiều | `"backend": "arcface"` | `python tools/get_models.py`, đăng ký lại khuôn mặt |
| Chống giả mạo thụ động (MiniFASNet) | `"antispoof_enable": true` | `get_models.py`, rồi `tools/eval_spoof.py` để chọn ngưỡng |
| Nhiều người cùng lúc | `"max_faces": 3` | không |
| Nhiều ca trong ngày | `"timetable": "Ca sáng|07:00|11:30;Ca chiều|13:00|17:00"` | không |
| Mã hóa vector khuôn mặt | `"encrypt_embeddings": true` (mặc định) | **sao lưu `data.key` riêng** |
| Tự xóa điểm danh cũ | `"retention_days": 365` | không |
| Chế độ kiosk toàn màn hình | `"kiosk": true` | không |
| API chỉ-đọc | `python tools/serve_api.py` | đặt `FACE_API_TOKEN` |

Vector của các mô hình khác nhau KHÔNG so sánh được; mỗi mẫu lưu kèm tên mô hình.
Đổi `backend` nghĩa là phải đăng ký lại (dùng "Thêm mẫu" cho từng người).

Quy trình khuyến nghị: `tools/collect.py` thu ảnh -> `tools/evaluate.py dataset --backend dlib`
và `--backend arcface` -> chọn mô hình/ngưỡng theo báo cáo -> mới đưa vào dùng thật.
Ngưỡng ArcFace (1.0 / 0.05) và chống giả mạo (0.7) là giá trị khởi đầu CHƯA hiệu chỉnh.

Giấy phép: kiểm tra điều khoản của mô hình InsightFace (buffalo_s) và MiniFASNet trước khi dùng thương mại.
Dữ liệu sinh trắc học là dữ liệu cá nhân nhạy cảm (Nghị định 13/2023/NĐ-CP): cần sự đồng ý của người được đăng ký.

## Đăng ký bằng ảnh tải lên (không cần camera)

Nút **Đăng ký từ ảnh** (người mới) và **Thêm mẫu từ ảnh** (người đã có). Chọn 3-10 ảnh chân dung.
Hệ thống chỉ nhận ảnh có đúng 1 mặt, đủ lớn/nét/sáng, và tự loại ảnh không giống các ảnh còn lại
(nhầm người). Ảnh bị loại được liệt kê kèm lý do. Chỉ lưu vector, không lưu ảnh.
Lưu ý: đăng ký bằng ảnh không có bước kiểm tra người thật, nên chỉ quản trị viên được dùng
và phải có sự đồng ý của người trong ảnh. Mọi lần đăng ký đều ghi vào nhật ký hoạt động.
Ảnh nên chụp bằng chính camera/điều kiện sáng khi điểm danh để nhận diện chính xác nhất.
