"""
Bộ giao diện dùng chung cho hệ thống điểm danh tự động bằng nhận diện khuôn mặt.

Gồm: bảng màu, nút bo góc, ô nhập liệu, thẻ (card), banner trạng thái,
đồng hồ, hộp thoại chuẩn và các hàm vẽ khung khuôn mặt bằng PIL.
Chỉ dùng tkinter + Pillow, không cần cài thêm thư viện.
"""

import datetime
import tkinter as tk
from tkinter import ttk

from PIL import ImageFont


# =========================================================
# BẢNG MÀU + FONT
# =========================================================
BG = "#F1F5F9"
SURFACE = "#FFFFFF"
SURFACE_ALT = "#F8FAFC"
BORDER = "#E2E8F0"

TEXT = "#0F172A"
MUTED = "#64748B"

NAVY = "#0F1B3D"
NAVY_MUTED = "#93A4C7"
ACCENT = "#38BDF8"

PRIMARY = "#2563EB"
PRIMARY_H = "#1D4ED8"
PRIMARY_SOFT = "#EAF1FF"

SUCCESS = "#16A34A"
SUCCESS_H = "#15803D"
SUCCESS_SOFT = "#E7F7EC"

DANGER = "#DC2626"
DANGER_H = "#B91C1C"
DANGER_SOFT = "#FDECEC"

SECONDARY = "#E8EDF5"
SECONDARY_H = "#D8E0EC"

CAMERA_BG = "#0B1220"

FONT = "Segoe UI"


# =========================================================
# TIỆN ÍCH CỬA SỔ
# =========================================================
def center_on_screen(win, w, h):
    """Đặt cửa sổ ở giữa màn hình (tự thu nhỏ nếu màn hình quá bé)."""
    sw, sh = win.winfo_screenwidth(), win.winfo_screenheight()
    w = min(w, sw - 80)
    h = min(h, sh - 120)
    x = max((sw - w) // 2, 0)
    y = max((sh - h) // 2 - 20, 0)
    win.geometry(f"{w}x{h}+{x}+{y}")


def center_on_parent(win, parent, w, h):
    """Đặt hộp thoại ở giữa cửa sổ cha."""
    parent.update_idletasks()
    x = parent.winfo_x() + (parent.winfo_width() - w) // 2
    y = parent.winfo_y() + (parent.winfo_height() - h) // 2
    win.geometry(f"{w}x{h}+{max(x, 0)}+{max(y, 0)}")


def initials(name):
    """'Nguyễn Văn An' -> 'NA'."""
    parts = [p for p in str(name).split() if p]
    if not parts:
        return "?"
    if len(parts) == 1:
        return parts[0][0].upper()
    return (parts[0][0] + parts[-1][0]).upper()


def setup_styles(root):
    """Style cho các widget ttk (Combobox, Treeview, Scrollbar)."""
    style = ttk.Style(root)

    try:
        style.theme_use("clam")
    except tk.TclError:
        pass

    style.configure(
        "TCombobox",
        padding=6,
        fieldbackground="#FFFFFF",
        background="#FFFFFF",
        bordercolor=BORDER,
        lightcolor=BORDER,
        darkcolor=BORDER,
        arrowsize=16
    )

    style.configure(
        "Treeview",
        background="#FFFFFF",
        fieldbackground="#FFFFFF",
        foreground=TEXT,
        rowheight=30,
        borderwidth=0,
        font=(FONT, 10)
    )

    style.configure(
        "Treeview.Heading",
        background=SURFACE_ALT,
        foreground=MUTED,
        font=(FONT, 9, "bold"),
        relief="flat",
        padding=(8, 6)
    )

    style.map(
        "Treeview",
        background=[("selected", PRIMARY_SOFT)],
        foreground=[("selected", TEXT)]
    )

    style.map(
        "Treeview.Heading",
        background=[("active", SURFACE_ALT)]
    )

    # Bỏ viền mặc định của Treeview
    style.layout(
        "Treeview",
        [("Treeview.treearea", {"sticky": "nswe"})]
    )

    style.configure(
        "Vertical.TScrollbar",
        background=BORDER,
        troughcolor=SURFACE_ALT,
        bordercolor=SURFACE_ALT,
        arrowcolor=MUTED,
        relief="flat"
    )

    root.option_add("*TCombobox*Listbox.font", (FONT, 11))


# =========================================================
# NÚT BO GÓC
# =========================================================
class RoundedButton(tk.Canvas):

    STYLES = {
        "primary": (PRIMARY, PRIMARY_H, "#FFFFFF"),
        "success": (SUCCESS, SUCCESS_H, "#FFFFFF"),
        "danger": (DANGER, DANGER_H, "#FFFFFF"),
        "secondary": (SECONDARY, SECONDARY_H, TEXT),
        "ghost": (None, "#D5DDE9", MUTED),
    }

    def __init__(
        self,
        parent,
        text,
        command=None,
        style="primary",
        font_size=11,
        height=44,
        radius=10,
        width=120
    ):
        self._parent_bg = parent.cget("bg")

        super().__init__(
            parent,
            width=width,
            height=height,
            bg=self._parent_bg,
            highlightthickness=0,
            bd=0,
            cursor="hand2"
        )

        self._text = text
        self._command = command
        self._style = style
        self._font = (FONT, font_size, "bold")
        self._radius = radius
        self._hover = False
        self._down = False
        self._enabled = True

        self.bind("<Configure>", lambda e: self._draw())
        self.bind("<Enter>", self._on_enter)
        self.bind("<Leave>", self._on_leave)
        self.bind("<ButtonPress-1>", self._on_press)
        self.bind("<ButtonRelease-1>", self._on_release)

    # -----------------------------------------------------
    def configure_button(self, text=None, style=None, command=None):
        if text is not None:
            self._text = text
        if style is not None:
            self._style = style
        if command is not None:
            self._command = command
        self._draw()

    def set_enabled(self, enabled):
        self._enabled = bool(enabled)
        self.config(cursor="hand2" if enabled else "arrow")
        self._draw()

    # -----------------------------------------------------
    def _colors(self):
        base, hover, fg = self.STYLES[self._style]

        if base is None:
            base = self._parent_bg

        if not self._enabled:
            return "#E2E8F0", "#94A3B8"

        if self._down:
            return hover, fg

        return (hover if self._hover else base), fg

    def _round_rect(self, x1, y1, x2, y2, r, **kw):
        pts = [
            x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r,
            x2, y2 - r, x2, y2, x2 - r, y2, x1 + r, y2,
            x1, y2, x1, y2 - r, x1, y1 + r, x1, y1
        ]
        return self.create_polygon(pts, smooth=True, **kw)

    def _draw(self):
        self.delete("all")

        w, h = self.winfo_width(), self.winfo_height()

        if w < 4 or h < 4:
            return

        fill, fg = self._colors()
        r = min(self._radius, h // 2)

        self._round_rect(1, 1, w - 1, h - 1, r, fill=fill, outline=fill)

        self.create_text(
            w / 2,
            h / 2,
            text=self._text,
            fill=fg,
            font=self._font
        )

    # -----------------------------------------------------
    def _on_enter(self, _):
        self._hover = True
        self._draw()

    def _on_leave(self, _):
        self._hover = False
        self._down = False
        self._draw()

    def _on_press(self, _):
        if self._enabled:
            self._down = True
            self._draw()

    def _on_release(self, e):
        was_down = self._down
        self._down = False
        self._draw()

        inside = (
            0 <= e.x <= self.winfo_width()
            and 0 <= e.y <= self.winfo_height()
        )

        if was_down and inside and self._enabled and self._command:
            self._command()


# =========================================================
# Ô NHẬP LIỆU
# =========================================================
class FormField(tk.Frame):
    """Nhãn + ô nhập (viền đổi màu khi focus). values=... -> dạng Combobox."""

    def __init__(
        self,
        parent,
        label,
        show=None,
        values=None,
        textvariable=None,
        bg=SURFACE,
        font_size=11
    ):
        super().__init__(parent, bg=bg)

        tk.Label(
            self,
            text=label,
            bg=bg,
            fg=MUTED,
            font=(FONT, 9, "bold"),
            anchor="w"
        ).pack(fill="x", pady=(0, 4))

        self.var = textvariable or tk.StringVar()

        if values is not None:
            self.entry = ttk.Combobox(
                self,
                textvariable=self.var,
                values=values,
                state="readonly",
                font=(FONT, font_size)
            )
            self.entry.pack(fill="x", ipady=4)
            return

        self.box = tk.Frame(
            self,
            bg="#FFFFFF",
            highlightthickness=1,
            highlightbackground=BORDER,
            highlightcolor=PRIMARY
        )
        self.box.pack(fill="x")

        self.entry = tk.Entry(
            self.box,
            textvariable=self.var,
            show=show or "",
            font=(FONT, font_size),
            relief="flat",
            bd=0,
            bg="#FFFFFF",
            fg=TEXT,
            insertbackground=TEXT
        )
        self.entry.pack(
            side="left",
            fill="x",
            expand=True,
            padx=(10, 4),
            ipady=8
        )

        self.entry.bind(
            "<FocusIn>",
            lambda e: self.box.config(highlightbackground=PRIMARY)
        )
        self.entry.bind(
            "<FocusOut>",
            lambda e: self.box.config(highlightbackground=BORDER)
        )

        self._show_char = show

        if show:
            self._toggle = tk.Label(
                self.box,
                text="Hiện",
                bg="#FFFFFF",
                fg=MUTED,
                font=(FONT, 9, "bold"),
                cursor="hand2",
                padx=10
            )
            self._toggle.pack(side="right")
            self._toggle.bind("<Button-1>", lambda e: self._toggle_show())

    def _toggle_show(self):
        if self.entry.cget("show"):
            self.entry.config(show="")
            self._toggle.config(text="Ẩn")
        else:
            self.entry.config(show=self._show_char)
            self._toggle.config(text="Hiện")

    def get(self):
        return self.var.get()

    def focus_entry(self):
        self.entry.focus_set()


# =========================================================
# THẺ (CARD)
# =========================================================
class Card(tk.Frame):

    def __init__(self, parent, title=None, padx=16, pady=14, bg=SURFACE):
        super().__init__(
            parent,
            bg=bg,
            highlightthickness=1,
            highlightbackground=BORDER
        )

        if title:
            tk.Label(
                self,
                text=title.upper(),
                bg=bg,
                fg=MUTED,
                font=(FONT, 9, "bold"),
                anchor="w"
            ).pack(fill="x", padx=padx, pady=(pady, 6))

        self.body = tk.Frame(self, bg=bg)
        self.body.pack(
            fill="both",
            expand=True,
            padx=padx,
            pady=(0 if title else pady, pady)
        )


# =========================================================
# AVATAR (VÒNG TRÒN CHỮ CÁI ĐẦU)
# =========================================================
class Avatar(tk.Canvas):

    def __init__(self, parent, size=56, bg=SURFACE):
        super().__init__(
            parent,
            width=size,
            height=size,
            bg=bg,
            highlightthickness=0,
            bd=0
        )
        self._size = size
        self.set("?", BORDER, MUTED)

    def set(self, text, fill, fg="#FFFFFF"):
        s = self._size
        self.delete("all")
        self.create_oval(2, 2, s - 2, s - 2, fill=fill, outline="")
        self.create_text(
            s / 2,
            s / 2,
            text=text,
            fill=fg,
            font=(FONT, max(int(s * 0.32), 8), "bold")
        )


# =========================================================
# BANNER TRẠNG THÁI
# =========================================================
class StatusBanner(tk.Frame):

    KINDS = {
        "idle": (MUTED, "#F1F5F9", "●"),
        "info": (PRIMARY, PRIMARY_SOFT, "i"),
        "success": (SUCCESS, SUCCESS_SOFT, "✓"),
        "error": (DANGER, DANGER_SOFT, "✕"),
    }

    def __init__(self, parent, height=84):
        super().__init__(
            parent,
            bg=SURFACE,
            height=height,
            highlightthickness=1,
            highlightbackground=BORDER
        )
        self.pack_propagate(False)

        self._bar = tk.Frame(self, width=6)
        self._bar.pack(side="left", fill="y")

        self._icon = tk.Label(self, font=(FONT, 18, "bold"), width=2)
        self._icon.pack(side="left", padx=(14, 6))

        self._text = tk.Frame(self)
        self._text.pack(side="left", expand=True, fill="x", padx=(0, 12))

        self._title_lbl = tk.Label(
            self._text,
            anchor="w",
            justify="left",
            font=(FONT, 13, "bold"),
            fg=TEXT
        )
        self._title_lbl.pack(fill="x")

        self._sub_lbl = tk.Label(
            self._text,
            anchor="w",
            justify="left",
            font=(FONT, 10),
            fg=MUTED
        )
        self._sub_lbl.pack(fill="x")

        self.bind("<Configure>", self._on_resize)

        self.set("idle", "Sẵn sàng")

    def _on_resize(self, e):
        wrap = max(e.width - 100, 120)
        self._title_lbl.config(wraplength=wrap)
        self._sub_lbl.config(wraplength=wrap)

    def set(self, kind, title, sub=""):
        accent, soft, icon = self.KINDS[kind]

        for w in (
            self,
            self._icon,
            self._text,
            self._title_lbl,
            self._sub_lbl
        ):
            w.config(bg=soft)

        self._bar.config(bg=accent)
        self._icon.config(text=icon, fg=accent)
        self._title_lbl.config(text=title)
        self._sub_lbl.config(text=sub)


# =========================================================
# ĐỒNG HỒ
# =========================================================
class ClockWidget(tk.Frame):

    def __init__(self, parent, bg=NAVY):
        super().__init__(parent, bg=bg)

        self._time = tk.Label(
            self,
            bg=bg,
            fg="#FFFFFF",
            font=(FONT, 15, "bold"),
            anchor="e"
        )
        self._time.pack(fill="x")

        self._date = tk.Label(
            self,
            bg=bg,
            fg=NAVY_MUTED,
            font=(FONT, 9),
            anchor="e"
        )
        self._date.pack(fill="x")

        self._job = None
        self._tick()

    def _tick(self):
        now = datetime.datetime.now()
        self._time.config(text=now.strftime("%H:%M:%S"))
        self._date.config(text=now.strftime("%d/%m/%Y"))
        self._job = self.after(1000, self._tick)

    def destroy(self):
        if self._job is not None:
            try:
                self.after_cancel(self._job)
            except tk.TclError:
                pass
            self._job = None
        super().destroy()


# =========================================================
# LOGO + THANH TIÊU ĐỀ
# =========================================================
def logo(parent, size=40, bg=NAVY, fg="#FFFFFF", accent=ACCENT):
    """Biểu tượng quét khuôn mặt vẽ bằng Canvas (không cần file ảnh)."""
    c = tk.Canvas(
        parent,
        width=size,
        height=size,
        bg=bg,
        highlightthickness=0,
        bd=0
    )

    m = size * 0.08
    arm = size * 0.28
    w = max(2, int(size * 0.07))

    for x, y, dx, dy in (
        (m, m, 1, 1),
        (size - m, m, -1, 1),
        (m, size - m, 1, -1),
        (size - m, size - m, -1, -1)
    ):
        c.create_line(
            x, y, x + dx * arm, y,
            fill=accent, width=w, capstyle="round"
        )
        c.create_line(
            x, y, x, y + dy * arm,
            fill=accent, width=w, capstyle="round"
        )

    cx = size / 2
    r = size * 0.13

    c.create_oval(
        cx - r, size * 0.28,
        cx + r, size * 0.28 + 2 * r,
        fill=fg, outline=""
    )

    c.create_arc(
        cx - size * 0.24, size * 0.56,
        cx + size * 0.24, size * 0.56 + size * 0.40,
        start=0, extent=180,
        fill=fg, outline=""
    )

    return c


def build_header(root, title, subtitle=""):
    """Thanh tiêu đề màu navy. Trả về frame bên phải để gắn đồng hồ, user..."""
    header = tk.Frame(root, bg=NAVY, height=68)
    header.pack(fill="x")
    header.pack_propagate(False)

    logo(header, 38).pack(side="left", padx=(24, 12))

    box = tk.Frame(header, bg=NAVY)
    box.pack(side="left")

    tk.Label(
        box,
        text=title,
        bg=NAVY,
        fg="#FFFFFF",
        font=(FONT, 15, "bold")
    ).pack(anchor="w")

    if subtitle:
        tk.Label(
            box,
            text=subtitle,
            bg=NAVY,
            fg=NAVY_MUTED,
            font=(FONT, 9)
        ).pack(anchor="w")

    right = tk.Frame(header, bg=NAVY)
    right.pack(side="right", padx=24)

    return right


# =========================================================
# HỘP THOẠI CHUẨN
# =========================================================
class BaseDialog(tk.Toplevel):
    """
    Khung hộp thoại: tiêu đề + phần thân (self.body) + 2 nút Hủy / OK.
    Lớp con thêm widget vào self.body, định nghĩa submit(), rồi gọi finish().
    """

    def __init__(
        self,
        parent,
        title,
        subtitle,
        width,
        ok_text,
        ok_style="primary"
    ):
        super().__init__(parent)

        self.withdraw()
        self.title(title)
        self.configure(bg=SURFACE)
        self.resizable(False, False)

        self.result = None
        self._width = width
        self._parent = parent

        head = tk.Frame(self, bg=SURFACE)
        head.pack(fill="x", padx=28, pady=(24, 8))

        tk.Label(
            head,
            text=title,
            bg=SURFACE,
            fg=TEXT,
            font=(FONT, 16, "bold"),
            anchor="w"
        ).pack(fill="x")

        if subtitle:
            tk.Label(
                head,
                text=subtitle,
                bg=SURFACE,
                fg=MUTED,
                font=(FONT, 10),
                anchor="w",
                justify="left",
                wraplength=width - 56
            ).pack(fill="x", pady=(2, 0))

        foot = tk.Frame(self, bg=SURFACE)
        foot.pack(side="bottom", fill="x", padx=28, pady=(14, 24))
        foot.columnconfigure((0, 1), weight=1, uniform="btn")

        RoundedButton(
            foot, "Hủy", self.destroy, "secondary", 11, 42
        ).grid(row=0, column=0, sticky="ew", padx=(0, 6))

        RoundedButton(
            foot, ok_text, self.submit, ok_style, 11, 42
        ).grid(row=0, column=1, sticky="ew", padx=(6, 0))

        self.body = tk.Frame(self, bg=SURFACE)
        self.body.pack(fill="both", expand=True, padx=28, pady=(8, 0))

        self.bind("<Return>", lambda e: self.submit())
        self.bind("<Escape>", lambda e: self.destroy())

        self.transient(parent)

    def submit(self):
        self.destroy()

    def finish(self):
        """Gọi sau khi đã thêm xong widget: tự tính chiều cao, căn giữa, hiển thị."""
        self.update_idletasks()

        center_on_parent(
            self,
            self._parent,
            self._width,
            self.winfo_reqheight()
        )

        self.deiconify()

        try:
            self.wait_visibility()
            self.grab_set()
        except tk.TclError:
            pass

        self.focus_force()


# =========================================================
# VẼ KHUNG KHUÔN MẶT TRÊN ẢNH CAMERA (PIL)
# =========================================================
_GREEN = (22, 163, 74)
_RED = (220, 38, 38)
_DARK = (15, 23, 42)

_FONT_CACHE = {}


def load_font(size, bold=False):
    """Font hỗ trợ tiếng Việt có dấu (Segoe UI / Arial / DejaVu)."""
    key = (size, bold)

    if key in _FONT_CACHE:
        return _FONT_CACHE[key]

    if bold:
        names = (
            "segoeuib.ttf",
            "arialbd.ttf",
            "DejaVuSans-Bold.ttf",
            "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
            "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
        )
    else:
        names = (
            "segoeui.ttf",
            "arial.ttf",
            "DejaVuSans.ttf",
            "/System/Library/Fonts/Supplemental/Arial.ttf",
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
        )

    font = None

    for name in names:
        try:
            font = ImageFont.truetype(name, size)
            break
        except OSError:
            continue

    if font is None:
        font = ImageFont.load_default()

    _FONT_CACHE[key] = font
    return font


def draw_pill(draw, x, y, text, fill, font, fg=(255, 255, 255), dot=None):
    """Vẽ nhãn bo tròn (có thể kèm chấm tròn màu). Trả về (rộng, cao)."""
    l, t, r, b = draw.textbbox((0, 0), text, font=font)

    pad_x, pad_y = 12, 6
    dot_w = 14 if dot else 0

    w = (r - l) + pad_x * 2 + dot_w
    h = (b - t) + pad_y * 2

    x, y = int(x), int(y)

    draw.rounded_rectangle(
        [x, y, x + w, y + h],
        radius=h // 2,
        fill=fill
    )

    if dot:
        cy = y + h // 2
        draw.ellipse(
            [x + pad_x, cy - 4, x + pad_x + 8, cy + 4],
            fill=dot
        )

    draw.text(
        (x + pad_x + dot_w - l, y + pad_y - t),
        text,
        font=font,
        fill=fg
    )

    return w, h


def draw_face_box(draw, left, top, right, bottom, label, known, font, bounds):
    """
    Khung 4 góc + nhãn tên bo tròn.
    known=True: xanh lá; False: đỏ. bounds=(rộng, cao) của ảnh.
    """
    color = _GREEN if known else _RED

    left, top = int(left), int(top)
    right, bottom = int(right), int(bottom)

    arm = max(16, min(right - left, bottom - top) // 4)

    for x, y, dx, dy in (
        (left, top, 1, 1),
        (right, top, -1, 1),
        (left, bottom, 1, -1),
        (right, bottom, -1, -1)
    ):
        # Kéo dài 2px về phía ngoài để hai nét gặp nhau liền mạch ở góc
        draw.line([(x - dx * 2, y), (x + dx * arm, y)], fill=color, width=4)
        draw.line([(x, y - dy * 2), (x, y + dy * arm)], fill=color, width=4)

    l, t, r, b = draw.textbbox((0, 0), label, font=font)
    pill_w = (r - l) + 24
    pill_h = (b - t) + 12

    # Giữ nhãn nằm trong ảnh
    x = max(min(left, bounds[0] - pill_w - 4), 0)

    y = bottom + 10

    if y + pill_h > bounds[1]:
        y = max(top - 10 - pill_h, 0)

    draw_pill(draw, x, y, label, color, font)


def draw_live_badge(draw, font):
    """Nhãn LIVE ở góc trên trái ảnh camera."""
    draw_pill(
        draw,
        14,
        14,
        "LIVE",
        _DARK,
        font,
        dot=(239, 68, 68)
    )