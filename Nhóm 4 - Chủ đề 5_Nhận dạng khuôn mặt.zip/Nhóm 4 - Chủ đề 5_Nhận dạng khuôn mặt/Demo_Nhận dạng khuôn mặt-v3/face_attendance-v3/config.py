"""Cấu hình hệ thống. Muốn đổi, tạo file config.json cạnh main.py, ví dụ:

    {"match_threshold": 0.45, "require_liveness": false}

Khóa nào không có trong file sẽ dùng giá trị mặc định dưới đây.
"""

import json
import logging
import os

log = logging.getLogger(__name__)

DEFAULTS = {
    # --- camera ---
    "camera_index": 0,
    "frame_width": 640,
    "frame_height": 480,
    "detect_scale": 0.5,         # nhận diện trên ảnh thu nhỏ (nhanh hơn)

    # --- so khớp khuôn mặt ---
    "match_threshold": 0.5,      # khoảng cách tối đa để coi là cùng người
    "match_margin": 0.04,        # người tốt nhất phải hơn người nhì chừng này
    "confirm_window": 6,         # xác nhận qua N lần nhận diện gần nhất...
    "confirm_votes": 4,          # ...trong đó phải có ít nhất M lần cùng một người

    # --- đăng ký ---
    "samples_per_person": 5,
    "max_samples": 15,
    "capture_interval": 1.2,     # giây giữa 2 mẫu
    "capture_timeout": 90,
    "min_face_width": 50,        # px trên ảnh đã thu nhỏ

    # --- điểm danh ---
    "auto_attendance": True,     # tự điểm danh khi nhận ra, không cần bấm nút
    "require_liveness": True,    # yêu cầu chớp mắt (chống ảnh in/ảnh trên màn hình)
    "liveness_window": 8.0,      # giây: xác minh người thật có hiệu lực trong khoảng này
    "liveness_mode": "blink",    # "blink" = chớp mắt | "challenge" = động tác ngẫu nhiên
    "challenge_steps": 2,        # số động tác liên tiếp (chế độ challenge)
    "challenge_timeout": 8.0,    # giây cho mỗi động tác, quá hạn sẽ đổi chuỗi mới
    "challenge_yaw": 0.22,       # ngưỡng quay đầu (chuẩn hóa theo khoảng cách 2 mắt)
    "challenge_mar": 0.35,       # ngưỡng há miệng
    "class_start": "",           # giờ vào lớp "HH:MM"; để trống = không tính đi muộn
    "late_after_minutes": 15,    # điểm danh sau giờ vào lớp chừng này phút = đi muộn

    # --- chất lượng ảnh khi đăng ký (trên ảnh đã thu nhỏ) ---
    "min_sharpness": 15.0,       # độ nét tối thiểu (phương sai Laplacian)
    "min_brightness": 50.0,      # độ sáng trung bình tối thiểu (0-255)
    "max_brightness": 215.0,     # độ sáng trung bình tối đa (chống ngược sáng/cháy)

    # --- nhật ký ---
    "unknown_log_seconds": 60,   # tối thiểu giây giữa 2 lần ghi "khuôn mặt lạ"
    "audit_keep": 5000,          # số dòng nhật ký hoạt động giữ lại

    # --- mô hình nhận diện ---
    "backend": "dlib",           # "dlib" (128 chiều) | "arcface" (512 chiều, cần tools/get_models.py)
    "arcface_model": "models/w600k_mbf.onnx",
    "arcface_threshold": 1.0,    # khoảng cách tối đa (vector đã chuẩn hóa); CHƯA hiệu chỉnh:
    "arcface_margin": 0.05,      # hãy chạy tools/evaluate.py --backend arcface để chọn giá trị

    # --- chống giả mạo thụ động (MiniFASNet ONNX, xem tools/get_models.py) ---
    "antispoof_enable": False,   # bật sau khi đã hiệu chỉnh bằng tools/eval_spoof.py
    "antispoof_dir": "models",
    "antispoof_threshold": 0.7,  # xác suất "người thật" trung bình tối thiểu
    "antispoof_frames": 3,       # số lần đo gần nhất dùng để lấy trung bình

    # --- nhiều người cùng lúc ---
    "max_faces": 1,              # 1 = chỉ khuôn mặt lớn nhất (như cũ); >1 = điểm danh nhiều người

    # --- nhiều ca trong ngày ---
    # "Tên ca|giờ bắt đầu|giờ kết thúc;..." ví dụ "Ca sáng|07:00|11:30;Ca chiều|13:00|17:00".
    # Để trống = cả ngày là một buổi (như cũ). Ngoài giờ các ca thì không điểm danh.
    "timetable": "",
    "session_early_minutes": 15, # cho phép điểm danh sớm hơn giờ bắt đầu ca chừng này phút

    # --- bảo vệ dữ liệu ---
    "encrypt_embeddings": True,  # mã hóa vector khuôn mặt trong cơ sở dữ liệu (AES-GCM)
    "key_file": "data.key",      # khóa mã hóa; hãy sao lưu riêng, mất khóa là mất dữ liệu khuôn mặt
    "retention_days": 0,         # >0: tự xóa điểm danh cũ hơn N ngày khi khởi động (0 = giữ mãi)

    # --- giao diện ---
    "kiosk": False,              # toàn màn hình, ẩn quản trị cho tới khi đăng nhập lại

    # --- hệ thống ---
    "backup_keep": 7,            # số bản sao lưu cơ sở dữ liệu giữ lại
    "login_max_attempts": 5,
    "login_lock_seconds": 30,
}


class Config:

    def __init__(self, **overrides):

        for key, default in DEFAULTS.items():
            setattr(self, key, overrides.get(key, default))

    @classmethod
    def load(cls, base_dir):
        """Đọc config.json (nếu có). Giá trị sai kiểu bị bỏ qua, dùng mặc định."""

        path = os.path.join(base_dir, "config.json")

        if not os.path.exists(path):
            return cls()

        try:
            with open(path, "r", encoding="utf-8") as f:
                raw = json.load(f)

            if not isinstance(raw, dict):
                raise ValueError("config.json phải là một đối tượng JSON")

        except (OSError, ValueError) as e:
            log.warning("Không đọc được config.json: %s", e)
            return cls()

        clean = {}

        for key, value in raw.items():

            if key not in DEFAULTS:
                log.warning("config.json: bỏ qua khóa lạ %r", key)
                continue

            default = DEFAULTS[key]

            if isinstance(default, bool):
                ok = isinstance(value, bool)
            elif isinstance(default, str):
                ok = isinstance(value, str)
            elif isinstance(default, int):
                ok = isinstance(value, int) and not isinstance(value, bool)
            else:
                ok = (
                    isinstance(value, (int, float))
                    and not isinstance(value, bool)
                )

            if not ok:
                log.warning("config.json: %r sai kiểu, dùng mặc định", key)
                continue

            clean[key] = value

        return cls(**clean)
