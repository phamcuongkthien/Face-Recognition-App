import unittest

import numpy as np

from tests.helpers import enc
from tools import evalcore


def world(n_people=4, noise=0.01):
    enrolled = {f"P{i}": [enc(i, noise), enc(i, noise * 1.3)] for i in range(1, n_people + 1)}
    return enrolled


class EvalCoreTests(unittest.TestCase):

    def test_perfect_world_has_no_errors(self):
        owners, m = evalcore.build_index(world())
        tests = [(f"P{i}", "sang", enc(i, 0.012)) for i in range(1, 5)]
        tests += [(None, "nguoi_la", enc(900 + k)) for k in range(5)]
        o = evalcore.system_outcomes(tests, owners, m, 0.5, 0.04)
        self.assertEqual((o["ta"], o["fr"], o["mis"], o["fa"], o["tr"]), (4, 0, 0, 0, 5))
        g, imp = evalcore.pair_scores(tests, owners, m)
        self.assertLess(g.max(), imp.min())
        eer, _ = evalcore.equal_error_rate(g, imp)
        self.assertLess(eer, 0.01)

    def test_counts_false_reject_misid_and_false_accept(self):
        owners, m = evalcore.build_index(world())
        far = enc(1, 0.0) + 5.0                       # rất xa mọi mẫu -> bị từ chối
        tests = [("P1", "toi", far)]
        o = evalcore.system_outcomes(tests, owners, m, 0.5, 0.04)
        self.assertEqual((o["fr"], o["mis"]), (1, 0))
        self.assertEqual(o["by_cond"]["toi"], [1, 1])

        # P2 xuất hiện nhưng được gắn nhãn P1 -> nhận nhầm
        o = evalcore.system_outcomes([("P1", "sang", enc(2, 0.01))], owners, m, 0.5, 0.04)
        self.assertEqual(o["mis"], 1)

        # người lạ giống hệt P3 -> bị nhận thành P3
        o = evalcore.system_outcomes([(None, "nguoi_la", enc(3, 0.01))], owners, m, 0.5, 0.04)
        self.assertEqual(o["fa"], 1)

    def test_threshold_sweep_is_monotone_in_frr(self):
        owners, m = evalcore.build_index(world())
        rng = np.random.RandomState(0)
        tests = [(f"P{i}", "x", enc(i, 0.01) + rng.normal(0, 0.03, 128)) for i in range(1, 5) for _ in range(10)]
        rows = evalcore.sweep(tests, owners, m, 0.04, np.arange(0.2, 0.8, 0.1))
        frr = [r[1] for r in rows]
        self.assertTrue(all(a >= b - 1e-9 for a, b in zip(frr, frr[1:])))

    def test_rule_of_three(self):
        self.assertAlmostEqual(evalcore.upper_bound_zero(300), 0.01)

    def test_margin_rejects_two_close_people(self):
        base = enc(1, 0.0)
        enrolled = {"A": [base], "B": [base + 0.001]}
        owners, m = evalcore.build_index(enrolled)
        o = evalcore.system_outcomes([("A", "x", base)], owners, m, 0.5, 0.04)
        self.assertEqual(o["fr"], 1)                  # quá giống nhau -> từ chối, không đoán bừa


class ReportTests(unittest.TestCase):

    def test_single_person_report(self):
        from tools.evaluate import build_report
        enrolled = {"Toi": [enc(1, 0.01), enc(1, 0.015), enc(1, 0.02)]}
        tests = [("Toi", "sang", enc(1, 0.012)) for _ in range(5)]
        tests += [("Toi", "toi", enc(1, 0.0) + 5.0)]
        text = build_report(enrolled, tests, 0.5, 0.04)
        self.assertIn("Chỉ có 1 người", text)
        self.assertIn("5/6", text)
        self.assertIn("không đo được", text)
        self.assertNotIn("Nhận NHẦM", text)
        self.assertIn("chưa thể chọn ngưỡng", text)

    def test_single_person_with_strangers(self):
        from tools.evaluate import build_report
        enrolled = {"Toi": [enc(1, 0.01), enc(1, 0.02)]}
        tests = [("Toi", "sang", enc(1, 0.012))] + [(None, "nguoi_la", enc(50 + k)) for k in range(4)]
        text = build_report(enrolled, tests, 0.5, 0.04)
        self.assertIn("0/4", text)
        self.assertIn("EER", text)

    def test_two_people_report_mentions_dangerous_errors(self):
        from tools.evaluate import build_report
        enrolled = world(3)
        tests = [(f"P{i}", "sang", enc(i, 0.012)) for i in (1, 2, 3)]
        tests += [(None, "nguoi_la", enc(80 + k)) for k in range(3)]
        text = build_report(enrolled, tests, 0.5, 0.04)
        self.assertIn("Nhận NHẦM", text)
        self.assertIn("cận trên 95%", text)


class DiagnosticsTests(unittest.TestCase):

    def test_flags_same_face_enrolled_under_two_names(self):
        from tools.evaluate import build_report
        enrolled = {"A": [enc(1, 0.01), enc(1, 0.02)], "B": [enc(1, 0.015), enc(1, 0.025)]}
        tests = [("A", "sang", enc(1, 0.012)), ("B", "sang", enc(1, 0.018))]
        text = build_report(enrolled, tests, 0.5, 0.04)
        self.assertIn("CÙNG MỘT KHUÔN MẶT", text)
        self.assertIn("Hệ thống nhận ảnh của ai thành ai", text)

    def test_flags_inconsistent_enroll_set(self):
        from tools.evaluate import build_report
        enrolled = {"A": [enc(1, 0.01), enc(2, 0.01)], "B": [enc(3, 0.01), enc(3, 0.02)]}
        tests = [("A", "sang", enc(1, 0.012))]
        self.assertIn("không nhất quán", build_report(enrolled, tests, 0.5, 0.04))

    def test_reports_missing_faces_per_folder(self):
        from tools.evaluate import build_report
        enrolled = {"A": [enc(1, 0.01)], "B": [enc(2, 0.01)]}
        tests = [("A", "sang", enc(1, 0.012))]
        text = build_report(enrolled, tests, 0.5, 0.04, 5, 0,
                            {("A", "test_xa"): 4}, {("A", "test_xa"): 15})
        self.assertIn("| A | test_xa | 4 | 15 |", text)

    def test_clean_data_has_no_warnings(self):
        from tools.evaluate import build_report
        enrolled = world(3)
        tests = [(f"P{i}", "sang", enc(i, 0.012)) for i in (1, 2, 3)]
        text = build_report(enrolled, tests, 0.5, 0.04)
        self.assertNotIn("⚠", text)


if __name__ == "__main__":
    unittest.main()
