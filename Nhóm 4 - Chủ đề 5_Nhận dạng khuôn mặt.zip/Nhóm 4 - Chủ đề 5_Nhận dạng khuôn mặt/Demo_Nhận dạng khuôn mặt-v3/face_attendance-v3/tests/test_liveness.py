import unittest

from liveness import BlinkDetector, eye_aspect_ratio, face_ear

OPEN_EYE = [(0, 0), (1, -1), (2, -1), (3, 0), (2, 1), (1, 1)]            # EAR ~0.67
CLOSED_EYE = [(0, 0), (1, -0.1), (2, -0.1), (3, 0), (2, 0.1), (1, 0.1)]  # EAR ~0.07


def feed(det, values, start=0.0, step=0.15):
    t, hits = start, []
    for v in values:
        hits.append(det.update(v, t)); t += step
    return hits, t


class EarTests(unittest.TestCase):

    def test_ear_values(self):
        self.assertGreater(eye_aspect_ratio(OPEN_EYE), 0.5)
        self.assertLess(eye_aspect_ratio(CLOSED_EYE), 0.15)
        self.assertIsNone(eye_aspect_ratio([(0, 0)] * 5))
        self.assertIsNone(eye_aspect_ratio([(0, 0)] * 6))   # chia 0

    def test_face_ear_average_and_missing(self):
        v = face_ear({"left_eye": OPEN_EYE, "right_eye": OPEN_EYE})
        self.assertAlmostEqual(v, eye_aspect_ratio(OPEN_EYE))
        self.assertIsNone(face_ear({}))


class BlinkTests(unittest.TestCase):

    def test_blink_detected(self):
        d = BlinkDetector()
        hits, t = feed(d, [0.30] * 8)
        self.assertFalse(any(hits))
        hits, t = feed(d, [0.12, 0.30], start=t)       # nhắm 1 mẫu rồi mở
        self.assertEqual(hits, [False, True])
        self.assertTrue(d.recently_blinked(t, 8))
        self.assertFalse(d.recently_blinked(t + 20, 8))

    def test_photo_with_noise_never_blinks(self):
        d = BlinkDetector()
        vals = [0.30 + 0.01 * ((-1) ** i) for i in range(60)]
        hits, _ = feed(d, vals)
        self.assertFalse(any(hits)); self.assertEqual(d.blink_count, 0)

    def test_different_eye_size_scales(self):
        for base in (0.20, 0.35):
            d = BlinkDetector()
            _, t = feed(d, [base] * 8)
            hits, _ = feed(d, [base * 0.4, base], start=t)
            self.assertTrue(hits[-1], base)

    def test_long_closed_is_not_blink_and_relearns(self):
        d = BlinkDetector()
        _, t = feed(d, [0.30] * 8)
        hits, t = feed(d, [0.12] * 10 + [0.30], start=t)     # nhắm >1.5s
        self.assertFalse(any(hits))
        # đổi tư thế: EAR thấp bền vững -> học lại, sau đó chớp mắt vẫn bắt được
        _, t = feed(d, [0.18] * 10, start=t)
        hits, _ = feed(d, [0.06, 0.18], start=t)
        self.assertTrue(hits[-1])

    def test_reset(self):
        d = BlinkDetector()
        _, t = feed(d, [0.30] * 8); feed(d, [0.1, 0.3], start=t)
        d.reset(); self.assertFalse(d.recently_blinked(t, 99))


if __name__ == "__main__":
    unittest.main()
