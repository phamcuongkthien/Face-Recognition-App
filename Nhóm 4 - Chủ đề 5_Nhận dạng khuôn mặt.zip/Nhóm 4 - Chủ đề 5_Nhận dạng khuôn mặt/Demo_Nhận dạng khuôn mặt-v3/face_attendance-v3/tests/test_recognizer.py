import unittest

import numpy as np

import recognizer
from tests.helpers import enc


class MatchTests(unittest.TestCase):

    def setUp(self):
        self.owners = ["A", "A", "A", "B", "B"]
        self.m = np.vstack([enc(1, .01), enc(1, .02), enc(1, .03), enc(2, .01), enc(2, .02)])

    def test_known(self):
        sid, d = recognizer.match_face(self.m, self.owners, enc(1, .015))
        self.assertEqual(sid, "A"); self.assertLess(d, .5)

    def test_unknown_and_empty(self):
        self.assertIsNone(recognizer.match_face(self.m, self.owners, enc(99))[0])
        self.assertEqual(recognizer.match_face(np.empty((0, 128)), [], enc(1)), (None, None))

    def test_ambiguous_between_people_rejected_but_same_person_ok(self):
        e = enc(1)
        self.assertIsNone(recognizer.match_face(np.vstack([e, e + 1e-4]), ["A", "B"], e)[0])
        self.assertEqual(recognizer.match_face(np.vstack([e, e + 1e-4, e + 2e-4]), ["A"] * 3, e)[0], "A")

    def test_distance_to_student(self):
        d = recognizer.distance_to_student(self.m, self.owners, enc(1, .015), "A")
        self.assertLess(d, .5)
        self.assertGreater(recognizer.distance_to_student(self.m, self.owners, enc(1, .015), "B"), .5)
        self.assertIsNone(recognizer.distance_to_student(self.m, self.owners, enc(1), "Z"))

    def test_face_area(self):
        self.assertEqual(recognizer.face_area((0, 10, 20, 0)), 200)
        self.assertEqual(recognizer.face_area((5, 0, 0, 5)), 0)


class StableTests(unittest.TestCase):

    def test_needs_consistent_votes(self):
        s = recognizer.StableIdentity(6, 4)
        for v in ("A", "A", "B", "A"):
            self.assertIsNone(s.add(v))
        self.assertEqual(s.candidate, "A")
        self.assertEqual(s.add("A"), "A")
        s.reset(); self.assertIsNone(s.confirmed)

    def test_flicker_never_confirms(self):
        s = recognizer.StableIdentity()
        for v in "ABABABAB":
            self.assertIsNone(s.add(v))


if __name__ == "__main__":
    unittest.main()
