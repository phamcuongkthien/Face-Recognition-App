import numpy as np


def enc(seed, noise=0.0):
    base = np.random.RandomState(seed).uniform(-0.2, 0.2, 128)
    if noise:
        base = base + np.random.RandomState(seed + 1000).normal(0, noise, 128)
    return base


BOX = (10, 110, 110, 10)      # top, right, bottom, left -> rộng 100
SMALL_BOX = (0, 30, 30, 0)    # rộng 30
