"""Test cho phiên bản 3: nhiều người, nhiều ca, mã hóa, mô hình ArcFace, chống giả mạo thụ động."""

import datetime
import os
import random
import shutil
import sqlite3
import sys
import tempfile
import unittest
from unittest.mock import MagicMock

import numpy as np

import antispoof
import backends
import db
import secure
from config import Config
from engine import Engine, parse_timetable
from tests.helpers import BOX, enc
from tests.test_engine import Base, Clock
from tracker import Tracker, iou

MODELS = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "models")
HAVE_MODELS = all(os.path.exists(os.path.join(MODELS, f)) for f in
                  ("MiniFASNetV2.onnx", "MiniFASNetV1SE.onnx", "w600k_mbf.onnx"))

LEFT = (10, 110, 110, 10)        # hai khuôn mặt không chồng nhau
RIGHT = (10, 330, 110, 230)
SMALLER = (10, 330, 90, 250)     # nhỏ hơn LEFT


# =========================================================
# TRACKER
# =========================================================
class TrackerTests(unittest.TestCase):

    def test_iou(self):
        self.assertEqual(iou(LEFT, LEFT), 1.0)
        self.assertEqual(iou(LEFT, RIGHT), 0.0)
        self.assertAlmostEqual(iou((0, 10, 10, 0), (0, 15, 10, 5)), 1 / 3, places=3)

    def test_keeps_identity_when_faces_move_a_bit(self):
        tr = Tracker(lambda: object())
        a, b = tr.update([LEFT, RIGHT], 0.0)
        a2, b2 = tr.update([(12, 114, 112, 14), (11, 332, 111, 232)], 0.2)
        self.assertIs(a.state, a2.state)
        self.assertIs(b.state, b2.state)
        self.assertIsNot(a.state, b.state)

    def test_order_of_detections_does_not_matter(self):
        tr = Tracker(lambda: object())
        a, b = tr.update([LEFT, RIGHT], 0.0)
        b2, a2 = tr.update([RIGHT, LEFT], 0.2)
        self.assertIs(a.state, a2.state)
        self.assertIs(b.state, b2.state)

    def test_forgets_people_who_left(self):
        tr = Tracker(lambda: object(), max_age=1.0)
        (a,) = tr.update([LEFT], 0.0)
        tr.update([], 2.0)
        (a2,) = tr.update([LEFT], 2.1)
        self.assertIsNot(a.state, a2.state)


# =========================================================
# NHIỀU NGƯỜI CÙNG LÚC
# =========================================================
class MultiFaceTests(Base):

    def two(self, e, s1, s2, ear1=None, ear2=None, dt=0.15, **extra):
        self.clock.advance(dt)
        e.process([
            {"loc": LEFT, "enc": enc(s1, 0.015), "ear": ear1, **extra.get("a", {})},
            {"loc": RIGHT, "enc": enc(s2, 0.015), "ear": ear2, **extra.get("b", {})},
        ])

    def test_default_single_face_ignores_second_person(self):
        e = self.make(require_liveness=False)
        for _ in range(10):
            self.two(e, 1, 2)
        self.assertEqual(e.marked_today, {"SV01"} if False else e.marked_today)
        self.assertEqual(len(e.marked_today), 1)       # chỉ một người (mặt lớn nhất hoặc đầu tiên)

    def test_both_people_marked_when_max_faces_2(self):
        e = self.make(require_liveness=False, max_faces=2)
        for _ in range(10):
            self.two(e, 1, 2)
        self.assertEqual(e.marked_today, {"SV01", "SV02"})
        self.assertEqual(len(self.events(e, "attendance")), 2)

    def test_each_person_needs_their_own_blink(self):
        e = self.make(require_liveness=True, max_faces=2)
        # cả hai chưa chớp
        for _ in range(10):
            self.two(e, 1, 2, 0.3, 0.3)
        self.assertEqual(e.marked_today, set())
        # chỉ SV02 (mặt phụ) chớp
        self.two(e, 1, 2, 0.3, 0.1)
        self.two(e, 1, 2, 0.3, 0.3)
        self.assertEqual(e.marked_today, {"SV02"})
        # rồi SV01 chớp
        self.two(e, 1, 2, 0.1, 0.3)
        self.two(e, 1, 2, 0.3, 0.3)
        self.assertEqual(e.marked_today, {"SV01", "SV02"})

    def test_blink_of_one_face_does_not_count_for_the_other(self):
        e = self.make(require_liveness=True, max_faces=2)
        for i in range(30):
            ear1 = 0.1 if i % 4 == 0 else 0.3          # chỉ mặt lớn nhất chớp
            self.two(e, 1, 2, ear1, 0.3)
        self.assertIn("SV01", e.marked_today)
        self.assertNotIn("SV02", e.marked_today)

    def test_unknown_face_in_group_is_not_marked(self):
        e = self.make(require_liveness=False, max_faces=3)
        for _ in range(10):
            self.two(e, 1, 777)
        self.assertEqual(e.marked_today, {"SV01"})
        labels = {f["label"] for f in e.faces}
        self.assertIn("Chưa đăng ký", labels)

    def test_two_faces_with_same_identity_marked_once(self):
        e = self.make(require_liveness=False, max_faces=2)
        for _ in range(10):
            self.two(e, 1, 1)
        self.assertEqual(len(self.events(e, "attendance")), 1)

    def test_people_swapping_positions_keep_their_own_state(self):
        e = self.make(require_liveness=True, max_faces=2)
        for _ in range(8):
            self.two(e, 1, 2, 0.3, 0.3)
        self.two(e, 1, 2, 0.1, 0.3)               # SV01 (trái) chớp nửa chừng
        # hai người đổi chỗ trong khung hình
        self.clock.advance(0.15)
        e.process([
            {"loc": LEFT, "enc": enc(2, 0.015), "ear": 0.3},
            {"loc": RIGHT, "enc": enc(1, 0.015), "ear": 0.3},
        ])
        self.assertNotIn("SV02", e.marked_today)

    def test_challenge_mode_runs_per_person(self):
        e = self.make(require_liveness=True, liveness_mode="challenge", max_faces=2,
                      challenge_steps=1)
        for st in (e._pstate,):
            st.challenge.pool = ("open_mouth",); st.challenge.steps = 1
            st.challenge.rng = random.Random(1)
        # mặt phụ có ChallengeLiveness riêng; ép nhóm động tác về "há miệng"
        orig = e.tracker.make_state

        def make():
            ps = orig()
            ps.challenge.pool = ("open_mouth",); ps.challenge.steps = 1
            return ps
        e.tracker.make_state = make
        for _ in range(8):
            self.two(e, 1, 2, 0.3, 0.3, a={"mar": 0.0}, b={"mar": 0.0})
        self.assertEqual(e.marked_today, set())
        for _ in range(4):                          # chỉ người phải há miệng
            self.two(e, 1, 2, 0.3, 0.3, a={"mar": 0.0}, b={"mar": 0.7})
        self.assertEqual(e.marked_today, {"SV02"})

    def test_registration_blocked_when_multiple_faces(self):
        e = self.make(require_liveness=False, max_faces=2)
        for _ in range(3):
            self.two(e, 1, 2)
        self.assertIn("nhiều hơn 1", e.check_can_capture())


# =========================================================
# NHIỀU CA TRONG NGÀY
# =========================================================
TT = "Ca sáng|07:00|11:30;Ca chiều|13:00|17:00"


class TimetableParseTests(unittest.TestCase):

    def test_parse(self):
        self.assertEqual(parse_timetable(TT), [("Ca sáng", 420, 690), ("Ca chiều", 780, 1020)])
        self.assertEqual(parse_timetable(""), [])

    def test_bad_entries_skipped(self):
        got = parse_timetable("Ok|07:00|08:00;Sai|08:00;Ngược|10:00|09:00;|07:00|08:00;Giờ|25:00|26:00")
        self.assertEqual(got, [("Ok", 420, 480)])


class SessionTests(Base):

    def at(self, h, m=0):
        self.clock.t = datetime.datetime(2026, 10, 6, h, m, 0).timestamp()

    def settle(self, e, seed):
        for _ in range(8):
            self.step(e, seed)

    def test_no_timetable_behaves_like_before(self):
        e = self.make(require_liveness=False)
        self.settle(e, 1)
        row = self.db.conn.execute("SELECT session FROM attendance").fetchone()
        self.assertEqual(row, ("",))

    def test_outside_hours_no_attendance_and_hint(self):
        e = self.make(require_liveness=False, timetable=TT)
        self.at(12, 0)
        self.settle(e, 1)
        self.assertEqual(self.db.attendance_on("2026-10-06"), [])
        self.assertTrue(any("Ngoài giờ" in x[2] for x in self.events(e, "status")))
        self.assertIn("ngoài giờ", e.mark_manual("SV01", "thử").lower())

    def test_same_student_can_attend_both_sessions(self):
        e = self.make(require_liveness=False, timetable=TT)
        self.at(8, 0);  self.settle(e, 1)
        self.at(14, 0); self.settle(e, 1)
        rows = self.db.attendance_on("2026-10-06")
        self.assertEqual([(r["student_id"], r["session"]) for r in rows],
                         [("SV01", "Ca sáng"), ("SV01", "Ca chiều")])

    def test_second_attendance_in_same_session_rejected(self):
        e = self.make(require_liveness=False, timetable=TT)
        self.at(8, 0);  self.settle(e, 1)
        self.at(9, 0);  self.settle(e, 1)
        self.assertEqual(len(self.db.attendance_on("2026-10-06")), 1)

    def test_early_arrival_allowed(self):
        e = self.make(require_liveness=False, timetable=TT, session_early_minutes=15)
        self.at(6, 50); self.settle(e, 1)
        self.assertEqual(len(self.db.attendance_on("2026-10-06")), 1)
        e2 = self.make(require_liveness=False, timetable=TT, session_early_minutes=5)
        self.db.remove_attendance("SV01", "2026-10-06", "Ca sáng")
        e2.reload()
        self.at(6, 50); self.settle(e2, 1)
        self.assertEqual(len(self.db.attendance_on("2026-10-06")), 0)

    def test_late_is_relative_to_each_session_start(self):
        e = self.make(require_liveness=False, timetable=TT, late_after_minutes=15)
        self.at(7, 10);  self.settle(e, 1)       # đúng giờ ca sáng
        self.at(13, 30); self.settle(e, 1)       # muộn 30 phút ca chiều
        st = {r["session"]: r["status"] for r in self.db.attendance_on("2026-10-06")}
        self.assertEqual(st, {"Ca sáng": "present", "Ca chiều": "late"})

    def test_marked_set_follows_session_change(self):
        e = self.make(require_liveness=False, timetable=TT)
        self.at(8, 0);  self.settle(e, 1)
        self.assertIn("SV01", e.marked_today)
        self.at(14, 0); self.step(e, 555)
        self.assertNotIn("SV01", e.marked_today)

    def test_manual_and_unmark_apply_to_current_session(self):
        e = self.make(timetable=TT)
        self.at(8, 0)
        self.assertIsNone(e.mark_manual("SV01", "khẩu trang"))
        self.at(14, 0)
        self.assertIsNone(e.mark_manual("SV01", "khẩu trang"))
        self.assertIsNone(e.unmark_today("SV01"))             # chỉ hủy ca chiều
        rows = self.db.attendance_on("2026-10-06")
        self.assertEqual([r["session"] for r in rows], ["Ca sáng"])

    def test_statistics_count_each_session_as_a_lesson(self):
        d = self.db
        D = datetime.datetime
        d.mark_attendance("SV01", D(2026, 10, 6, 8, 0, 0), session="Ca sáng")
        d.mark_attendance("SV01", D(2026, 10, 6, 14, 0, 0), session="Ca chiều")
        d.mark_attendance("SV02", D(2026, 10, 6, 8, 5, 0), session="Ca sáng")
        st = d.statistics()
        self.assertEqual(st["days"], ["2026-10-06|Ca sáng", "2026-10-06|Ca chiều"])
        per = {p["student_id"]: p for p in st["per_student"]}
        self.assertEqual((per["SV01"]["sessions"], per["SV01"]["present"]), (2, 2))
        self.assertEqual((per["SV02"]["present"], per["SV02"]["absent"]), (1, 1))
        self.assertEqual(per["SV02"]["absent_days"], ["2026-10-06|Ca chiều"])

    def test_excel_has_one_column_per_session(self):
        import openpyxl
        D = datetime.datetime
        self.db.mark_attendance("SV01", D(2026, 10, 6, 8, 0, 0), session="Ca sáng")
        self.db.mark_attendance("SV01", D(2026, 10, 6, 14, 0, 0), session="Ca chiều")
        out = os.path.join(self.dir, "o.xlsx")
        self.db.export_excel(out)
        ws = openpyxl.load_workbook(out)["Diem Danh"]
        hdr = [c.value for c in ws[1]]
        self.assertIn("06/10/2026 · Ca sáng", hdr)
        self.assertIn("06/10/2026 · Ca chiều", hdr)

    def test_slot_helpers(self):
        self.assertEqual(db.slot_of("2026-10-06"), "2026-10-06")
        self.assertEqual(db.split_slot("2026-10-06|Ca sáng"), ("2026-10-06", "Ca sáng"))
        self.assertEqual(db.slot_label("2026-10-06|Ca sáng", with_year=False), "06/10 · Ca sáng")


class SessionMigrationTests(unittest.TestCase):

    def test_old_unique_constraint_replaced_without_losing_rows(self):
        d = tempfile.mkdtemp()
        try:
            path = os.path.join(d, "old.db")
            c = sqlite3.connect(path)
            c.executescript("""
                CREATE TABLE students (student_id TEXT PRIMARY KEY, name TEXT NOT NULL,
                  class_name TEXT NOT NULL DEFAULT '', faculty TEXT NOT NULL DEFAULT '',
                  active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL);
                CREATE TABLE attendance (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  student_id TEXT NOT NULL, day TEXT NOT NULL, time TEXT NOT NULL,
                  distance REAL, UNIQUE (student_id, day));
                INSERT INTO students VALUES ('SV01','An','K1','X',1,'2026-01-01T00:00:00');
                INSERT INTO attendance(student_id, day, time) VALUES ('SV01','2026-10-02','08:00:00');
            """)
            c.commit(); c.close()
            x = db.Database(path)
            self.assertEqual(len(x.attendance_on("2026-10-02")), 1)
            # sau migration, cùng ngày nhưng khác ca thì được phép
            self.assertTrue(x.mark_attendance("SV01", datetime.datetime(2026, 10, 2, 14, 0, 0), session="Ca chiều"))
            # trùng ca thì không
            self.assertFalse(x.mark_attendance("SV01", datetime.datetime(2026, 10, 2, 15, 0, 0), session="Ca chiều"))
            x.close()
            x = db.Database(path)                  # mở lại không lỗi
            self.assertEqual(len(x.attendance_on("2026-10-02")), 2)
            x.close()
        finally:
            shutil.rmtree(d, ignore_errors=True)


# =========================================================
# MÃ HÓA VECTOR
# =========================================================
class EncryptionTests(unittest.TestCase):

    def setUp(self):
        self.dir = tempfile.mkdtemp()
        self.path = os.path.join(self.dir, "e.db")

    def tearDown(self):
        shutil.rmtree(self.dir, ignore_errors=True)

    def cipher(self, b=b"k" * 32):
        return secure.EmbeddingCipher(b)

    def test_roundtrip_and_ciphertext_differs(self):
        c = self.cipher()
        blob = c.encrypt(b"hello" * 50, b"SV01")
        self.assertTrue(secure.is_encrypted(blob))
        self.assertNotIn(b"hello", blob)
        self.assertEqual(c.decrypt(blob, b"SV01"), b"hello" * 50)
        self.assertNotEqual(blob, c.encrypt(b"hello" * 50, b"SV01"))      # nonce ngẫu nhiên

    def test_wrong_key_and_tamper_and_wrong_aad_fail(self):
        c = self.cipher()
        blob = c.encrypt(b"x" * 100, b"SV01")
        with self.assertRaises(secure.WrongKeyError):
            self.cipher(b"z" * 32).decrypt(blob, b"SV01")
        with self.assertRaises(secure.WrongKeyError):
            c.decrypt(blob, b"SV02")
        bad = bytearray(blob); bad[-1] ^= 1
        with self.assertRaises(secure.WrongKeyError):
            c.decrypt(bytes(bad), b"SV01")

    def test_plain_legacy_blob_passes_through(self):
        raw = np.arange(128, dtype=np.float64).tobytes()
        self.assertFalse(secure.is_encrypted(raw))
        self.assertEqual(self.cipher().decrypt(raw), raw)

    def test_database_stores_ciphertext_and_reads_back(self):
        d = db.Database(self.path, cipher=self.cipher())
        d.add_student("SV01", "An", "K1", "X", [enc(1), enc(1, .01)])
        blob = d.conn.execute("SELECT encoding FROM face_samples").fetchone()[0]
        self.assertTrue(secure.is_encrypted(blob))
        ids, m = d.load_face_index()
        self.assertEqual(ids, ["SV01", "SV01"])
        np.testing.assert_allclose(m[0], enc(1))
        d.close()

    def test_without_key_encrypted_db_refuses_clearly(self):
        d = db.Database(self.path, cipher=self.cipher())
        d.add_student("SV01", "An", "K1", "X", [enc(1)])
        d.close()
        d = db.Database(self.path)
        with self.assertRaises(secure.WrongKeyError):
            d.load_face_index()
        d.close()

    def test_vectors_cannot_be_swapped_between_students(self):
        d = db.Database(self.path, cipher=self.cipher())
        d.add_student("SV01", "An", "K1", "X", [enc(1)])
        d.add_student("SV02", "Bình", "K1", "X", [enc(2)])
        b1 = d.conn.execute("SELECT encoding FROM face_samples WHERE student_id='SV01'").fetchone()[0]
        d.conn.execute("UPDATE face_samples SET encoding=? WHERE student_id='SV02'", (b1,))
        with self.assertRaises(secure.WrongKeyError):
            d.load_face_index()
        d.close()

    def test_encrypt_existing_migrates_plain_data(self):
        d = db.Database(self.path)
        d.add_student("SV01", "An", "K1", "X", [enc(1), enc(1, .01)])
        d.cipher = self.cipher()
        self.assertEqual(d.encrypt_existing(), 2)
        self.assertEqual(d.encrypt_existing(), 0)             # lần hai không còn gì
        ids, m = d.load_face_index()
        np.testing.assert_allclose(m[1], enc(1, .01))
        d.close()

    def test_key_file_created_once_with_private_mode(self):
        p = os.path.join(self.dir, "data.key")
        k1 = secure.load_or_create_key(p)
        k2 = secure.load_or_create_key(p)
        self.assertEqual(k1, k2)
        self.assertEqual(len(k1), 32)
        if os.name == "posix":
            self.assertEqual(os.stat(p).st_mode & 0o077, 0)

    def test_passphrase_changes_key_but_same_passphrase_is_stable(self):
        p = os.path.join(self.dir, "data.key")
        a = secure.load_or_create_key(p, "mat khau")
        b = secure.load_or_create_key(p, "mat khau")
        c = secure.load_or_create_key(p, "khac")
        self.assertEqual(a, b)
        self.assertNotEqual(a, c)
        self.assertNotEqual(a, secure.load_or_create_key(p))

    def test_invalid_key_file_rejected(self):
        p = os.path.join(self.dir, "bad.key")
        open(p, "wb").write(b"short")
        with self.assertRaises(ValueError):
            secure.load_or_create_key(p)

    def test_make_cipher_respects_config(self):
        self.assertIsNone(secure.make_cipher(Config(encrypt_embeddings=False), self.dir))
        c = secure.make_cipher(Config(), self.dir)
        self.assertIsNotNone(c)
        self.assertTrue(os.path.exists(os.path.join(self.dir, "data.key")))

    def test_backup_of_encrypted_db_is_still_encrypted(self):
        d = db.Database(self.path, cipher=self.cipher())
        d.add_student("SV01", "An", "K1", "X", [enc(1)])
        p = d.backup(os.path.join(self.dir, "bk"), keep=2, today=datetime.date(2026, 10, 1))
        c = sqlite3.connect(p)
        self.assertTrue(secure.is_encrypted(c.execute("SELECT encoding FROM face_samples").fetchone()[0]))
        c.close(); d.close()


# =========================================================
# LƯU GIỮ DỮ LIỆU
# =========================================================
class RetentionTests(unittest.TestCase):

    def test_purges_only_old_rows_and_logs(self):
        d = tempfile.mkdtemp()
        try:
            x = db.Database(os.path.join(d, "r.db"))
            x.add_student("SV01", "An", "K1", "X", [enc(1)])
            D = datetime.datetime
            x.mark_attendance("SV01", D(2026, 1, 1, 8, 0, 0))
            x.mark_attendance("SV01", D(2026, 10, 1, 8, 0, 0))
            self.assertEqual(x.apply_retention(0, datetime.date(2026, 10, 6)), 0)
            self.assertEqual(x.apply_retention(30, datetime.date(2026, 10, 6)), 1)
            self.assertEqual([r["time"] for r in x.attendance_on("2026-10-01")], ["08:00:00"])
            self.assertEqual(x.attendance_on("2026-01-01"), [])
            self.assertEqual(len(x.recent_events(kind="retention_purge")), 1)
            x.close()
        finally:
            shutil.rmtree(d, ignore_errors=True)


# =========================================================
# MÔ HÌNH NHẬN DIỆN THEO BACKEND
# =========================================================
def unit(seed, dim=512, noise=0.0):
    v = np.random.RandomState(seed).normal(0, 1, dim)
    if noise:
        v = v + np.random.RandomState(seed + 999).normal(0, noise, dim)
    return v / np.linalg.norm(v)


class ModelColumnTests(unittest.TestCase):

    def setUp(self):
        self.dir = tempfile.mkdtemp()
        self.db = db.Database(os.path.join(self.dir, "m.db"))

    def tearDown(self):
        self.db.close(); shutil.rmtree(self.dir, ignore_errors=True)

    def test_models_are_kept_separate(self):
        self.db.add_student("SV01", "An", "K1", "X", [enc(1)], model="dlib")
        self.db.add_samples("SV01", [unit(1)], model="arcface")
        ids, m = self.db.load_face_index("dlib")
        self.assertEqual((len(ids), m.shape[1]), (1, 128))
        ids, m = self.db.load_face_index("arcface", 512)
        self.assertEqual((len(ids), m.shape[1]), (1, 512))
        self.assertEqual(self.db.sample_count("SV01"), 2)
        self.assertEqual(self.db.sample_count("SV01", "arcface"), 1)

    def test_empty_index_has_right_dimension(self):
        ids, m = self.db.load_face_index("arcface", 512)
        self.assertEqual(m.shape, (0, 512))

    def test_max_samples_applies_per_model(self):
        self.db.add_student("SV01", "An", "K1", "X", [enc(1), enc(2), enc(3)], model="dlib")
        self.db.add_samples("SV01", [unit(i) for i in range(4)], max_samples=2, model="arcface")
        self.assertEqual(self.db.sample_count("SV01", "dlib"), 3)       # không bị ảnh hưởng
        self.assertEqual(self.db.sample_count("SV01", "arcface"), 2)

    def test_list_students_counts_by_model(self):
        self.db.add_student("SV01", "An", "K1", "X", [enc(1)], model="dlib")
        self.assertEqual(self.db.list_students()[0]["samples"], 1)
        self.assertEqual(self.db.list_students(model="arcface")[0]["samples"], 0)

    def test_old_database_gets_model_column_defaulting_to_dlib(self):
        p = os.path.join(self.dir, "o.db")
        c = sqlite3.connect(p)
        c.executescript("""
            CREATE TABLE students (student_id TEXT PRIMARY KEY, name TEXT NOT NULL,
              class_name TEXT NOT NULL DEFAULT '', faculty TEXT NOT NULL DEFAULT '',
              active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL);
            CREATE TABLE face_samples (id INTEGER PRIMARY KEY AUTOINCREMENT,
              student_id TEXT NOT NULL, encoding BLOB NOT NULL);
            INSERT INTO students VALUES ('SV01','An','K1','X',1,'2026-01-01T00:00:00');
        """)
        c.execute("INSERT INTO face_samples(student_id, encoding) VALUES (?, ?)",
                  ("SV01", np.arange(128, dtype=np.float64).tobytes()))
        c.commit(); c.close()
        x = db.Database(p)
        ids, m = x.load_face_index("dlib")
        self.assertEqual(ids, ["SV01"])
        x.close()


class ArcFaceEngineTests(unittest.TestCase):
    """Engine với backend arcface: vector 512 chiều, ngưỡng riêng, thu mẫu lại."""

    def setUp(self):
        self.dir = tempfile.mkdtemp()
        self.db = db.Database(os.path.join(self.dir, "a.db"))
        self.clock = Clock()

    def tearDown(self):
        self.db.close(); shutil.rmtree(self.dir, ignore_errors=True)

    def eng(self, **cfg):
        return Engine(self.db, Config(backend="arcface", require_liveness=False, **cfg), clock=self.clock)

    def feed(self, e, vec, n=8):
        for _ in range(n):
            self.clock.advance(0.15)
            e.process([{"loc": BOX, "enc": vec, "ear": None}])

    def test_recognises_with_512d_vectors_and_arcface_thresholds(self):
        self.db.add_student("SV01", "An", "K1", "X", [unit(1), unit(1, noise=0.01)], model="arcface")
        self.db.add_student("SV02", "Bình", "K1", "X", [unit(2)], model="arcface")
        e = self.eng()
        self.assertEqual((e.model, e.dim), ("arcface", 512))
        self.feed(e, unit(1, noise=0.02))
        self.assertEqual(e.marked_today, {"SV01"})

    def test_dlib_only_students_are_flagged_and_not_recognised(self):
        self.db.add_student("SV01", "An", "K1", "X", [enc(1)], model="dlib")
        e = self.eng()
        self.assertEqual(e.unenrolled, ["SV01"])
        self.feed(e, unit(1))
        self.assertEqual(e.marked_today, set())

    def test_reenroll_adds_arcface_samples_without_old_ones_to_compare(self):
        self.db.add_student("SV01", "An", "K1", "X", [enc(1)], model="dlib")
        e = self.eng()
        self.feed(e, unit(1), n=3)
        self.assertIsNone(e.start_add_samples("SV01"))
        for _ in range(60):
            self.clock.advance(1.3)
            e.process([{"loc": BOX, "enc": unit(1, noise=0.01), "ear": None}])
        self.assertIsNone(e.capture)
        self.assertGreater(self.db.sample_count("SV01", "arcface"), 0)
        self.assertEqual(self.db.sample_count("SV01", "dlib"), 1)
        self.assertEqual(e.unenrolled, [])

    def test_reenroll_refuses_a_face_that_belongs_to_someone_else(self):
        self.db.add_student("SV01", "An", "K1", "X", [enc(1)], model="dlib")
        self.db.add_student("SV02", "Bình", "K1", "X", [unit(2)], model="arcface")
        e = self.eng()
        self.feed(e, unit(2), n=6)               # đang là Bình đứng trước camera
        e.cancel_capture()
        e.capture = None
        # mô phỏng: gắn mẫu của Bình cho An
        e._begin_capture("append", ("SV01", "An", "K1", "X"), 3)
        e.capture["samples"] = [unit(2, noise=0.01)] * 3
        e._finish_capture()
        self.assertEqual(self.db.sample_count("SV01", "arcface"), 0)

    def test_thresholds_for(self):
        self.assertEqual(backends.thresholds_for(Config()), (0.5, 0.04))
        self.assertEqual(backends.thresholds_for(Config(backend="arcface")), (1.0, 0.05))
        self.assertEqual(backends.thresholds_for(Config(backend="arcface", arcface_threshold=0.9,
                                                        arcface_margin=0.1)), (0.9, 0.1))


class BackendMathTests(unittest.TestCase):

    def marks(self):
        eye = lambda cx: [(cx - 6, 100), (cx - 2, 98), (cx + 2, 98), (cx + 6, 100), (cx + 2, 102), (cx - 2, 102)]
        top = [(80, 170), (90, 165), (100, 163), (110, 163), (120, 163), (130, 165), (140, 170)] + [(0, 0)] * 5
        return {"left_eye": eye(80), "right_eye": eye(140),
                "nose_tip": [(105, 140), (108, 142), (110, 143), (112, 142), (115, 140)],
                "top_lip": top}

    def test_five_points_order_and_values(self):
        p = backends.five_points(self.marks())
        self.assertEqual(p.shape, (5, 2))
        self.assertLess(p[0][0], p[1][0])             # mắt trái ảnh trước
        self.assertLess(p[3][0], p[4][0])             # khóe miệng trái ảnh trước
        np.testing.assert_allclose(p[2], (110, 143))
        np.testing.assert_allclose(p[3], (80, 170))

    def test_five_points_independent_of_eye_naming(self):
        m = self.marks()
        swapped = dict(m, left_eye=m["right_eye"], right_eye=m["left_eye"])
        np.testing.assert_allclose(backends.five_points(m), backends.five_points(swapped))

    def test_five_points_missing_returns_none(self):
        self.assertIsNone(backends.five_points({}))
        self.assertIsNone(backends.five_points({"left_eye": [(0, 0)]}))

    def test_align_maps_points_onto_template(self):
        import cv2
        img = np.zeros((300, 300, 3), np.uint8)
        pts = backends.ARCFACE_TEMPLATE * 1.5 + np.array([60, 40], np.float32)   # khuôn mặt đã phóng to/dịch chuyển
        for x, y in pts:
            cv2.circle(img, (int(round(x)), int(round(y))), 3, (255, 255, 255), -1)
        a = backends.align_face(img, pts)
        self.assertEqual(a.shape, (112, 112, 3))
        for x, y in backends.ARCFACE_TEMPLATE:
            self.assertGreater(a[int(round(y)), int(round(x))].max(), 100)     # chấm trắng nằm đúng chỗ chuẩn

    def test_preprocess_range_and_layout(self):
        blob = backends.preprocess_arcface(np.full((112, 112, 3), 255, np.uint8))
        self.assertEqual(blob.shape, (1, 3, 112, 112))
        self.assertAlmostEqual(float(blob.max()), 1.0, places=5)
        b = np.zeros((112, 112, 3), np.uint8); b[:, :, 0] = 255                  # BGR: xanh dương
        blob = backends.preprocess_arcface(b)
        self.assertAlmostEqual(float(blob[0, 2].max()), 1.0, places=5)           # sau đảo kênh nằm ở kênh RGB thứ 3

    def test_l2_normalize(self):
        v = backends.l2_normalize([3, 4])
        self.assertAlmostEqual(float(np.linalg.norm(v)), 1.0)
        self.assertEqual(float(np.linalg.norm(backends.l2_normalize([0, 0]))), 0.0)

    def test_arcface_missing_model_gives_clear_error(self):
        with self.assertRaises(FileNotFoundError) as cm:
            backends.ArcFaceBackend("/nonexistent/x.onnx")
        self.assertIn("get_models", str(cm.exception))

    def test_make_backend_default_is_dlib(self):
        self.assertEqual(backends.make_backend(Config()).name, "dlib")


@unittest.skipUnless(HAVE_MODELS, "chưa tải mô hình (python tools/get_models.py)")
class RealModelSmokeTests(unittest.TestCase):
    """Chạy mô hình ONNX thật: kiểm tra hình dạng, chuẩn hóa, tính ổn định."""

    @classmethod
    def setUpClass(cls):
        import cv2
        from skimage import data
        cls.cv2 = cv2
        cls.img = cv2.cvtColor(data.astronaut(), cv2.COLOR_RGB2BGR)
        cls.pts = np.array([[200, 102], [247, 103], [220, 125], [199, 143], [240, 144]], np.float32)

    def test_arcface_embedding_is_unit_and_stable(self):
        b = backends.ArcFaceBackend(os.path.join(MODELS, "w600k_mbf.onnx"))
        e0 = b.embed_aligned(backends.align_face(self.img, self.pts))
        self.assertEqual(e0.shape, (512,))
        self.assertAlmostEqual(float(np.linalg.norm(e0)), 1.0, places=4)
        np.testing.assert_allclose(e0, b.embed_aligned(backends.align_face(self.img, self.pts)), atol=1e-5)
        dim = self.img * 0.7
        e1 = b.embed_aligned(backends.align_face(dim.astype(np.uint8), self.pts))
        self.assertLess(np.linalg.norm(e1 - e0), 0.6)                  # cùng khuôn mặt, tối hơn: vẫn gần
        noise = (np.random.RandomState(0).rand(112, 112, 3) * 255).astype(np.uint8)
        self.assertGreater(np.linalg.norm(b.embed_aligned(noise) - e0), 1.2)    # không phải mặt: xa

    def test_antispoof_returns_probability(self):
        sp = antispoof.PassiveAntiSpoof(MODELS)
        p = sp.real_probability(self.img, [180, 80, 270, 170])
        self.assertTrue(0.0 <= p <= 1.0)
        self.assertEqual(len(sp.sessions), 2)

    def test_antispoof_missing_model_gives_clear_error(self):
        with self.assertRaises(FileNotFoundError):
            antispoof.PassiveAntiSpoof(os.path.join(MODELS, "khong_co"))


class AntiSpoofMathTests(unittest.TestCase):

    def test_softmax(self):
        p = antispoof.softmax(np.array([[1.0, 2.0, 3.0]]))
        self.assertAlmostEqual(float(p.sum()), 1.0)
        self.assertGreater(p[0, 2], p[0, 0])
        big = antispoof.softmax(np.array([[1000.0, 1001.0, 999.0]]))      # không tràn số
        self.assertTrue(np.isfinite(big).all())

    def test_crop_scales_and_stays_in_image(self):
        img = np.zeros((200, 300, 3), np.uint8)
        out = antispoof.crop_for_spoof(img, [100, 50, 140, 100], 2.7, (80, 80))
        self.assertEqual(out.shape, (80, 80, 3))
        edge = antispoof.crop_for_spoof(img, [0, 0, 60, 60], 4.0, (80, 80))   # sát mép vẫn an toàn
        self.assertEqual(edge.shape, (80, 80, 3))

    def test_crop_is_larger_than_face_box(self):
        img = np.zeros((400, 400, 3), np.uint8)
        img[150:250, 150:250] = 255                       # "mặt" trắng 100x100
        small = antispoof.crop_for_spoof(img, [150, 150, 250, 250], 1.0, (80, 80))
        wide = antispoof.crop_for_spoof(img, [150, 150, 250, 250], 2.7, (80, 80))
        self.assertGreater(small.mean(), wide.mean())     # vùng rộng hơn chứa nhiều nền đen hơn


# =========================================================
# CHỐNG GIẢ MẠO THỤ ĐỘNG TRONG ENGINE
# =========================================================
class PassiveSpoofEngineTests(Base):

    def run_frames(self, e, spoof, n=10, ear=None):
        for _ in range(n):
            self.clock.advance(0.15)
            e.process([{"loc": BOX, "enc": enc(1, 0.015), "ear": ear, "spoof": spoof}])

    def test_disabled_by_default_ignores_scores(self):
        e = self.make(require_liveness=False)
        self.run_frames(e, 0.01)
        self.assertEqual(e.marked_today, {"SV01"})

    def test_low_score_blocks_attendance(self):
        e = self.make(require_liveness=False, antispoof_enable=True, require_liveness_=None) if False else \
            self.make(require_liveness=True, antispoof_enable=True, antispoof_threshold=0.7)
        for i in range(30):
            self.clock.advance(0.15)
            e.process([{"loc": BOX, "enc": enc(1, 0.015), "ear": 0.1 if i % 3 == 0 else 0.3, "spoof": 0.2}])
        self.assertEqual(e.marked_today, set())

    def test_high_score_plus_blink_allows_attendance(self):
        e = self.make(require_liveness=True, antispoof_enable=True, antispoof_threshold=0.7)
        for _ in range(8):
            self.clock.advance(0.15)
            e.process([{"loc": BOX, "enc": enc(1, 0.015), "ear": 0.3, "spoof": 0.95}])
        for ear in (0.1, 0.3, 0.3):
            self.clock.advance(0.15)
            e.process([{"loc": BOX, "enc": enc(1, 0.015), "ear": ear, "spoof": 0.95}])
        self.assertEqual(e.marked_today, {"SV01"})

    def test_blink_alone_not_enough_when_spoof_score_low(self):
        e = self.make(require_liveness=True, antispoof_enable=True)
        self.blink_sequence_with_spoof(e, 0.3)
        self.assertEqual(e.marked_today, set())

    def blink_sequence_with_spoof(self, e, sp):
        for ear in [0.3] * 8 + [0.1, 0.3, 0.3]:
            self.clock.advance(0.15)
            e.process([{"loc": BOX, "enc": enc(1, 0.015), "ear": ear, "spoof": sp}])

    def test_needs_a_full_window_of_scores(self):
        e = self.make(require_liveness=True, antispoof_enable=True, antispoof_frames=5)
        self.assertFalse(e._spoof_ok(e._pstate))
        for _ in range(4):
            e._pstate.spoof.append(0.99)
        self.assertFalse(e._spoof_ok(e._pstate))
        e._pstate.spoof.append(0.99)
        self.assertTrue(e._spoof_ok(e._pstate))

    def test_average_not_single_frame(self):
        e = self.make(antispoof_enable=True, antispoof_frames=4, antispoof_threshold=0.7)
        for v in (0.9, 0.9, 0.9, 0.1):
            e._pstate.spoof.append(v)
        self.assertTrue(e._spoof_ok(e._pstate))          # trung bình 0.7 -> đạt
        e._pstate.spoof.append(0.1)
        self.assertFalse(e._spoof_ok(e._pstate))

    def test_suspected_spoof_is_audited_once(self):
        e = self.make(require_liveness=True, antispoof_enable=True)
        e.actor = "gv1"
        self.run_frames(e, 0.1, n=40, ear=0.3)
        rows = self.db.recent_events(kind="spoof_suspect")
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["actor"], "gv1")

    def test_prompt_tells_user_what_to_do(self):
        e = self.make(require_liveness=True, antispoof_enable=True, antispoof_frames=3)
        self.assertIn("Giữ yên", e.liveness_prompt())
        for _ in range(3):
            e._pstate.spoof.append(0.05)
        self.assertIn("khuôn mặt thật", e.liveness_prompt())

    def test_switching_person_clears_scores(self):
        e = self.make(require_liveness=True, antispoof_enable=True)
        self.run_frames(e, 0.9, n=8, ear=0.3)
        for _ in range(8):
            self.clock.advance(0.15)
            e.process([{"loc": BOX, "enc": enc(2, 0.015), "ear": 0.3, "spoof": None}])
        self.assertEqual(len(e._pstate.spoof), 0)

    def test_liveness_toggle_off_disables_spoof_check_too(self):
        e = self.make(require_liveness=False, antispoof_enable=True)
        self.run_frames(e, 0.0, n=10)
        self.assertEqual(e.marked_today, {"SV01"})


# =========================================================
# FaceDetector: backend, nhiều mặt, chống giả mạo
# =========================================================
class FaceDetectorV3Tests(unittest.TestCase):

    def run_det(self, det, fr, frame=None):
        cv2 = MagicMock()
        cv2.resize.side_effect = lambda f, dsize, fx, fy: f[::2, ::2]
        cv2.cvtColor.side_effect = lambda im, code: im[:, :, 0]
        cv2.Laplacian.return_value = np.ones((4, 4))
        saved = {k: sys.modules.get(k) for k in ("cv2", "face_recognition")}
        sys.modules["cv2"], sys.modules["face_recognition"] = cv2, fr
        try:
            return det(np.zeros((480, 640, 3), np.uint8) if frame is None else frame)
        finally:
            for k, v in saved.items():
                if v is None: sys.modules.pop(k, None)
                else: sys.modules[k] = v

    def fr_mock(self, locs):
        fr = MagicMock()
        fr.face_locations.return_value = locs
        eye = [(0, 0), (1, -1), (2, -1), (3, 0), (2, 1), (1, 1)]
        fr.face_landmarks.side_effect = lambda img, ls: [{"left_eye": eye, "right_eye": eye} for _ in ls]
        return fr

    def test_pose_for_top_n_faces_only(self):
        from vision import FaceDetector
        locs = [(10, 40, 40, 10), (20, 140, 140, 20), (10, 100, 100, 10)]
        fr = self.fr_mock(locs)
        fr.face_encodings.return_value = ["a", "b", "c"]
        res = self.run_det(FaceDetector(scale=0.5, max_faces=2), fr)
        have = [d["ear"] is not None for d in res["dets"]]
        self.assertEqual(have, [False, True, True])            # hai mặt lớn nhất có đo
        self.assertEqual(len(fr.face_landmarks.call_args[0][1]), 2)

    def test_drops_faces_whose_encoding_failed(self):
        from vision import FaceDetector

        class B:
            name = "x"; needs_full_res = False
            def encode(self, rgb, locs): return ["ok", None]
        fr = self.fr_mock([(10, 60, 60, 10), (20, 140, 140, 20)])
        res = self.run_det(FaceDetector(backend=B()), fr)
        self.assertEqual([d["enc"] for d in res["dets"]], ["ok"])

    def test_full_resolution_backend_gets_scaled_locations(self):
        from vision import FaceDetector
        seen = {}

        class B:
            name = "x"; needs_full_res = True
            def encode(self, rgb, locs):
                seen["shape"], seen["locs"] = rgb.shape, locs
                return ["v"] * len(locs)
        fr = self.fr_mock([(10, 60, 60, 10)])
        self.run_det(FaceDetector(scale=0.5, backend=B()), fr)
        self.assertEqual(seen["shape"], (480, 640, 3))
        self.assertEqual(seen["locs"], [(20, 120, 120, 20)])

    def test_antispoof_called_with_full_res_xyxy_box(self):
        from vision import FaceDetector
        calls = []

        class S:
            def real_probability(self, frame, box):
                calls.append(box); return 0.8
        fr = self.fr_mock([(10, 60, 60, 10)])
        fr.face_encodings.return_value = ["a"]
        res = self.run_det(FaceDetector(scale=0.5, antispoof=S()), fr)
        self.assertEqual(calls, [[20, 20, 120, 120]])            # [left, top, right, bottom]
        self.assertEqual(res["dets"][0]["spoof"], 0.8)

    def test_antispoof_error_does_not_break_detection(self):
        from vision import FaceDetector

        class S:
            def real_probability(self, frame, box): raise RuntimeError("boom")
        fr = self.fr_mock([(10, 60, 60, 10)])
        fr.face_encodings.return_value = ["a"]
        res = self.run_det(FaceDetector(antispoof=S()), fr)
        self.assertEqual(len(res["dets"]), 1)
        self.assertIsNone(res["dets"][0]["spoof"])


if __name__ == "__main__":
    unittest.main()
