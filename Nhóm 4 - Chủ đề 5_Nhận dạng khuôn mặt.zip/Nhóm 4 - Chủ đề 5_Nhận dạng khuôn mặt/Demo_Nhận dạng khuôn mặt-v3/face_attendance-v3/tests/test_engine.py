import datetime
import os
import shutil
import tempfile
import unittest

import db
from config import Config
from engine import Engine
from tests.helpers import BOX, SMALL_BOX, enc


class Clock:
    def __init__(self, t=None): self.t = t or datetime.datetime(2026, 10, 6, 8, 0, 0).timestamp()
    def __call__(self): return self.t
    def advance(self, s): self.t += s


class Base(unittest.TestCase):

    def setUp(self):
        self.dir = tempfile.mkdtemp()
        self.db = db.Database(os.path.join(self.dir, "t.db"))
        self.clock = Clock()
        self.db.add_student("SV01", "An", "K1", "X", [enc(1, .01), enc(1, .02)])
        self.db.add_student("SV02", "Bình", "K1", "X", [enc(2, .01), enc(2, .02)])

    def tearDown(self):
        self.db.close(); shutil.rmtree(self.dir, ignore_errors=True)

    def make(self, **cfg):
        e = Engine(self.db, Config(**cfg), clock=self.clock)
        return e

    def step(self, e, seed, ear=None, noise=0.015, dt=0.15, box=BOX):
        self.clock.advance(dt)
        e.process([{"loc": box, "enc": enc(seed, noise), "ear": ear}])

    def events(self, e, kind=None):
        ev = e.pop_events()
        return [x for x in ev if kind is None or x[0] == kind]

    def blink_sequence(self, e, seed):
        for _ in range(8): self.step(e, seed, ear=0.30)
        self.step(e, seed, ear=0.10)
        self.step(e, seed, ear=0.30)


class RecognitionTests(Base):

    def test_needs_several_frames_then_confirms(self):
        e = self.make(require_liveness=False, auto_attendance=False)
        self.step(e, 1); self.assertIsNone(e.current_student); self.assertEqual(e.faces[0]["label"], "Đang xác nhận…")
        for _ in range(3): self.step(e, 1)
        self.assertEqual(e.current_student, "SV01"); self.assertEqual(e.faces[0]["label"], "An"); self.assertTrue(e.faces[0]["known"])

    def test_stranger_never_confirmed(self):
        e = self.make(require_liveness=False)
        for _ in range(10): self.step(e, 555)
        self.assertIsNone(e.current_student); self.assertEqual(e.faces[0]["label"], "Chưa đăng ký")
        self.assertEqual(self.db.attendance_days(), [])

    def test_person_swap_not_confirmed_immediately(self):
        e = self.make(require_liveness=False, auto_attendance=False)
        for _ in range(6): self.step(e, 1)
        self.assertEqual(e.current_student, "SV01")
        self.step(e, 555); self.assertIsNone(e.current_student)

    def test_biggest_face_is_primary(self):
        e = self.make(require_liveness=False, auto_attendance=False)
        for _ in range(6):
            self.clock.advance(.15)
            e.process([{"loc": SMALL_BOX, "enc": enc(2, .015), "ear": None},
                       {"loc": BOX, "enc": enc(1, .015), "ear": None}])
        self.assertEqual(e.current_student, "SV01")
        labels = {f["sid"]: f["label"] for f in e.faces}
        self.assertEqual(labels, {"SV02": "Bình", "SV01": "An"})

    def test_no_face_resets(self):
        e = self.make(require_liveness=False, auto_attendance=False)
        for _ in range(6): self.step(e, 1)
        e.process([]); self.assertIsNone(e.current_student); self.assertEqual(e.faces, [])


class AutoAttendanceTests(Base):

    def test_auto_without_liveness(self):
        e = self.make(require_liveness=False)
        for _ in range(4): self.step(e, 1)
        ev = self.events(e, "attendance")
        self.assertEqual(len(ev), 1); self.assertEqual(ev[0][1:4], ("SV01", "An", "K1"))
        self.assertIn("SV01", e.marked_today)
        for _ in range(10): self.step(e, 1)            # không ghi lại / không spam
        self.assertEqual(self.events(e, "attendance"), [])
        self.assertEqual(len(self.db.attendance_on("2026-10-06")), 1)

    def test_liveness_blocks_photo_allows_blink(self):
        e = self.make(require_liveness=True)
        for _ in range(30): self.step(e, 1, ear=0.30 + 0.005 * (-1) ** _)     # ảnh tĩnh
        self.assertEqual(self.db.attendance_days(), [])
        st = [x for x in self.events(e, "status")]
        self.assertEqual(sum("chớp mắt" in x[2] for x in st), 1)                 # gợi ý chỉ 1 lần
        self.blink_sequence(e, 1)
        self.assertEqual(self.db.attendance_days(), ["2026-10-06"])
        self.assertEqual(len(self.events(e, "attendance")), 1)

    def test_label_asks_to_blink(self):
        e = self.make(require_liveness=True)
        for _ in range(6): self.step(e, 1, ear=0.30)
        self.assertEqual(e.faces[0]["label"], "An · chớp mắt")

    def test_blink_expires(self):
        e = self.make(require_liveness=True, auto_attendance=False, liveness_window=8.0)
        self.blink_sequence(e, 1)
        self.assertTrue(e.liveness_ok())
        self.clock.advance(20); self.assertFalse(e.liveness_ok())

    def test_blink_of_a_does_not_carry_to_b(self):
        e = self.make(require_liveness=True, auto_attendance=False)
        self.blink_sequence(e, 1); self.assertTrue(e.liveness_ok())
        for _ in range(8): self.step(e, 2, ear=0.30)       # đổi sang B, B chưa chớp
        self.assertEqual(e.current_student, "SV02")
        self.assertFalse(e.liveness_ok())

    def test_auto_off_means_manual_only(self):
        e = self.make(require_liveness=False, auto_attendance=False)
        for _ in range(6): self.step(e, 1)
        self.assertEqual(self.db.attendance_days(), [])
        e.manual_attendance()
        self.assertEqual(self.db.attendance_days(), ["2026-10-06"])
        self.assertEqual(self.events(e, "status")[-1][1], "success")

    def test_new_day_allows_attendance_again(self):
        e = self.make(require_liveness=False)
        for _ in range(5): self.step(e, 1)
        self.assertIn("SV01", e.marked_today)
        self.clock.advance(24 * 3600)
        for _ in range(5): self.step(e, 1)
        self.assertEqual(len(self.db.attendance_days()), 2)

    def test_marked_today_restored_after_restart(self):
        e = self.make(require_liveness=False)
        for _ in range(5): self.step(e, 1)
        e2 = self.make(require_liveness=False)
        self.assertEqual(e2.marked_today, {"SV01"})
        self.assertEqual([r["name"] for r in e2.today_log()], ["An"])
        for _ in range(8): self.step(e2, 1)
        self.assertEqual(len(self.db.attendance_on("2026-10-06")), 1)


class ManualMessagesTests(Base):

    def msg(self, e):
        e.manual_attendance(); return self.events(e, "status")[-1][1:]

    def test_messages(self):
        e = self.make(require_liveness=True, auto_attendance=False)
        self.assertEqual(self.msg(e)[0], "error")                        # không thấy ai
        self.step(e, 1, ear=.3); self.assertIn("xác nhận", self.msg(e)[1])
        for _ in range(8): self.step(e, 1, ear=.3)
        self.assertIn("chớp mắt", self.msg(e)[1])                        # cần chớp mắt
        self.blink_sequence(e, 1); self.events(e)
        self.assertEqual(self.msg(e)[0], "success")
        self.assertIn("đã điểm danh", self.msg(e)[1])                    # lần 2
        for _ in range(8): self.step(e, 555, ear=.3)
        self.assertIn("chưa đăng ký", self.msg(e)[1])


class CaptureTests(Base):

    def run_capture(self, e, seed, n=5, box=BOX, noise=0.02):
        for i in range(n * 4):
            self.step(e, seed, ear=.3, noise=noise, dt=0.4, box=box)
            if e.capture is None: break

    def test_register_new_student_five_samples(self):
        e = self.make(require_liveness=False, auto_attendance=False)
        self.step(e, 77)
        self.assertIsNone(e.check_can_register())
        self.assertIsNone(e.start_register("SV99", "Chi", "K3", "Y"))
        self.assertIn("0/5", self.events(e, "status")[-1][2])
        self.run_capture(e, 77)
        fin = self.events(e, "capture_finished")
        self.assertEqual(len(fin), 1); self.assertTrue(fin[0][1])
        self.assertEqual(self.db.sample_count("SV99"), 5)
        self.assertIn("SV99", e.students)
        self.assertEqual(len(set(e.face_owner_ids)), 3)

    def test_prechecks(self):
        e = self.make(require_liveness=False, auto_attendance=False)
        self.assertIn("Không tìm thấy", e.check_can_register())
        e.process([{"loc": BOX, "enc": enc(1), "ear": None}, {"loc": SMALL_BOX, "enc": enc(2), "ear": None}])
        self.assertIn("nhiều hơn 1", e.check_can_register())
        for _ in range(6): self.step(e, 1)
        e.process([{"loc": BOX, "enc": enc(1, .015), "ear": None}])
        self.assertIn("đã được đăng ký", e.check_can_register())
        self.assertIn("đã được đăng ký", e.start_register("SV01", "x", "y", "z"))

    def test_duplicate_id_rejected(self):
        e = self.make(require_liveness=False, auto_attendance=False)
        self.step(e, 77)
        self.assertIn("thuộc về An", e.start_register("SV01", "x", "y", "z"))
        self.assertIsNone(e.capture)

    def test_duplicate_face_rejected(self):
        e = self.make(require_liveness=False, auto_attendance=False)
        self.step(e, 1)                       # mặt của An, chưa xác nhận nên qua được bước kiểm tra đầu
        self.assertIsNone(e.start_register("SV50", "Giả", "K", "X"))
        self.run_capture(e, 1, noise=0.012)
        fin = self.events(e, "capture_finished")
        self.assertFalse(fin[0][1]); self.assertIn("An", fin[0][3])
        self.assertIsNone(self.db.get_student("SV50"))

    def test_small_face_and_multi_face_do_not_capture(self):
        e = self.make(require_liveness=False, auto_attendance=False)
        self.step(e, 77); e.start_register("SV99", "Chi", "K3", "Y"); self.events(e)
        for _ in range(5): self.step(e, 77, dt=2, box=SMALL_BOX)
        self.assertEqual(len(e.capture["samples"]), 0)
        self.assertIn("lại gần", self.events(e, "status")[-1][2])
        self.clock.advance(2)
        e.process([{"loc": BOX, "enc": enc(77), "ear": None}, {"loc": BOX, "enc": enc(78), "ear": None}])
        self.assertEqual(len(e.capture["samples"]), 0)

    def test_capture_interval_enforced(self):
        e = self.make(require_liveness=False, auto_attendance=False)
        self.step(e, 77); e.start_register("SV99", "Chi", "K3", "Y")
        for _ in range(5): self.step(e, 77, dt=0.1)         # 0.5s < 1 khoảng 1.2s
        self.assertEqual(len(e.capture["samples"]), 1)

    def test_timeout_and_cancel(self):
        e = self.make(require_liveness=False, auto_attendance=False)
        self.step(e, 77); e.start_register("SV99", "Chi", "K3", "Y"); self.events(e)
        self.clock.advance(100); e.process([])
        self.assertIsNone(e.capture); self.assertIn("Hết thời gian", self.events(e, "status")[-1][2])
        self.step(e, 77); e.start_register("SV99", "Chi", "K3", "Y")
        e.cancel_capture(); self.assertIsNone(e.capture)
        self.assertIsNone(self.db.get_student("SV99"))

    def test_add_samples_same_person_ok(self):
        e = self.make(require_liveness=False, auto_attendance=False)
        self.step(e, 1); self.assertIsNone(e.start_add_samples("SV01"))
        self.run_capture(e, 1, noise=0.012)
        fin = self.events(e, "capture_finished")
        self.assertTrue(fin[0][1], fin); self.assertEqual(self.db.sample_count("SV01"), 7)

    def test_add_samples_wrong_person_rejected(self):
        e = self.make(require_liveness=False, auto_attendance=False)
        self.step(e, 2); self.assertIsNone(e.start_add_samples("SV01"))     # đứng trước camera là Bình
        self.run_capture(e, 2)
        fin = self.events(e, "capture_finished")
        self.assertFalse(fin[0][1]); self.assertEqual(self.db.sample_count("SV01"), 2)

    def test_add_samples_respects_max(self):
        e = self.make(require_liveness=False, auto_attendance=False, max_samples=3)
        self.step(e, 1)
        self.assertIsNone(e.start_add_samples("SV01"))
        self.assertEqual(e.capture["total"], 1)            # chỉ còn chỗ cho 1 mẫu
        e.cancel_capture()
        self.db.add_samples("SV01", [enc(1, .03)], 3)
        self.assertIn("đủ", e.start_add_samples("SV01"))
        self.assertIn("Không tìm thấy sinh viên", e.start_add_samples("NOPE"))

    def test_update_and_delete(self):
        e = self.make(require_liveness=False, auto_attendance=False)
        self.assertTrue(e.update_student("SV01", "An Mới", "K2", "Y"))
        self.assertEqual(e.students["SV01"]["name"], "An Mới")
        e.delete_student("SV01")
        self.assertNotIn("SV01", e.students); self.assertNotIn("SV01", e.face_owner_ids)
        for _ in range(8): self.step(e, 1)
        self.assertIsNone(e.current_student)


if __name__ == "__main__":
    unittest.main()
