import threading
import time
import unittest

import numpy as np

from vision import VisionPipeline


class FakeCap:
    def __init__(self, frames=None, fail_after=None):
        self.n = 0; self.opened = True; self.released = False; self.fail_after = fail_after
    def isOpened(self): return self.opened
    def read(self):
        time.sleep(0.002)
        if self.fail_after is not None and self.n >= self.fail_after:
            return False, None
        self.n += 1
        return True, np.full((4, 6, 3), self.n % 255, dtype=np.uint8)
    def release(self): self.released = True


def wait_for(cond, timeout=3.0):
    t = time.time()
    while time.time() - t < timeout:
        if cond(): return True
        time.sleep(0.005)
    return False


class PipelineTests(unittest.TestCase):

    def test_frames_and_results_flow_and_stop_releases_camera(self):
        cap = FakeCap()
        p = VisionPipeline(lambda: cap, lambda f: {"dets": [], "small_w": 3, "small_h": 2})
        p.start()
        self.assertTrue(wait_for(lambda: p.get_result()[0] > 2))
        frame, fid = p.get_frame()
        self.assertEqual(frame.shape, (4, 6, 3)); self.assertTrue(frame.flags["C_CONTIGUOUS"])
        self.assertTrue(p.camera_ok)
        p.stop()
        self.assertTrue(cap.released); self.assertFalse(p.camera_ok)

    def test_slow_detector_does_not_block_video(self):
        slow = threading.Event()
        def detect(f):
            time.sleep(0.3); return {"dets": [], "small_w": 1, "small_h": 1}
        p = VisionPipeline(lambda: FakeCap(), detect); p.start()
        time.sleep(0.5)
        _, fid = p.get_frame(); rid, _ = p.get_result()
        p.stop()
        self.assertGreater(fid, 20)       # video chạy nhanh
        self.assertLessEqual(rid, 3)      # nhận diện chậm không kéo video chậm theo

    def test_detector_exception_is_survived(self):
        calls = {"n": 0}
        def detect(f):
            calls["n"] += 1
            if calls["n"] == 1: raise RuntimeError("boom")
            return {"dets": [], "small_w": 1, "small_h": 1}
        p = VisionPipeline(lambda: FakeCap(), detect); p.start()
        self.assertTrue(wait_for(lambda: p.get_result()[0] >= 1, 5))
        p.stop()

    def test_camera_missing_then_available(self):
        state = {"n": 0}
        def opener():
            state["n"] += 1
            c = FakeCap(); c.opened = state["n"] >= 3
            return c
        p = VisionPipeline(opener, lambda f: {"dets": [], "small_w": 1, "small_h": 1}, reopen_every=0.01)
        p.start()
        self.assertTrue(wait_for(lambda: p.camera_ok, 3))
        p.stop()

    def test_camera_drops_and_reconnects(self):
        caps = []
        def opener():
            c = FakeCap(fail_after=5 if not caps else None); caps.append(c); return c
        p = VisionPipeline(opener, lambda f: {"dets": [], "small_w": 1, "small_h": 1}, reopen_every=0.01)
        p.start()
        self.assertTrue(wait_for(lambda: len(caps) >= 2, 5))
        self.assertTrue(wait_for(lambda: p.camera_ok, 3))
        p.stop()
        self.assertTrue(caps[0].released)


if __name__ == "__main__":
    unittest.main()


class FaceDetectorTests(unittest.TestCase):
    """Kiểm tra cách FaceDetector quy đổi tọa độ, dùng cv2/face_recognition giả."""

    def test_scaling_and_ear_only_for_largest(self):
        import sys
        from unittest.mock import MagicMock
        from vision import FaceDetector

        cv2 = MagicMock()
        cv2.resize.side_effect = lambda f, dsize, fx, fy: f[::2, ::2]   # thu nhỏ một nửa
        fr = MagicMock()
        small_loc = (10, 60, 60, 10)          # 50x50  (nhỏ)
        big_loc = (20, 140, 140, 20)          # 120x120 (lớn)
        fr.face_locations.return_value = [small_loc, big_loc]
        fr.face_encodings.return_value = ["encA", "encB"]
        eye = [(0, 0), (1, -1), (2, -1), (3, 0), (2, 1), (1, 1)]
        fr.face_landmarks.return_value = [{"left_eye": eye, "right_eye": eye}]

        saved = {k: sys.modules.get(k) for k in ("cv2", "face_recognition")}
        sys.modules["cv2"], sys.modules["face_recognition"] = cv2, fr
        try:
            frame = np.zeros((480, 640, 3), dtype=np.uint8)
            res = FaceDetector(scale=0.5)(frame)
        finally:
            for k, v in saved.items():
                if v is None: sys.modules.pop(k, None)
                else: sys.modules[k] = v

        self.assertEqual((res["small_w"], res["small_h"]), (320, 240))
        dets = res["dets"]
        self.assertEqual([d["enc"] for d in dets], ["encA", "encB"])
        self.assertIsNone(dets[0]["ear"])                 # mặt nhỏ: không tính mắt
        self.assertGreater(dets[1]["ear"], 0.5)           # mặt lớn: có EAR
        # landmarks được lấy trên ảnh gốc => tọa độ nhân 2 và truyền đúng mặt lớn
        args = fr.face_landmarks.call_args[0]
        self.assertEqual(args[1], [(40, 280, 280, 40)])
        self.assertEqual(args[0].shape, (480, 640, 3))

    def test_no_faces(self):
        import sys
        from unittest.mock import MagicMock
        from vision import FaceDetector
        cv2 = MagicMock(); cv2.resize.side_effect = lambda f, dsize, fx, fy: f[::2, ::2]
        fr = MagicMock(); fr.face_locations.return_value = []; fr.face_encodings.return_value = []
        saved = {k: sys.modules.get(k) for k in ("cv2", "face_recognition")}
        sys.modules["cv2"], sys.modules["face_recognition"] = cv2, fr
        try:
            res = FaceDetector()(np.zeros((480, 640, 3), dtype=np.uint8))
        finally:
            for k, v in saved.items():
                if v is None: sys.modules.pop(k, None)
                else: sys.modules[k] = v
        self.assertEqual(res["dets"], []); fr.face_landmarks.assert_not_called()
