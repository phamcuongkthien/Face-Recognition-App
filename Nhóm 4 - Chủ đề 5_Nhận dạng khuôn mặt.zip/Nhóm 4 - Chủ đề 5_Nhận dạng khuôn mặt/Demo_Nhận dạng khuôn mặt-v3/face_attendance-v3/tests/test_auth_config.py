import json
import os
import shutil
import tempfile
import unittest

import auth
from config import Config, DEFAULTS


class AuthTests(unittest.TestCase):

    def test_hash(self):
        h = auth.hash_password("Secret123")
        self.assertNotIn("Secret123", h)
        self.assertTrue(auth.verify_password("Secret123", h))
        self.assertFalse(auth.verify_password("secret123", h))
        self.assertFalse(auth.verify_password("x", "rác"))
        self.assertNotEqual(auth.hash_password("a"), auth.hash_password("a"))  # salt khác nhau

    def test_throttle(self):
        t = [0.0]
        th = auth.LoginThrottle(3, 30, clock=lambda: t[0])
        for _ in range(2): th.failure("u")
        self.assertEqual(th.seconds_locked("u"), 0)
        th.failure("u")
        self.assertGreater(th.seconds_locked("u"), 0)
        self.assertEqual(th.seconds_locked("other"), 0)
        t[0] = 31
        self.assertEqual(th.seconds_locked("u"), 0)
        th.failure("u"); th.success("u"); th.failure("u")
        self.assertEqual(th.seconds_locked("u"), 0)


class ConfigTests(unittest.TestCase):

    def setUp(self): self.d = tempfile.mkdtemp()
    def tearDown(self): shutil.rmtree(self.d, ignore_errors=True)

    def write(self, text):
        with open(os.path.join(self.d, "config.json"), "w", encoding="utf-8") as f: f.write(text)

    def test_defaults_without_file(self):
        c = Config.load(self.d)
        for k, v in DEFAULTS.items(): self.assertEqual(getattr(c, k), v)

    def test_override_and_bad_values_ignored(self):
        self.write(json.dumps({"match_threshold": 0.4, "require_liveness": False,
                               "max_samples": "nhieu", "auto_attendance": 1, "lạ": 5, "camera_index": 1}))
        c = Config.load(self.d)
        self.assertEqual(c.match_threshold, 0.4); self.assertFalse(c.require_liveness)
        self.assertEqual(c.camera_index, 1)
        self.assertEqual(c.max_samples, DEFAULTS["max_samples"])        # sai kiểu
        self.assertEqual(c.auto_attendance, DEFAULTS["auto_attendance"])  # 1 không phải bool

    def test_broken_file(self):
        self.write("{không phải json"); self.assertEqual(Config.load(self.d).camera_index, 0)
        self.write("[1,2]"); self.assertEqual(Config.load(self.d).camera_index, 0)


if __name__ == "__main__":
    unittest.main()
