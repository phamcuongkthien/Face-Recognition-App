"""Test cho các phần bổ sung: thử thách ngẫu nhiên, đi muộn, điểm danh thủ công,
nhật ký, chất lượng ảnh, migration CSDL, thống kê công bằng, an toàn Excel."""

import datetime
import os
import random
import shutil
import sqlite3
import tempfile
import unittest

import numpy as np
import openpyxl

import db
import liveness
from config import Config
from engine import parse_hhmm, valid_student_id
from liveness import ChallengeLiveness
from tests.helpers import BOX, enc
from tests.test_engine import Base


# ---------- landmarks giả để thử các công thức ----------
def lm(yaw_shift=0.0, mouth_open=0.0):
    """Khuôn mặt giả: hai mắt cách nhau 40px, mũi lệch yaw_shift*40px."""

    def eye(cx):
        return [(cx - 6, 0), (cx - 3, -2), (cx + 3, -2), (cx + 6, 0), (cx + 3, 2), (cx - 3, 2)]

    left, right = eye(-20), eye(20)
    top = [(-20, 50), (-14, 46), (-8, 44), (0, 44), (8, 44), (14, 46), (20, 50),
           (12, 48), (6, 47), (0, 47), (-6, 47), (-12, 48)]
    gap = mouth_open * 40
    bottom = [(20, 50), (14, 54), (8, 56), (0, 56), (-8, 56), (-14, 54), (-20, 50),
              (-12, 48), (-6, 47 + gap), (0, 47 + gap), (6, 47 + gap), (12, 48)]
    # bottom[8..10] là 3 điểm môi trong dưới
    return {
        "left_eye": left, "right_eye": right,
        "nose_tip": [(yaw_shift * 40 + dx, 25) for dx in (-4, -2, 0, 2, 4)],
        "top_lip": top, "bottom_lip": bottom,
    }


class PoseFormulaTests(unittest.TestCase):

    def test_yaw_sign_and_scale(self):
        self.assertAlmostEqual(liveness.head_yaw(lm(0.0)), 0.0, places=3)
        self.assertGreater(liveness.head_yaw(lm(0.4)), 0.3)
        self.assertLess(liveness.head_yaw(lm(-0.4)), -0.3)

    def test_mouth_closed_vs_open(self):
        closed = liveness.mouth_aspect_ratio(lm(mouth_open=0.0))
        opened = liveness.mouth_aspect_ratio(lm(mouth_open=0.5))
        self.assertLess(closed, 0.1)
        self.assertGreater(opened, 0.35)

    def test_missing_landmarks_return_none(self):
        self.assertIsNone(liveness.head_yaw({}))
        self.assertIsNone(liveness.mouth_aspect_ratio({"top_lip": [], "bottom_lip": []}))
        pose = liveness.face_pose({})
        self.assertEqual(pose, {"ear": None, "mar": None, "yaw": None})


class ChallengeTests(unittest.TestCase):

    def make(self, **kw):
        kw.setdefault("rng", random.Random(1))
        return ChallengeLiveness(**kw)

    def test_distinct_random_steps(self):
        c = self.make(steps=3)
        c.update(0.0, yaw=0.0)
        self.assertEqual(len(c.sequence), 3)
        self.assertEqual(len(set(c.sequence)), 3)

    def test_completes_when_each_action_is_done(self):
        c = self.make(pool=("turn_left", "open_mouth"), steps=2)
        t = 0.0
        c.update(t, yaw=0.0)
        done = False
        for _ in range(2):
            action = c.current
            for _ in range(3):
                t += 0.2
                kw = {"turn_left": {"yaw": -0.4}, "open_mouth": {"mar": 0.6}}[action]
                done = c.update(t, **kw) or done
        self.assertTrue(done)
        self.assertTrue(c.recently_passed(t, 5))
        self.assertFalse(c.recently_passed(t + 10, 5))

    def test_wrong_action_does_not_pass(self):
        c = self.make(pool=("turn_left", "turn_right"), steps=2)
        t = 0.0
        for _ in range(20):
            t += 0.2
            c.update(t, ear=0.3, mar=0.0, yaw=0.0)     # chỉ đứng yên / chớp mắt
        self.assertIsNone(c.passed_at)

    def test_each_action_needs_its_own_signal(self):
        cases = (
            ("open_mouth", dict(mar=0.0, yaw=0.5), dict(mar=0.6, yaw=0.0)),
            ("turn_left", dict(mar=0.6, yaw=0.5), dict(mar=0.0, yaw=-0.4)),   # sai chiều / đúng chiều
            ("turn_right", dict(mar=0.6, yaw=-0.5), dict(mar=0.0, yaw=0.4)),
        )
        for action, wrong, right in cases:
            c = self.make(pool=(action,), steps=1)
            for i in range(6):
                c.update(i * 0.2, **wrong)
            self.assertIsNone(c.passed_at, action)
            c = self.make(pool=(action,), steps=1)
            for i in range(6):
                c.update(i * 0.2, **right)
            self.assertIsNotNone(c.passed_at, action)

    def test_single_noisy_frame_is_not_enough(self):
        c = self.make(pool=("open_mouth",), steps=1, hold=2)
        c.update(0.0, mar=0.0)
        c.update(0.2, mar=0.9)                           # 1 khung nhiễu
        c.update(0.4, mar=0.0)
        self.assertIsNone(c.passed_at)

    def test_pre_recorded_blink_video_fails_non_blink_challenges(self):
        c = self.make(pool=("turn_left", "turn_right", "open_mouth"), steps=2, timeout=8)
        t = 0.0
        for i in range(120):                            # video: mặt thẳng, chớp mắt đều
            t += 0.2
            ear = 0.1 if i % 15 == 0 else 0.3
            c.update(t, ear=ear, mar=0.02, yaw=0.0)
        self.assertIsNone(c.passed_at)
        self.assertGreaterEqual(c.failures, 1)          # quá hạn và bị đổi chuỗi

    def test_timeout_reissues_new_sequence(self):
        c = self.make(pool=("turn_left", "turn_right", "open_mouth"), steps=1, timeout=2)
        c.update(0.0, yaw=0.0)
        first = list(c.sequence)
        for i in range(1, 30):
            c.update(i * 0.5, yaw=0.0)
        self.assertGreaterEqual(c.failures, 1)
        self.assertEqual(len(c.sequence), 1)
        self.assertIsNotNone(first)

    def test_action_before_being_asked_does_not_count(self):
        c = self.make(pool=("blink",), steps=1)
        for _ in range(8):
            c.blink.update(0.3, 0.0)
        c.blink.update(0.05, 0.1)
        c.blink.update(0.3, 0.2)                        # chớp mắt TRƯỚC khi có yêu cầu
        self.assertIsNotNone(c.blink.last_blink)
        c.update(1.0, ear=0.3)                          # yêu cầu được phát ra ở t=1.0
        self.assertIsNone(c.passed_at)

    def test_reset(self):
        c = self.make(steps=1)
        c.update(0.0, yaw=0.0)
        c.reset()
        self.assertEqual(c.sequence, [])
        self.assertIsNone(c.passed_at)


class EngineChallengeTests(Base):

    def make_ch(self, pool=("turn_left", "turn_right", "open_mouth"), steps=2, **cfg):
        e = self.make(require_liveness=True, liveness_mode="challenge",
                      challenge_steps=steps, **cfg)
        e.challenge.pool = pool
        e.challenge.steps = steps
        e.challenge.rng = random.Random(3)
        return e

    def pose(self, e, seed, **p):
        self.clock.advance(0.15)
        e.process([{"loc": BOX, "enc": enc(seed, 0.015), **p}])

    def do_action(self, e, seed, action):
        kw = {"turn_left": {"yaw": -0.4}, "turn_right": {"yaw": 0.4},
              "open_mouth": {"mar": 0.6}}[action]
        for _ in range(3):
            self.pose(e, seed, ear=0.3, **kw)

    def test_attendance_only_after_random_actions(self):
        e = self.make_ch()
        for _ in range(8):
            self.pose(e, 1, ear=0.3, mar=0.0, yaw=0.0)
        self.assertEqual(e.current_student, "SV01")
        self.assertEqual(self.events(e, "attendance"), [])          # mới nhận ra, chưa làm gì
        self.assertTrue(e.liveness_prompt())
        for _ in range(2):
            self.do_action(e, 1, e.challenge.current)
        att = self.events(e, "attendance")
        self.assertEqual([a[1] for a in att], ["SV01"])
        self.assertIn("SV01", e.marked_today)

    def test_replayed_video_without_the_asked_action_never_marks(self):
        e = self.make_ch()
        for i in range(120):
            self.pose(e, 1, ear=0.1 if i % 12 == 0 else 0.3, mar=0.0, yaw=0.0)
        self.assertEqual(self.events(e, "attendance"), [])
        self.assertNotIn("SV01", e.marked_today)

    def test_repeated_failures_are_audited_once(self):
        e = self.make_ch(challenge_timeout=2.0)
        e.actor = "gv1"
        for _ in range(150):
            self.pose(e, 1, ear=0.3, mar=0.0, yaw=0.0)
        rows = self.db.recent_events(kind="liveness_failed")
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["actor"], "gv1")

    def test_challenge_resets_when_person_changes(self):
        e = self.make_ch()
        for _ in range(8):
            self.pose(e, 1, ear=0.3, mar=0.0, yaw=0.0)
        self.do_action(e, 1, e.challenge.current)                    # xong 1/2 động tác của An
        self.assertEqual(e.challenge.index, 1)
        for _ in range(8):
            self.pose(e, 2, ear=0.3, mar=0.0, yaw=0.0)               # Bình thế chỗ
        self.assertNotIn("SV01", e.marked_today)
        self.assertLessEqual(e.challenge.index, 1)

    def test_default_mode_is_still_blink(self):
        self.assertFalse(self.make().challenge_mode)


class LateAndManualTests(Base):

    def at(self, h, m):
        self.clock.t = datetime.datetime(2026, 10, 6, h, m, 0).timestamp()

    def recognise(self, e, seed=1):
        for _ in range(6):
            self.step(e, seed)

    def test_parse_hhmm(self):
        self.assertEqual(parse_hhmm("07:30"), 450)
        for bad in ("", "7h30", "25:00", "07:61", None):
            self.assertIsNone(parse_hhmm(bad))

    def test_on_time_and_late(self):
        e = self.make(require_liveness=False, class_start="07:30", late_after_minutes=15)
        self.at(7, 40)
        self.recognise(e, 1)
        self.assertEqual(self.db.attendance_on("2026-10-06")[0]["status"], db.STATUS_PRESENT)
        self.at(8, 0)
        self.recognise(e, 2)
        rows = {r["student_id"]: r for r in self.db.attendance_on("2026-10-06")}
        self.assertEqual(rows["SV02"]["status"], db.STATUS_LATE)
        self.assertIn(("SV02", "2026-10-06"), self.db.late_map())

    def test_no_class_start_never_late(self):
        e = self.make(require_liveness=False)
        self.at(23, 0)
        self.recognise(e)
        self.assertEqual(self.db.attendance_on("2026-10-06")[0]["status"], db.STATUS_PRESENT)

    def test_manual_requires_reason_and_is_audited(self):
        e = self.make(require_liveness=False)
        e.actor = "gv1"
        self.assertIn("lý do", e.mark_manual("SV01", "  "))
        self.assertIn("Không tìm thấy", e.mark_manual("XXX", "ok"))
        self.assertIsNone(e.mark_manual("SV01", "đeo khẩu trang"))
        row = self.db.conn.execute(
            "SELECT method, marked_by, note FROM attendance WHERE student_id='SV01'").fetchone()
        self.assertEqual(row, ("manual", "gv1", "đeo khẩu trang"))
        ev = self.db.recent_events(kind="attendance_manual")
        self.assertEqual(len(ev), 1)
        self.assertIn("đeo khẩu trang", ev[0]["detail"])
        self.assertEqual(len(self.events(e, "attendance")), 1)
        self.assertIn("đã điểm danh", e.mark_manual("SV01", "lại"))

    def test_unmark_today(self):
        e = self.make(require_liveness=False)
        e.mark_manual("SV01", "thử")
        self.assertIsNone(e.unmark_today("SV01"))
        self.assertNotIn("SV01", e.marked_today)
        self.assertEqual(self.db.attendance_on("2026-10-06"), [])
        self.assertIn("chưa điểm danh", e.unmark_today("SV01"))
        self.assertEqual(len(self.db.recent_events(kind="attendance_removed")), 1)
        # sau khi hủy có thể điểm danh lại
        self.assertIsNone(e.mark_manual("SV01", "ghi lại"))


class AuditAndRegisterTests(Base):

    def test_unknown_face_logged_with_rate_limit(self):
        e = self.make(require_liveness=False, unknown_log_seconds=60)
        for _ in range(40):                             # 6 giây người lạ
            self.step(e, 777)
        self.assertEqual(len(self.db.recent_events(kind="unknown_face")), 1)
        for _ in range(500):                            # thêm ~75 giây
            self.step(e, 777)
        self.assertEqual(len(self.db.recent_events(kind="unknown_face")), 2)

    def test_known_person_is_not_logged_as_unknown(self):
        e = self.make(require_liveness=False)
        for _ in range(40):
            self.step(e, 1)
        self.assertEqual(self.db.recent_events(kind="unknown_face"), [])

    def test_student_id_and_name_validation(self):
        e = self.make()
        self.step(e, 900)
        for bad in ("A", "SV 01", "SV;DROP", "=cmd", "x" * 21):
            self.assertIn("Mã sinh viên", e.start_register(bad, "Ten", "K1", "X"))
        self.assertIn("Họ tên", e.start_register("SV99", "", "K1", "X"))
        self.assertIn("Họ tên", e.start_register("SV99", "A\x00B", "K1", "X"))
        self.assertTrue(valid_student_id("237480201031"))
        self.assertIsNone(e.start_register("SV99", "Chi", "K1", "X"))

    def _register(self, e, **kw):
        for _ in range(3):
            self.step(e, 900)
        self.assertIsNone(e.start_register("SV99", "Chi", "K1", "X", **kw))
        for _ in range(40):
            self.step(e, 900, dt=1.3)
        self.assertIsNone(e.capture)

    def test_consent_recorded_only_when_given(self):
        e = self.make(require_liveness=False)
        self._register(e, consent=True)
        self.assertIsNotNone(self.db.conn.execute(
            "SELECT consent_at FROM students WHERE student_id='SV99'").fetchone()[0])
        self.assertEqual(len(self.db.recent_events(kind="student_registered")), 1)

    def test_no_consent_flag_by_default(self):
        e = self.make(require_liveness=False)
        self._register(e)
        self.assertIsNone(self.db.conn.execute(
            "SELECT consent_at FROM students WHERE student_id='SV99'").fetchone()[0])

    def test_blurry_dark_and_glare_samples_rejected(self):
        e = self.make(require_liveness=False)
        self.step(e, 900)
        e.start_register("SV99", "Chi", "K1", "X")
        good = {"sharp": 120.0, "bright": 120.0}
        for q, text in (({"sharp": 3.0, "bright": 120.0}, "mờ"),
                        ({"sharp": 120.0, "bright": 20.0}, "tối"),
                        ({"sharp": 120.0, "bright": 250.0}, "chói")):
            self.clock.advance(2)
            e.process([{"loc": BOX, "enc": enc(900, .015), "ear": None, "quality": q}])
            self.assertEqual(len(e.capture["samples"]), 0)
            self.assertIn(text, " ".join(x[2] for x in self.events(e, "status")))
        self.clock.advance(2)
        e.process([{"loc": BOX, "enc": enc(900, .015), "ear": None, "quality": good}])
        self.assertEqual(len(e.capture["samples"]), 1)

    def test_missing_quality_is_accepted(self):
        e = self.make(require_liveness=False)
        self.step(e, 900)
        e.start_register("SV99", "Chi", "K1", "X")
        self.clock.advance(2)
        e.process([{"loc": BOX, "enc": enc(900, .015), "ear": None}])
        self.assertEqual(len(e.capture["samples"]), 1)

    def test_delete_and_update_audited(self):
        e = self.make()
        e.actor = "admin"
        e.update_student("SV01", "An B", "K1", "X")
        e.delete_student("SV02")
        kinds = [r["kind"] for r in self.db.recent_events()]
        self.assertIn("student_updated", kinds)
        self.assertIn("student_deleted", kinds)


class DbImprovementTests(unittest.TestCase):

    def setUp(self):
        self.dir = tempfile.mkdtemp()
        self.path = os.path.join(self.dir, "t.db")

    def tearDown(self):
        shutil.rmtree(self.dir, ignore_errors=True)

    def test_migrates_old_database_without_losing_data(self):
        old = sqlite3.connect(self.path)
        old.executescript("""
            CREATE TABLE students (student_id TEXT PRIMARY KEY, name TEXT NOT NULL,
              class_name TEXT NOT NULL DEFAULT '', faculty TEXT NOT NULL DEFAULT '',
              active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL);
            CREATE TABLE attendance (id INTEGER PRIMARY KEY AUTOINCREMENT,
              student_id TEXT NOT NULL, day TEXT NOT NULL, time TEXT NOT NULL,
              distance REAL, UNIQUE (student_id, day));
            INSERT INTO students VALUES ('SV01','An','K1','X',1,'2026-10-01T08:00:00');
            INSERT INTO attendance(student_id, day, time) VALUES ('SV01','2026-10-02','08:00:00');
        """)
        old.commit(); old.close()
        d = db.Database(self.path)
        row = d.conn.execute("SELECT status, method, marked_by, note FROM attendance").fetchone()
        self.assertEqual(row, ("present", "auto", None, ""))
        self.assertEqual(d.get_student("SV01")["name"], "An")
        d.log_event("x", "y")
        self.assertEqual(len(d.recent_events()), 1)
        d.close()
        d = db.Database(self.path)            # mở lần hai không lỗi (migration idempotent)
        self.assertEqual(len(d.attendance_on("2026-10-02")), 1)
        d.close()

    def test_late_joiner_not_marked_absent_for_earlier_days(self):
        d = db.Database(self.path)
        d.add_student("SV01", "An", "K1", "X", [enc(1)], created_at="2026-09-01T00:00:00")
        d.add_student("SV02", "Bình", "K1", "X", [enc(2)], created_at="2026-10-05T09:00:00")
        D = datetime.datetime
        for day in (1, 2, 3, 6, 7):
            d.mark_attendance("SV01", D(2026, 10, day, 8, 0, 0))
        d.mark_attendance("SV02", D(2026, 10, 6, 8, 0, 0))
        st = {p["student_id"]: p for p in d.statistics()["per_student"]}
        self.assertEqual((st["SV01"]["sessions"], st["SV01"]["rate"]), (5, 100.0))
        # Bình vào ngày 5/10: chỉ tính các buổi 6 và 7/10, có mặt 1/2
        self.assertEqual((st["SV02"]["sessions"], st["SV02"]["present"], st["SV02"]["rate"]),
                         (2, 1, 50.0))
        self.assertEqual(st["SV02"]["absent_days"], ["2026-10-07"])
        per_day = {p["day"]: p for p in d.statistics()["per_day"]}
        self.assertEqual(per_day["2026-10-02"]["total"], 1)     # Bình chưa vào lớp
        self.assertEqual(per_day["2026-10-06"]["total"], 2)
        d.close()

    def test_legacy_attendance_before_created_date_is_kept(self):
        d = db.Database(self.path)
        d.add_student("SV01", "An", "K1", "X", [enc(1)], created_at="2026-10-06T00:00:00")
        d.mark_attendance("SV01", datetime.datetime(2026, 9, 30, 8, 0, 0))
        d.mark_attendance("SV01", datetime.datetime(2026, 10, 7, 8, 0, 0))
        st = d.statistics()["per_student"][0]
        self.assertEqual((st["sessions"], st["present"]), (2, 2))
        d.close()

    def test_excel_does_not_store_formulas_from_names(self):
        d = db.Database(self.path)
        d.add_student("SV01", '=HYPERLINK("http://evil","x")', "K1", "X", [enc(1)],
                      created_at="2026-01-01T00:00:00")
        d.mark_attendance("SV01", datetime.datetime(2026, 10, 1, 8, 0, 0))
        out = os.path.join(self.dir, "o.xlsx")
        d.export_excel(out)
        wb = openpyxl.load_workbook(out)
        for ws in wb.worksheets:
            for row in ws.iter_rows():
                for c in row:
                    self.assertNotEqual(c.data_type, "f", (ws.title, c.coordinate))
        self.assertEqual(wb["Diem Danh"]["B2"].value, '=HYPERLINK("http://evil","x")')
        d.close()

    def test_excel_marks_late_and_not_yet_enrolled(self):
        d = db.Database(self.path)
        d.add_student("SV01", "An", "K1", "X", [enc(1)], created_at="2026-01-01T00:00:00")
        d.add_student("SV02", "Bình", "K1", "X", [enc(2)], created_at="2026-10-02T00:00:00")
        D = datetime.datetime
        d.mark_attendance("SV01", D(2026, 10, 1, 8, 30, 0), status=db.STATUS_LATE)
        d.mark_attendance("SV01", D(2026, 10, 2, 7, 30, 0))
        d.mark_attendance("SV02", D(2026, 10, 2, 7, 31, 0))
        out = os.path.join(self.dir, "o.xlsx")
        d.export_excel(out)
        wb = openpyxl.load_workbook(out)
        rows = {r[0]: r for r in wb["Diem Danh"].iter_rows(min_row=2, values_only=True)}
        self.assertEqual(rows["SV02"][4], "—")
        self.assertEqual(rows["SV01"][4], "08:30:00")
        self.assertEqual(wb["Diem Danh"]["E2"].font.color.rgb[-6:], "B45309")
        tong = {r[0]: r for r in wb["Tong Hop"].iter_rows(min_row=2, values_only=True) if r[0]}
        self.assertEqual(tong["SV01"][9], 1)
        d.close()

    def test_audit_prune_and_filter(self):
        d = db.Database(self.path)
        for i in range(20):
            d.log_event("a" if i % 2 else "b", f"n{i}", "u")
        self.assertEqual(len(d.recent_events(kind="a")), 10)
        d.prune_events(keep=5)
        ev = d.recent_events(100)
        self.assertEqual(len(ev), 5)
        self.assertEqual(ev[0]["detail"], "n19")             # mới nhất đứng đầu
        d.close()

    def test_backup_is_verified(self):
        d = db.Database(self.path)
        d.add_student("SV01", "An", "K1", "X", [enc(1)])
        p = d.backup(os.path.join(self.dir, "bk"), keep=3, today=datetime.date(2026, 10, 1))
        c = sqlite3.connect(p)
        self.assertEqual(c.execute("PRAGMA integrity_check").fetchone()[0], "ok")
        c.close(); d.close()

    def test_reregistration_after_delete_restarts_enrollment(self):
        d = db.Database(self.path)
        d.add_student("SV01", "An", "K1", "X", [enc(1)], created_at="2026-01-01T00:00:00")
        d.deactivate_student("SV01")
        d.add_student("SV01", "An", "K1", "X", [enc(1)], created_at="2026-10-10T00:00:00")
        d.mark_attendance("SV01", datetime.datetime(2026, 10, 12, 8, 0, 0))
        d.mark_attendance("SV01", datetime.datetime(2026, 9, 1, 8, 0, 0))
        st = d.statistics()["per_student"][0]
        self.assertEqual(st["sessions"], 2)          # 1/9 (lịch sử giữ lại) và 12/10
        d.close()


class ConfigImprovementTests(unittest.TestCase):

    def test_string_options_validated(self):
        d = tempfile.mkdtemp()
        try:
            with open(os.path.join(d, "config.json"), "w", encoding="utf-8") as f:
                f.write('{"liveness_mode": "challenge", "class_start": 730, "challenge_steps": 3}')
            c = Config.load(d)
            self.assertEqual(c.liveness_mode, "challenge")
            self.assertEqual(c.class_start, "")          # sai kiểu -> mặc định
            self.assertEqual(c.challenge_steps, 3)
        finally:
            shutil.rmtree(d, ignore_errors=True)

    def test_defaults_keep_old_behaviour(self):
        c = Config()
        self.assertEqual(c.liveness_mode, "blink")
        self.assertEqual(c.class_start, "")


class VisionQualityTests(unittest.TestCase):

    def test_sharp_vs_blurred_vs_dark(self):
        import cv2
        import vision
        rng = np.random.RandomState(0)
        sharp = (rng.rand(120, 120) * 255).astype(np.uint8)
        blur = cv2.GaussianBlur(sharp, (0, 0), 6)
        dark = (sharp // 10).astype(np.uint8)
        loc = (10, 110, 110, 10)
        qs, qb, qd = (vision.face_quality(x, loc) for x in (sharp, blur, dark))
        self.assertGreater(qs["sharp"], 50 * qb["sharp"])
        self.assertLess(qd["bright"], 30)
        self.assertGreater(qs["bright"], 100)
        self.assertIsNone(vision.face_quality(sharp, (0, 3, 3, 0)))


if __name__ == "__main__":
    unittest.main()
