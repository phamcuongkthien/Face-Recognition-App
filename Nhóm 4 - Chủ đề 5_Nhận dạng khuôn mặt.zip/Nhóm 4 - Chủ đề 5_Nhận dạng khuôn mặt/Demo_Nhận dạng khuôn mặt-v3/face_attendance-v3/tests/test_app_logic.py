"""Test lớp giao diện bằng tkinter giả lập (không cần màn hình/camera)."""

import os
import shutil
import sys
import tempfile
import time
import unittest
from unittest.mock import MagicMock

import numpy as np

# ---- giả lập tkinter + theme chỉ trong lúc import app, rồi trả lại như cũ ----
_saved = {k: sys.modules.get(k) for k in
          ("tkinter", "tkinter.ttk", "tkinter.messagebox", "theme", "PIL.ImageTk")}
_tk = MagicMock()
sys.modules["tkinter"] = _tk
sys.modules["tkinter.ttk"] = _tk.ttk
sys.modules["tkinter.messagebox"] = _tk.messagebox
sys.modules["PIL.ImageTk"] = MagicMock()
_theme = MagicMock()
_theme.BaseDialog = type("BaseDialog", (), {})
sys.modules["theme"] = _theme

import app as appmod   # noqa: E402
import db              # noqa: E402
from auth import LoginThrottle  # noqa: E402
from config import Config       # noqa: E402
from engine import Engine       # noqa: E402
from tests.helpers import BOX, enc  # noqa: E402

for _k, _v in _saved.items():
    if _v is None:
        sys.modules.pop(_k, None)
    else:
        sys.modules[_k] = _v

mb = appmod.messagebox


class FakePipeline:
    def __init__(self):
        self.frame = np.zeros((480, 640, 3), dtype=np.uint8)
        self.fid = 1
        self.rid = 0
        self.result = None
        self.camera_ok = True
        self.stopped = False

    def get_frame(self): return self.frame, self.fid
    def get_result(self): return self.rid, self.result
    def stop(self): self.stopped = True


class AppBase(unittest.TestCase):

    def setUp(self):
        self.dir = tempfile.mkdtemp()
        self.db = db.Database(os.path.join(self.dir, "t.db"))
        self.db.add_student("SV01", "An", "K1", "X", [enc(1, .01), enc(1, .02)])
        self.cfg = Config(require_liveness=False, auto_attendance=False)
        for m in (mb.showinfo, mb.showwarning, mb.showerror, mb.askyesno):
            m.reset_mock()
        mb.askyesno.return_value = True
        self.old_export = appmod.EXPORT_DIR
        appmod.EXPORT_DIR = os.path.join(self.dir, "exports")
        self._saved_attrs = {
            n: getattr(appmod, n)
            for n in ("RegisterDialog", "PickerDialog", "EditStudentDialog",
                      "ChangePasswordDialog", "StatsWindow")
        }

    def tearDown(self):
        for n, v in self._saved_attrs.items():
            setattr(appmod, n, v)
        appmod.EXPORT_DIR = self.old_export
        self.db.close(); shutil.rmtree(self.dir, ignore_errors=True)

    def make_app(self, role="admin"):
        a = object.__new__(appmod.FaceRecognitionApp)
        a.root = MagicMock(); a.db = self.db; a.cfg = self.cfg; a.role = role
        a.username = "u"; a.engine = Engine(self.db, self.cfg)
        a.pipeline = FakePipeline()
        a.running = True; a.frame_job = None; a.status_job = None
        a.log_count = 0; a._info_key = None; a._last_fid = -1; a._last_rid = -1
        a._small_w = None; a._dirty = True; a._cam_msg = False; a._started = time.time()
        a.font_label = None; a.font_badge = None
        for n in ("cam_label", "status", "avatar", "lbl_name", "lbl_class", "lbl_faculty",
                  "lbl_state", "tree", "log_empty", "log_total"):
            setattr(a, n, MagicMock())
        a.cam_label.winfo_width.return_value = 640
        a.cam_label.winfo_height.return_value = 480
        a.var_auto = MagicMock(); a.var_live = MagicMock()
        a.set_status = MagicMock()
        return a

    def detection(self, a, seed=1, box=BOX):
        a.pipeline.rid += 1
        a.pipeline.fid += 1
        a.pipeline.result = {"dets": [{"loc": box, "enc": enc(seed, .015), "ear": None}],
                             "small_w": 320, "small_h": 240}


class TickTests(AppBase):

    def test_tick_processes_result_draws_scaled_boxes_and_skips_when_idle(self):
        a = self.make_app()
        self.detection(a)
        appmod.theme.draw_face_box.reset_mock()
        a._tick()
        self.assertEqual(len(a.engine.faces), 1)
        args = appmod.theme.draw_face_box.call_args[0]
        # khung nhỏ 320 rộng -> ảnh hiển thị 640 rộng => nhân 2
        self.assertEqual(args[1:5], (10 * 2, 10 * 2, 110 * 2, 110 * 2))
        self.assertEqual(args[5], "Đang xác nhận…")
        # không có khung/kết quả mới -> không vẽ lại
        appmod.theme.draw_face_box.reset_mock()
        a._tick()
        appmod.theme.draw_face_box.assert_not_called()
        # có khung mới -> vẽ lại
        a.pipeline.fid += 1; a._tick()
        appmod.theme.draw_face_box.assert_called()

    def test_camera_lost_shows_message_after_grace_period(self):
        a = self.make_app(); a.pipeline.camera_ok = False
        a._tick(); a.cam_label.config.assert_not_called()      # chưa tới 3 giây
        a._started -= 5
        a._tick(); self.assertTrue(a._cam_msg)
        self.assertIn("Không có tín hiệu", a.cam_label.config.call_args.kwargs["text"])
        a.cam_label.config.reset_mock(); a._tick()
        a.cam_label.config.assert_not_called()                  # không lặp lại
        a.pipeline.camera_ok = True; a._dirty = True; a._tick()
        self.assertFalse(a._cam_msg)                            # camera về -> xóa thông báo

    def test_tick_survives_exception_and_reschedules(self):
        a = self.make_app(); a.pipeline.get_frame = MagicMock(side_effect=RuntimeError("x"))
        a.tick(); a.root.after.assert_called()

    def test_tick_stops_after_shutdown(self):
        a = self.make_app(); a.shutdown()
        a.root.after.reset_mock(); a.tick()
        a.root.after.assert_not_called(); self.assertTrue(a.pipeline.stopped)

    def test_refresh_info_states(self):
        self.cfg.require_liveness = True
        a = self.make_app(); a.engine.require_liveness = True
        a.engine.current_student = "SV01"; a.engine.reload; 
        a.engine.current_student = "SV01"
        a.refresh_info(); self.assertIn("chớp mắt", a.lbl_state.config.call_args.kwargs["text"])
        a.engine.require_liveness = False; a._info_key = None; a.refresh_info()
        self.assertIn("Sẵn sàng", a.lbl_state.config.call_args.kwargs["text"])
        a.engine.marked_today.add("SV01"); a._info_key = None; a.refresh_info()
        self.assertIn("Đã điểm danh", a.lbl_state.config.call_args.kwargs["text"])
        a.engine.current_student = None; a._info_key = None; a.refresh_info()
        a.lbl_name.config.assert_called_with(text="Chưa nhận diện")


class EventAndActionTests(AppBase):

    def test_drain_events(self):
        a = self.make_app()
        a.engine.events.extend([("status", "success", "ok\nsub"),
                                ("attendance", "SV01", "An", "K1", "08:00:00"),
                                ("capture_finished", True, "Thành công", "xong")])
        a.drain_events()
        a.set_status.assert_called_with("ok\nsub", "success")
        a.tree.insert.assert_called(); self.assertEqual(a.log_count, 1)
        a.root.after.assert_called()                             # hộp thoại hoãn khỏi vòng lặp
        a.show_result(True, "t", "m"); mb.showinfo.assert_called_with("t", "m")
        a.show_result(False, "t", "m"); mb.showwarning.assert_called_with("t", "m")

    def test_load_today_log(self):
        import datetime
        now = datetime.datetime.now()
        self.db.mark_attendance("SV01", now)
        a = self.make_app(); a.load_today_log()
        self.assertEqual(a.log_count, 1)

    def test_manual_attendance_button(self):
        a = self.make_app()
        for _ in range(5): self.detection(a); a._tick()
        a.mark_attendance()
        self.assertEqual(len(self.db.attendance_days()), 1)
        a.set_status.assert_called_with("Điểm danh thành công:\nAn", "success")

    def test_register_flow(self):
        a = self.make_app("user")
        self.detection(a, seed=77); a._tick()
        appmod.RegisterDialog = lambda root: type("D", (), {"result": ("SV9", "Chi", "K3", "Y")})()
        a.register_face()
        self.assertIsNotNone(a.engine.capture)
        # bấm lần nữa -> hỏi hủy
        a.register_face(); self.assertIsNone(a.engine.capture)

    def test_register_without_face_warns_before_dialog(self):
        a = self.make_app()
        called = []
        appmod.RegisterDialog = lambda root: called.append(1)
        a.register_face()
        self.assertEqual(called, []); mb.showwarning.assert_called()

    def test_add_samples_flow(self):
        a = self.make_app()
        for _ in range(2): self.detection(a, seed=1); a._tick()
        appmod.PickerDialog = lambda *args, **kw: type("D", (), {"result": 0})()
        a.add_samples()
        self.assertEqual(a.engine.capture["mode"], "append")

    def test_admin_only_actions(self):
        a = self.make_app("user")
        a.edit_student(); a.delete_face()
        self.assertEqual(mb.showwarning.call_count, 2)
        self.assertEqual(self.db.get_student("SV01")["name"], "An")
        self.assertEqual(len(self.db.list_students()), 1)

    def test_edit_and_delete_as_admin(self):
        a = self.make_app("admin")
        appmod.PickerDialog = lambda *args, **kw: type("D", (), {"result": 0})()
        appmod.EditStudentDialog = lambda root, s: type("D", (), {"result": ("An Mới", "K2", "Y")})()
        a.edit_student()
        self.assertEqual(self.db.get_student("SV01")["name"], "An Mới")
        a.delete_face()
        self.assertEqual(self.db.list_students(), [])
        self.assertNotIn("SV01", a.engine.students)

    def test_pick_with_no_students(self):
        a = self.make_app(); self.db.deactivate_student("SV01")
        self.assertIsNone(a._pick_student("t", "s", "ok", "primary"))
        mb.showinfo.assert_called()

    def test_export_excel_creates_timestamped_file(self):
        a = self.make_app(); a.export_excel()
        files = os.listdir(appmod.EXPORT_DIR)
        self.assertEqual(len(files), 1); self.assertTrue(files[0].startswith("diemdanh_"))
        mb.showinfo.assert_called()

    def test_change_password(self):
        self.db.create_user("u", "oldpass1")
        a = self.make_app()
        appmod.ChangePasswordDialog = lambda root: type("D", (), {"result": ("oldpass1", "newpass2")})()
        a.change_password()
        self.assertEqual(self.db.check_login("u", "newpass2")[0], True)
        # sai mật khẩu hiện tại -> không đổi
        appmod.ChangePasswordDialog = lambda root: type("D", (), {"result": ("SAI", "hackpass")})()
        a.change_password()
        self.assertEqual(self.db.check_login("u", "hackpass")[0], False)
        mb.showerror.assert_called()

    def test_toggles(self):
        a = self.make_app()
        a.var_auto.get.return_value = True; a.on_toggle_auto(); self.assertTrue(a.engine.auto_attendance)
        a.var_live.get.return_value = False; a.on_toggle_live(); self.assertFalse(a.engine.require_liveness)


class FakeVar:
    def __init__(self, v=""): self.v = v
    def get(self): return self.v
    def set(self, v): self.v = v


class StatsWindowTests(AppBase):

    def setUp(self):
        super().setUp()
        import datetime
        self.db.add_student("SV02", "Bình", "K1", "X", [enc(2)])
        D = datetime.datetime
        for sid, days in {"SV01": (28, 29, 30), "SV02": (28,)}.items():
            for d in days:
                self.db.mark_attendance(sid, D(2026, 9, d, 8, 0, 0))

    def make_win(self):
        w = object.__new__(appmod.StatsWindow)
        w.parent = MagicMock(); w.db = self.db; w.export_dir = os.path.join(self.dir, "ex")
        w.stats = None; w.win = MagicMock()
        w.var_from = FakeVar(); w.var_to = FakeVar()
        for n in ("lbl_students", "lbl_days", "lbl_rate", "lbl_low", "lbl_range",
                  "tree_students", "tree_days", "chart"):
            setattr(w, n, MagicMock())
        w.chart.winfo_width.return_value = 800
        w.chart.winfo_height.return_value = 220
        return w

    def test_refresh_fills_cards_and_sorts_lowest_first(self):
        w = self.make_win(); w.refresh()
        w.lbl_students.config.assert_called_with(text="2")
        w.lbl_days.config.assert_called_with(text="3")
        w.lbl_rate.config.assert_called_with(text="66.7%")      # (100 + 33.3) / 2
        self.assertEqual(w.lbl_low.config.call_args.kwargs["text"], "1")   # Bình 33,3% < 70
        rows = [c.kwargs for c in w.tree_students.insert.call_args_list]
        self.assertEqual([r["values"][1] for r in rows], ["Bình", "An"])   # thấp nhất lên đầu
        self.assertEqual(rows[0]["tags"], ("low",)); self.assertEqual(rows[1]["tags"], ())
        self.assertEqual(rows[0]["values"][5:], ("33.3%", "Cần nhắc nhở"))
        days = [c.kwargs["values"][0] for c in w.tree_days.insert.call_args_list]
        self.assertEqual(days, ["30/09/2026", "29/09/2026", "28/09/2026"])  # mới nhất lên đầu

    def test_invalid_dates_warn_and_do_not_refresh(self):
        w = self.make_win()
        w.var_from.set("32/13/2026"); w.refresh()
        mb.showwarning.assert_called(); w.tree_students.insert.assert_not_called()
        mb.showwarning.reset_mock()
        w.var_from.set("30/09/2026"); w.var_to.set("01/09/2026"); w.refresh()
        mb.showwarning.assert_called(); w.tree_students.insert.assert_not_called()

    def test_range_filter(self):
        w = self.make_win()
        w.var_from.set("29/09/2026"); w.var_to.set("30/09/2026"); w.refresh()
        w.lbl_days.config.assert_called_with(text="2")
        w.lbl_range.config.assert_called_with(text="Phạm vi: 29/09/2026 → 30/09/2026")
        w.clear_range()
        self.assertEqual((w.var_from.get(), w.var_to.get()), ("", ""))
        w.lbl_days.config.assert_called_with(text="3")

    def test_quick_ranges_set_dates(self):
        import datetime
        w = self.make_win(); w.set_last_days(7)
        today = datetime.date.today()
        self.assertEqual(w.var_to.get(), today.strftime("%d/%m/%Y"))
        self.assertEqual(w.var_from.get(), (today - datetime.timedelta(days=6)).strftime("%d/%m/%Y"))
        w.lbl_days.config.assert_called_with(text="0")        # dữ liệu mẫu ở quá khứ

    def test_chart_bars_and_empty_state(self):
        w = self.make_win(); w.refresh()
        self.assertEqual(w.chart.create_rectangle.call_count, 3)
        fills = [c.kwargs["fill"] for c in w.chart.create_rectangle.call_args_list]
        # 28/09: 100% (xanh) · 29/09 và 30/09: 50% < 70% (đỏ)
        self.assertEqual(fills, [appmod.theme.PRIMARY, appmod.theme.DANGER, appmod.theme.DANGER])
        w.chart.reset_mock(); w.var_from.set("01/01/2030"); w.refresh()
        w.chart.create_rectangle.assert_not_called()
        self.assertIn("Chưa có dữ liệu", w.chart.create_text.call_args.kwargs["text"])

    def test_chart_limits_to_30_days(self):
        import datetime
        for d in range(1, 41):
            self.db.mark_attendance("SV01", datetime.datetime(2026, 1, 1) + datetime.timedelta(days=d))
        w = self.make_win(); w.refresh()
        self.assertEqual(w.chart.create_rectangle.call_count, 30)

    def test_export_range_creates_file(self):
        import openpyxl
        w = self.make_win(); w.var_from.set("29/09/2026"); w.export()
        files = os.listdir(w.export_dir)
        self.assertEqual(len(files), 1); self.assertTrue(files[0].startswith("baocao_"))
        wb = openpyxl.load_workbook(os.path.join(w.export_dir, files[0]))
        self.assertEqual(wb.sheetnames, ["Diem Danh", "Tong Hop", "Theo Ngay"])
        mb.showinfo.assert_called()

    def test_export_blocked_on_bad_date(self):
        w = self.make_win(); w.var_to.set("abc"); w.export()
        self.assertFalse(os.path.exists(w.export_dir))

    def test_open_stats_reuses_existing_window(self):
        a = self.make_app()
        created = []
        class Fake:
            def __init__(s, *args): created.append(s); s.focused = 0
            def exists(s): return True
            def focus(s): s.focused += 1
            def close(s): s.closed = True
        appmod.StatsWindow = Fake
        a.open_stats(); a.open_stats()
        self.assertEqual(len(created), 1); self.assertEqual(created[0].focused, 1)
        a.shutdown(); self.assertTrue(created[0].closed)


class LoginTests(AppBase):

    def make_login(self):
        p = object.__new__(appmod.LoginPage)
        p.root = MagicMock(); p.db = self.db; p.on_login = MagicMock()
        p.throttle = LoginThrottle(3, 30)
        p.username_var = MagicMock(); p.password_var = MagicMock()
        return p

    def test_throttle_locks_even_correct_password(self):
        self.db.create_user("gv", "right123")
        p = self.make_login()
        p.username_var.get.return_value = "gv"
        p.password_var.get.return_value = "wrong"
        for _ in range(3): p.login()
        self.assertEqual(mb.showerror.call_count, 3)
        p.password_var.get.return_value = "right123"
        p.login()
        p.on_login.assert_not_called(); mb.showwarning.assert_called()   # bị khóa

    def test_success_passes_role(self):
        self.db.create_user("gv", "right123")
        p = self.make_login()
        p.username_var.get.return_value = "gv"; p.password_var.get.return_value = "right123"
        p.login(); p.on_login.assert_called_with("gv", "admin")


if __name__ == "__main__":
    unittest.main()
