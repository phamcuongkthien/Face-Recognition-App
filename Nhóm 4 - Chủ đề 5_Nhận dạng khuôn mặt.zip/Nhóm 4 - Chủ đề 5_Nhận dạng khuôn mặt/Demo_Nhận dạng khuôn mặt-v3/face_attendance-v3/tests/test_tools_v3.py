import os, sys, tempfile, unittest, json, threading, urllib.request, urllib.error
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
from tools import eval_spoof, serve_api
from db import Database


class SpoofSweep(unittest.TestCase):
    def test_sweep_and_recommend(self):
        real = [0.95, 0.9, 0.85, 0.8, 0.4]
        attack = [0.1, 0.2, 0.5, 0.65, 0.3]
        rows = eval_spoof.sweep(real, attack, [0.3, 0.5, 0.7, 0.9])
        self.assertEqual(rows[0][1], 0.0)             # ngưỡng 0.3 không chặn ai
        self.assertAlmostEqual(rows[2][1], 0.2)       # 0.7 chặn 1/5 người thật
        self.assertEqual(rows[2][2], 0.0)
        self.assertEqual(eval_spoof.recommend(rows, 0.25), 0.9 if rows[3][1] <= 0.25 else 0.7)

    def test_recommend_none(self):
        rows = eval_spoof.sweep([0.1, 0.2], [0.9], [0.5])
        self.assertIsNone(eval_spoof.recommend(rows, 0.05))


class ApiTests(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()
        self.path = os.path.join(self.d, "t.db")
        db = Database(self.path)
        db.add_student("SV01", "An", "K1", "X", [np.zeros(128)])
        db.close()

    def test_route(self):
        db = Database(self.path)
        c, d = serve_api.route(db, "/api/students", {})
        self.assertEqual(c, 200)
        self.assertEqual(list(d[0]), ["student_id", "name", "class_name", "faculty"])
        self.assertEqual(serve_api.route(db, "/api/attendance", {"day": ["bad"]})[0], 400)
        self.assertEqual(serve_api.route(db, "/api/attendance", {"day": ["2026-11-09"]}), (200, []))
        self.assertEqual(serve_api.route(db, "/nope", {})[0], 404)
        db.close()

    def test_auth(self):
        from http.server import ThreadingHTTPServer
        srv = ThreadingHTTPServer(("127.0.0.1", 0), serve_api.make_handler(self.path, "x" * 20))
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        url = f"http://127.0.0.1:{srv.server_address[1]}/api/students"
        try:
            with self.assertRaises(urllib.error.HTTPError) as cm:
                urllib.request.urlopen(url)
            self.assertEqual(cm.exception.code, 401)
            req = urllib.request.Request(url, headers={"Authorization": "Bearer " + "x" * 20})
            self.assertEqual(json.load(urllib.request.urlopen(req))[0]["student_id"], "SV01")
        finally:
            srv.shutdown(); srv.server_close()


if __name__ == "__main__":
    unittest.main()
