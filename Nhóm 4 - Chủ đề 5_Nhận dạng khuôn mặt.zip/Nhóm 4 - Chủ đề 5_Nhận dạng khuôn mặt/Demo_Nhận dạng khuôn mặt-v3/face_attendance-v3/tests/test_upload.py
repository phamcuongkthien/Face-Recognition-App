import os, shutil, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
import db
from config import Config
from engine import Engine


def vec(seed, noise=0.0):
    v = np.random.RandomState(seed).normal(0, 1, 128)
    v = v / np.linalg.norm(v) * 0.9
    if noise:
        v = v + np.random.RandomState(seed + 500).normal(0, noise, 128)
    return v


def fake_encoder(table):
    def f(path):
        r = table[os.path.basename(path)]
        if isinstance(r, str):
            return {"enc": None, "problem": r, "quality": None}
        return {"enc": r, "problem": None, "quality": {"sharp": 100.0, "bright": 120.0}}
    return f


class UploadTests(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()
        self.db = db.Database(os.path.join(self.d, "u.db"))
        self.e = Engine(self.db, Config(require_liveness=False))

    def tearDown(self):
        self.db.close(); shutil.rmtree(self.d, ignore_errors=True)

    def test_enroll_ok_and_recognised(self):
        t = {f"a{i}.jpg": vec(1, 0.002 * i) for i in range(4)}
        err, notes = self.e.enroll_from_images("SV01", "An", "K1", "X", list(t), fake_encoder(t), True)
        self.assertIsNone(err); self.assertEqual(notes, [])
        self.assertEqual(self.db.sample_count("SV01", "dlib"), 4)
        from recognizer import match_face
        sid, _ = match_face(self.e.face_matrix, self.e.face_owner_ids, vec(1, 0.004), 0.5, 0.04)
        self.assertEqual(sid, "SV01")

    def test_bad_images_reported_and_outlier_dropped(self):
        t = {"ok1.jpg": vec(1, 0.002), "ok2.jpg": vec(1, 0.004), "ok3.jpg": vec(1, 0.006),
             "other.jpg": vec(9), "noface.jpg": "Không thấy khuôn mặt"}
        err, notes = self.e.enroll_from_images("SV01", "An", "K1", "X", list(t), fake_encoder(t), True)
        self.assertIsNone(err)
        self.assertEqual(self.db.sample_count("SV01", "dlib"), 3)
        self.assertEqual(len(notes), 2)
        self.assertTrue(any("other.jpg" in n for n in notes))

    def test_too_few_usable(self):
        t = {"a.jpg": vec(1), "b.jpg": "Có 2 khuôn mặt"}
        err, notes = self.e.enroll_from_images("SV01", "An", "K1", "X", list(t), fake_encoder(t), True)
        self.assertIn("cần ít nhất", err)
        self.assertIsNone(self.db.get_student("SV01"))

    def test_two_photos_of_different_people_rejected(self):
        t = {"a.jpg": vec(1), "b.jpg": vec(2)}
        err, _ = self.e.enroll_from_images("SV01", "An", "K1", "X", list(t), fake_encoder(t), True)
        self.assertIsNotNone(err)
        self.assertIsNone(self.db.get_student("SV01"))

    def test_duplicate_person_refused(self):
        t = {f"a{i}.jpg": vec(1, 0.002 * i) for i in range(3)}
        self.e.enroll_from_images("SV01", "An", "K1", "X", list(t), fake_encoder(t), True)
        t2 = {f"b{i}.jpg": vec(1, 0.003 * i) for i in range(3)}
        self.e.enroll_from_images("SV02", "Bình", "K1", "X", list(t2), fake_encoder(t2), True)
        self.assertIsNone(self.db.get_student("SV02"))
        fin = [x for x in self.e.pop_events() if x[0] == "capture_finished"]
        self.assertEqual(fin[-1][1], False)

    def test_invalid_id_and_existing_id(self):
        t = {"a.jpg": vec(1), "b.jpg": vec(1, 0.002)}
        self.assertIsNotNone(self.e.enroll_from_images("!", "An", "K1", "X", list(t), fake_encoder(t))[0])
        self.e.enroll_from_images("SV01", "An", "K1", "X", list(t), fake_encoder(t), True)
        self.assertIn("đã thuộc về", self.e.enroll_from_images("SV01", "Z", "K1", "X", list(t), fake_encoder(t))[0])

    def test_add_samples_from_images(self):
        t = {f"a{i}.jpg": vec(1, 0.002 * i) for i in range(3)}
        self.e.enroll_from_images("SV01", "An", "K1", "X", list(t), fake_encoder(t), True)
        t2 = {"n1.jpg": vec(1, 0.005), "n2.jpg": vec(1, 0.007), "x.jpg": vec(7)}
        err, notes = self.e.add_samples_from_images("SV01", list(t2), fake_encoder(t2))
        self.assertIsNone(err)
        self.assertEqual(self.db.sample_count("SV01", "dlib"), 5)

    def test_add_samples_wrong_person_refused(self):
        t = {f"a{i}.jpg": vec(1, 0.002 * i) for i in range(3)}
        self.e.enroll_from_images("SV01", "An", "K1", "X", list(t), fake_encoder(t), True)
        t2 = {"p1.jpg": vec(7), "p2.jpg": vec(7, 0.002)}
        self.e.add_samples_from_images("SV01", list(t2), fake_encoder(t2))
        self.assertEqual(self.db.sample_count("SV01", "dlib"), 3)

    def test_blurry_rejected_by_quality(self):
        def enc_fn(path):
            return {"enc": vec(1), "problem": None, "quality": {"sharp": 1.0, "bright": 120.0}}
        err, notes = self.e.enroll_from_images("SV01", "An", "K1", "X", ["a.jpg", "b.jpg"], enc_fn, True)
        self.assertIsNotNone(err); self.assertTrue(all("mờ" in n for n in notes))

    def test_max_samples_cap(self):
        t = {f"a{i}.jpg": vec(1, 0.001 * i) for i in range(20)}
        self.e.enroll_from_images("SV01", "An", "K1", "X", list(t), fake_encoder(t), True)
        self.assertEqual(self.db.sample_count("SV01", "dlib"), self.e.cfg.max_samples)


if __name__ == "__main__":
    unittest.main()
