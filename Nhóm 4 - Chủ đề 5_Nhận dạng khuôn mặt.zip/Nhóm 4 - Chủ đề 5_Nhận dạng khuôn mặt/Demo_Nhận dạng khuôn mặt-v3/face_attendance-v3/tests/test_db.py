import datetime
import os
import pickle
import shutil
import tempfile
import unittest

import openpyxl

import db
from tests.helpers import enc


class DbTests(unittest.TestCase):

    def setUp(self):
        self.dir = tempfile.mkdtemp()
        self.db = db.Database(os.path.join(self.dir, "t.db"))

    def tearDown(self):
        self.db.close()
        shutil.rmtree(self.dir, ignore_errors=True)

    def test_users_and_roles(self):
        self.assertEqual(self.db.create_user("boss", "123456"), "admin")
        self.assertEqual(self.db.create_user("gv1", "123456"), "user")
        self.assertEqual(self.db.check_login("boss", "123456"), (True, "admin"))
        self.assertEqual(self.db.check_login("gv1", "x"), (False, "wrong_password"))
        self.assertEqual(self.db.check_login("zz", "x"), (False, "not_found"))
        with self.assertRaises(ValueError):
            self.db.create_user("boss", "abcdef")
        row = self.db.conn.execute("select password_hash from users where username='boss'").fetchone()
        self.assertNotIn("123456", row[0])

    def test_set_password(self):
        self.db.create_user("gv", "oldpass1")
        self.assertTrue(self.db.set_password("gv", "newpass2"))
        self.assertEqual(self.db.check_login("gv", "oldpass1"), (False, "wrong_password"))
        self.assertEqual(self.db.check_login("gv", "newpass2")[0], True)
        self.assertFalse(self.db.set_password("nobody", "x"))

    def test_add_student_samples_and_duplicate(self):
        self.db.add_student("SV01", "An", "K1", "X", [enc(1, .01), enc(1, .02)])
        self.db.add_student("SV02", "An", "K1", "X", [enc(2)])     # trùng tên vẫn được
        ids, m = self.db.load_face_index()
        self.assertEqual(ids.count("SV01"), 2)
        self.assertEqual(m.shape, (3, 128))
        with self.assertRaises(ValueError):
            self.db.add_student("SV01", "Trùng mã", "K1", "X", [enc(3)])
        with self.assertRaises(ValueError):
            self.db.add_student("SV03", "Không mẫu", "K1", "X", [])
        self.assertEqual([s["samples"] for s in self.db.list_students()], [2, 1])

    def test_update_student(self):
        self.db.add_student("SV01", "An", "K1", "X", [enc(1)])
        self.assertTrue(self.db.update_student("SV01", "An Mới", "K2", "Y"))
        s = self.db.get_student("SV01")
        self.assertEqual((s["name"], s["class_name"], s["faculty"]), ("An Mới", "K2", "Y"))
        self.assertFalse(self.db.update_student("NOPE", "a", "b", "c"))
        self.assertEqual(self.db.sample_count("SV01"), 1)   # mẫu mặt giữ nguyên

    def test_add_samples_trims_oldest(self):
        self.db.add_student("SV01", "An", "K1", "X", [enc(i) for i in range(4)])
        self.db.add_samples("SV01", [enc(10), enc(11), enc(12)], max_samples=5)
        self.assertEqual(self.db.sample_count("SV01"), 5)
        ids, m = self.db.load_face_index()
        import numpy as np
        self.assertTrue(np.allclose(m[-1], enc(12)))        # mẫu mới nhất còn
        self.assertFalse(any(np.allclose(r, enc(0)) for r in m))  # mẫu cũ nhất bị bỏ
        with self.assertRaises(ValueError):
            self.db.add_samples("NOPE", [enc(1)])

    def test_soft_delete_keeps_history(self):
        self.db.add_student("SV01", "An", "K1", "X", [enc(1)])
        self.db.mark_attendance("SV01", datetime.datetime(2026, 9, 30, 8, 0, 0))
        self.db.deactivate_student("SV01")
        self.assertEqual(self.db.list_students(), [])
        self.assertEqual(self.db.load_face_index()[0], [])
        self.assertEqual(len(self.db.attendance_days()), 1)
        self.db.add_student("SV01", "An Mới", "K2", "Y", [enc(5)])   # đăng ký lại mã cũ
        self.assertEqual(self.db.get_student("SV01")["name"], "An Mới")

    def test_attendance_once_per_day_and_listing(self):
        self.db.add_student("SV01", "An", "K1", "X", [enc(1)])
        d1 = datetime.datetime(2026, 9, 30, 8, 0, 0)
        self.assertTrue(self.db.mark_attendance("SV01", d1))
        self.assertFalse(self.db.mark_attendance("SV01", d1.replace(hour=15)))
        self.assertTrue(self.db.mark_attendance("SV01", d1.replace(year=2027)))
        rows = self.db.attendance_on("2026-09-30")
        self.assertEqual([(r["student_id"], r["time"], r["name"]) for r in rows],
                         [("SV01", "08:00:00", "An")])

    def test_export_excel_absent_in_right_column(self):
        self.db.add_student("SV01", "An", "K1", "X", [enc(1)], created_at="2026-01-01T00:00:00")
        self.db.add_student("SV02", "Bình", "K1", "X", [enc(2)], created_at="2026-01-01T00:00:00")
        self.db.mark_attendance("SV01", datetime.datetime(2026, 9, 29, 8, 0, 0))
        self.db.mark_attendance("SV01", datetime.datetime(2026, 9, 30, 8, 5, 0))
        self.db.mark_attendance("SV02", datetime.datetime(2026, 9, 30, 8, 7, 0))
        path = os.path.join(self.dir, "out.xlsx")
        self.assertEqual(self.db.export_excel(path), (2, 2))
        rows = list(openpyxl.load_workbook(path).active.iter_rows(values_only=True))
        self.assertEqual(rows[0][4:6], ("29/09/2026", "30/09/2026"))
        by = {r[0]: r for r in rows[1:]}
        self.assertEqual(by["SV01"][4:], ("08:00:00", "08:05:00", 2, 100.0))
        self.assertEqual(by["SV02"][4:], ("Vắng", "08:07:00", 1, 50.0))

    def test_backup_once_per_day_and_rotation(self):
        bdir = os.path.join(self.dir, "bk")
        for day in range(1, 11):
            self.db.backup(bdir, keep=3, today=datetime.date(2026, 10, day))
        files = sorted(os.listdir(bdir))
        self.assertEqual(files, ["diemdanh_20261008.db", "diemdanh_20261009.db", "diemdanh_20261010.db"])
        # bản sao đọc được và có dữ liệu
        self.db.add_student("SV01", "An", "K1", "X", [enc(1)])
        p = self.db.backup(bdir, keep=3, today=datetime.date(2026, 10, 11))
        copy = db.Database(p)
        self.assertEqual(len(copy.list_students()), 1)
        copy.close()

    def test_migrate_legacy(self):
        legacy = os.path.join(self.dir, "legacy")
        os.makedirs(legacy)
        with open(os.path.join(legacy, "accounts.pkl"), "wb") as f:
            pickle.dump({"Admin01": "Admin01", "gv": "matkhau"}, f)
        with open(os.path.join(legacy, "dataset.pkl"), "wb") as f:
            pickle.dump({"names": ["An", "Bình"], "classes": ["K1", "K2"],
                         "faculties": ["X", "Y"], "encodings": [enc(1), enc(2)]}, f)
        wb = openpyxl.Workbook(); ws = wb.active
        ws.append(["Họ và Tên", "Lớp", "Khoa", "Buổi 1", "Buổi 2"])
        ws.append(["An", "K1", "X", "08:00:00 29/09", "08:01:00 30/09"])
        ws.append(["Cũ", "K9", "Z", "09:00:00 29/09", None])
        wb.save(os.path.join(legacy, "diemdanh.xlsx"))
        st = self.db.migrate_legacy(legacy)
        self.assertEqual(st, {"users": 2, "students": 2, "attendance": 3})
        self.assertEqual(self.db.check_login("Admin01", "Admin01"), (True, "admin"))
        self.assertEqual(self.db.check_login("gv", "matkhau"), (True, "user"))
        self.assertEqual(len(self.db.list_students()), 2)
        self.assertEqual(self.db.migrate_legacy(legacy), {"users": 0, "students": 0, "attendance": 0})


class StatisticsTests(unittest.TestCase):

    def setUp(self):
        self.dir = tempfile.mkdtemp()
        self.db = db.Database(os.path.join(self.dir, "t.db"))
        for i, name in enumerate(["An", "Bình", "Chi"], start=1):
            self.db.add_student(f"SV0{i}", name, "K1", "X", [enc(i)], created_at="2026-01-01T00:00:00")
        D = datetime.datetime
        # 4 ngày: 28, 29, 30/09 và 01/10
        for sid, days in {"SV01": (28, 29, 30, 1), "SV02": (28, 30), "SV03": ()}.items():
            for d in days:
                month = 10 if d == 1 else 9
                self.db.mark_attendance(sid, D(2026, month, d, 8, 0, 0))

    def tearDown(self):
        self.db.close(); shutil.rmtree(self.dir, ignore_errors=True)

    def test_overall_statistics(self):
        st = self.db.statistics()
        self.assertEqual(st["days"], ["2026-09-28", "2026-09-29", "2026-09-30", "2026-10-01"])
        by = {p["student_id"]: p for p in st["per_student"]}
        self.assertEqual((by["SV01"]["present"], by["SV01"]["absent"], by["SV01"]["rate"]), (4, 0, 100.0))
        self.assertEqual((by["SV02"]["present"], by["SV02"]["rate"]), (2, 50.0))
        self.assertEqual(by["SV02"]["absent_days"], ["2026-09-29", "2026-10-01"])
        self.assertEqual((by["SV03"]["present"], by["SV03"]["rate"]), (0, 0.0))
        self.assertEqual(st["overall_rate"], 50.0)                  # (100 + 50 + 0) / 3
        pd = {p["day"]: p for p in st["per_day"]}
        self.assertEqual((pd["2026-09-28"]["present"], pd["2026-09-28"]["total"]), (2, 3))
        self.assertEqual(pd["2026-09-29"]["rate"], 33.3)

    def test_date_range_filter(self):
        st = self.db.statistics("2026-09-29", "2026-09-30")
        self.assertEqual(st["days"], ["2026-09-29", "2026-09-30"])
        by = {p["student_id"]: p for p in st["per_student"]}
        self.assertEqual(by["SV01"]["rate"], 100.0)
        self.assertEqual(by["SV02"]["rate"], 50.0)                  # chỉ có mặt ngày 30
        self.assertEqual(self.db.statistics("2027-01-01", None)["days"], [])
        self.assertEqual(self.db.statistics("2027-01-01", None)["overall_rate"], 0.0)

    def test_deleted_student_excluded_from_statistics_but_history_kept(self):
        self.db.deactivate_student("SV02")
        st = self.db.statistics()
        self.assertEqual({p["student_id"] for p in st["per_student"]}, {"SV01", "SV03"})
        self.assertEqual(len(self.db.attendance_days()), 4)
        pd = {p["day"]: p for p in st["per_day"]}
        self.assertEqual(pd["2026-09-28"]["total"], 2)

    def test_rate_label(self):
        self.assertEqual([db.rate_label(r) for r in (100, 90, 89.9, 80, 75, 70, 69.9, 0)],
                         ["Tốt", "Tốt", "Khá", "Khá", "Trung bình", "Trung bình", "Cần nhắc nhở", "Cần nhắc nhở"])

    def test_export_three_sheets_and_range(self):
        path = os.path.join(self.dir, "r.xlsx")
        self.assertEqual(self.db.export_excel(path, "2026-09-29", "2026-09-30"), (3, 2))
        wb = openpyxl.load_workbook(path)
        self.assertEqual(wb.sheetnames, ["Diem Danh", "Tong Hop", "Theo Ngay"])
        rows = list(wb["Tong Hop"].iter_rows(values_only=True))
        self.assertEqual(rows[0][4:], ("Số buổi", "Có mặt", "Vắng", "Tỉ lệ (%)", "Xếp loại", "Đi muộn"))
        by = {r[0]: r for r in rows[1:] if r[0]}
        self.assertEqual(by["SV01"][4:], (2, 2, 0, 100.0, "Tốt", 0))
        self.assertEqual(by["SV03"][4:], (2, 0, 2, 0.0, "Cần nhắc nhở", 0))
        days = list(wb["Theo Ngay"].iter_rows(values_only=True))
        self.assertEqual(days[1], ("29/09/2026", 1, 3, 33.3, 0))
        self.assertEqual(days[2], ("30/09/2026", 2, 3, 66.7, 0))


if __name__ == "__main__":
    unittest.main()
