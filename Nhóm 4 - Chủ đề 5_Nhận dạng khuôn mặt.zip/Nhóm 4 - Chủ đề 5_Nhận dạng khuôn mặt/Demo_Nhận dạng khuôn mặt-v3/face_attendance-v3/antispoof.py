"""Chống giả mạo thụ động bằng MiniFASNet (ONNX): ảnh in, màn hình, video phát lại.

Mô hình chỉ nhìn một khung hình và trả lời "người thật hay ảnh của người".
Nó bổ sung (không thay thế) cho thử thách chớp mắt/quay đầu, và PHẢI được
hiệu chỉnh ngưỡng trên camera thật bằng tools/eval_spoof.py trước khi bật.

Tiền xử lý và nhãn đầu ra theo https://github.com/yakhyo/face-anti-spoofing :
  - cắt vùng quanh mặt với hệ số `scale`, đổi về 80x80, giữ nguyên BGR 0-255
  - đầu ra 3 lớp, softmax, lớp 1 = người thật
"""

import logging
import os

import numpy as np

log = logging.getLogger(__name__)

# (tên file, hệ số cắt) — trung bình xác suất của cả hai mô hình
DEFAULT_MODELS = (
    ("MiniFASNetV2.onnx", 2.7),
    ("MiniFASNetV1SE.onnx", 4.0),
)


def softmax(x):

    x = np.asarray(x, dtype=np.float64)
    x = x - x.max(axis=-1, keepdims=True)
    e = np.exp(x)

    return e / e.sum(axis=-1, keepdims=True)


def crop_for_spoof(image_bgr, bbox_xyxy, scale, size=(80, 80)):
    """Cắt vùng quanh khuôn mặt (rộng hơn khung mặt `scale` lần) và đổi cỡ."""

    import cv2

    h, w = image_bgr.shape[:2]

    x1, y1, x2, y2 = bbox_xyxy[:4]

    bw, bh = max(x2 - x1, 1), max(y2 - y1, 1)

    s = min((h - 1) / bh, (w - 1) / bw, scale)

    nw, nh = bw * s, bh * s

    cx, cy = x1 + bw / 2.0, y1 + bh / 2.0

    ax1 = max(0, int(cx - nw / 2))
    ay1 = max(0, int(cy - nh / 2))
    ax2 = min(w - 1, int(cx + nw / 2))
    ay2 = min(h - 1, int(cy + nh / 2))

    crop = image_bgr[ay1:ay2 + 1, ax1:ax2 + 1]

    return cv2.resize(crop, size)


class PassiveAntiSpoof:

    def __init__(self, model_dir="models", models=DEFAULT_MODELS, providers=None):

        import onnxruntime as ort

        self.sessions = []

        for fname, scale in models:

            path = os.path.join(model_dir, fname)

            if not os.path.exists(path):
                raise FileNotFoundError(
                    f"Thiếu mô hình chống giả mạo {path}. "
                    "Chạy: python tools/get_models.py"
                )

            sess = ort.InferenceSession(
                path, providers=providers or ["CPUExecutionProvider"]
            )

            shape = sess.get_inputs()[0].shape        # [batch, 3, H, W]

            self.sessions.append(
                (sess, sess.get_inputs()[0].name, scale, (int(shape[3]), int(shape[2])))
            )

    def real_probability(self, frame_bgr, bbox_xyxy):
        """Xác suất (0-1) khuôn mặt trong bbox là người thật."""

        probs = []

        for sess, name, scale, size in self.sessions:

            face = crop_for_spoof(frame_bgr, bbox_xyxy, scale, size)

            blob = np.transpose(face.astype(np.float32), (2, 0, 1))[None]

            logits = sess.run(None, {name: blob})[0]

            probs.append(softmax(logits)[0, 1])

        return float(np.mean(probs))
