"""So khớp khuôn mặt (thuần numpy, không cần camera hay giao diện)."""

from collections import Counter, deque

import numpy as np


def face_area(loc):
    """Diện tích khung mặt, loc = (top, right, bottom, left)."""

    top, right, bottom, left = loc

    return max(bottom - top, 0) * max(right - left, 0)


def _best_per_person(owner_ids, distances):

    best = {}

    for sid, d in zip(owner_ids, distances):
        if sid not in best or d < best[sid]:
            best[sid] = float(d)

    return best


def match_face(matrix, owner_ids, encoding, threshold=0.5, margin=0.04):
    """So khớp 1 vector khuôn mặt với tất cả mẫu đã đăng ký.

    Mỗi người có thể có nhiều mẫu; lấy khoảng cách nhỏ nhất của từng người.
    Trả về (student_id, distance) hoặc (None, best_distance_or_None).
    Từ chối khi quá xa, hoặc khi hai người khác nhau gần như ngang nhau.
    """

    if len(owner_ids) == 0:
        return None, None

    distances = np.linalg.norm(matrix - np.asarray(encoding), axis=1)

    ranked = sorted(
        _best_per_person(owner_ids, distances).items(),
        key=lambda kv: kv[1]
    )

    best_id, best_d = ranked[0]

    if best_d > threshold:
        return None, best_d

    if len(ranked) > 1 and ranked[1][1] - best_d < margin:
        return None, best_d

    return best_id, best_d


def distance_to_student(matrix, owner_ids, encoding, student_id):
    """Khoảng cách nhỏ nhất từ encoding tới các mẫu của một sinh viên."""

    idx = [i for i, sid in enumerate(owner_ids) if sid == student_id]

    if not idx:
        return None

    return float(
        np.linalg.norm(matrix[idx] - np.asarray(encoding), axis=1).min()
    )


class StableIdentity:
    """Chỉ xác nhận một người khi họ được nhận ra nhiều lần gần nhau.

    Tránh điểm danh nhầm do một khung hình bị nhiễu.
    """

    def __init__(self, window=6, min_votes=4):

        self.window = window
        self.min_votes = min_votes

        self.votes = deque(maxlen=window)

    def reset(self):

        self.votes.clear()

    def add(self, student_id):
        """Thêm kết quả của 1 lần nhận diện (None nếu không khớp).

        Trả về student_id đã xác nhận hoặc None.
        """

        self.votes.append(student_id)

        return self.confirmed

    @property
    def confirmed(self):

        counts = Counter(v for v in self.votes if v is not None)

        if not counts:
            return None

        sid, n = counts.most_common(1)[0]

        return sid if n >= self.min_votes else None

    @property
    def candidate(self):
        """Người đang được nghi là ai (chưa chắc chắn)."""

        counts = Counter(v for v in self.votes if v is not None)

        if not counts:
            return None

        return counts.most_common(1)[0][0]
