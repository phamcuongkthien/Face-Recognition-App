"""Điểm vào của chương trình: python main.py"""

import logging
import os
import sys
from logging.handlers import RotatingFileHandler

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def setup_logging():

    log_dir = os.path.join(BASE_DIR, "logs")
    os.makedirs(log_dir, exist_ok=True)

    handler = RotatingFileHandler(
        os.path.join(log_dir, "app.log"),
        maxBytes=1_000_000,
        backupCount=3,
        encoding="utf-8"
    )

    handler.setFormatter(
        logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
    )

    root = logging.getLogger()
    root.setLevel(logging.INFO)
    root.addHandler(handler)
    root.addHandler(logging.StreamHandler())


def check_dependencies():
    """Báo lỗi dễ hiểu nếu thiếu thư viện thay vì in traceback dài."""

    missing = []

    for module, package in (
        ("cv2", "opencv-python"),
        ("face_recognition", "face_recognition"),
        ("PIL", "Pillow"),
        ("openpyxl", "openpyxl"),
        ("numpy", "numpy"),
    ):
        try:
            __import__(module)
        except ImportError:
            missing.append(package)

    if missing:
        print(
            "Thiếu thư viện: " + ", ".join(missing) + "\n"
            "Cài bằng:  pip install -r requirements.txt"
        )
        sys.exit(1)


if __name__ == "__main__":

    setup_logging()

    check_dependencies()

    from app import Application

    Application()
