"""Theo dõi khuôn mặt giữa các khung hình để mỗi người có trạng thái riêng.

Ghép khung mặt mới với khung cũ theo độ chồng lấn (IoU) — đủ cho cảnh người
đứng/đi chậm trước camera điểm danh. Thuần Python, không cần camera.
"""

import itertools


def iou(a, b):
    """IoU của hai khung (top, right, bottom, left)."""

    t = max(a[0], b[0])
    l = max(a[3], b[3])
    r = min(a[1], b[1])
    bt = min(a[2], b[2])

    iw, ih = max(r - l, 0), max(bt - t, 0)

    inter = iw * ih

    area_a = max(a[2] - a[0], 0) * max(a[1] - a[3], 0)
    area_b = max(b[2] - b[0], 0) * max(b[1] - b[3], 0)

    union = area_a + area_b - inter

    return inter / union if union > 0 else 0.0


class Track:
    """Một khuôn mặt đang được theo dõi + trạng thái nhận diện/xác minh riêng."""

    def __init__(self, tid, loc, now, state):

        self.id = tid
        self.loc = loc
        self.first_seen = now
        self.last_seen = now
        self.state = state          # engine gắn vào: PersonState


class Tracker:

    def __init__(self, make_state, min_iou=0.2, max_age=1.5, max_tracks=16):

        self._ids = itertools.count(1)
        self.make_state = make_state
        self.min_iou = min_iou
        self.max_age = max_age
        self.max_tracks = max_tracks
        self.tracks = []

    def reset(self):

        self.tracks = []

    def update(self, locs, now):
        """Ghép các khung mới (locs) với track cũ. Trả về list Track cùng thứ tự locs."""

        pairs = sorted(
            (
                (iou(t.loc, loc), ti, li)
                for ti, t in enumerate(self.tracks)
                for li, loc in enumerate(locs)
            ),
            reverse=True
        )

        used_t, used_l, assigned = set(), set(), {}

        for score, ti, li in pairs:

            if score < self.min_iou:
                break

            if ti in used_t or li in used_l:
                continue

            used_t.add(ti)
            used_l.add(li)
            assigned[li] = self.tracks[ti]

        out = []

        for li, loc in enumerate(locs):

            t = assigned.get(li)

            if t is None:
                t = Track(next(self._ids), loc, now, self.make_state())
                self.tracks.append(t)

            t.loc = loc
            t.last_seen = now

            out.append(t)

        # Bỏ track đã mất quá lâu (người đã đi khỏi khung hình)
        self.tracks = [
            t for t in self.tracks if now - t.last_seen <= self.max_age
        ][-self.max_tracks:]

        return out
