"""Các mô hình tạo vector đặc trưng khuôn mặt.

  dlib    : face_recognition (ResNet, vector 128 chiều)   — mặc định
  arcface : ArcFace MobileFaceNet qua onnxruntime (512 chiều) — cần
            `python tools/get_models.py` để tải mô hình.

Mọi backend đều có cùng giao diện:
  name, dim, default_threshold, default_margin, encode(rgb_full, locations_full)

Vector của hai backend KHÔNG so sánh được với nhau, nên cơ sở dữ liệu lưu
tên mô hình kèm mỗi mẫu (cột face_samples.model).
"""

import logging
import os

import numpy as np

log = logging.getLogger(__name__)

# Tọa độ 5 điểm chuẩn của ảnh 112x112 mà ArcFace được huấn luyện
ARCFACE_TEMPLATE = np.array(
    [
        [38.2946, 51.6963],   # mắt bên trái ảnh
        [73.5318, 51.5014],   # mắt bên phải ảnh
        [56.0252, 71.7366],   # mũi
        [41.5493, 92.3655],   # khóe miệng bên trái ảnh
        [70.7299, 92.2041],   # khóe miệng bên phải ảnh
    ],
    dtype=np.float32
)


def five_points(landmarks):
    """5 điểm (2 mắt, mũi, 2 khóe miệng) từ landmark 68 điểm của face_recognition.

    Sắp theo vị trí trong ảnh (trái -> phải) để không phụ thuộc cách đặt tên.
    Trả về None nếu thiếu điểm.
    """

    try:
        eye_a = np.mean(landmarks["left_eye"], axis=0)
        eye_b = np.mean(landmarks["right_eye"], axis=0)
        nose = np.asarray(landmarks["nose_tip"][len(landmarks["nose_tip"]) // 2], float)
        top = landmarks["top_lip"]
        mouth_a = np.asarray(top[0], float)
        mouth_b = np.asarray(top[6], float)
    except (KeyError, IndexError, TypeError, ValueError):
        return None

    eyes = sorted([eye_a, eye_b], key=lambda p: p[0])
    mouth = sorted([mouth_a, mouth_b], key=lambda p: p[0])

    return np.array([eyes[0], eyes[1], nose, mouth[0], mouth[1]], dtype=np.float32)


def align_face(image_bgr, points5, size=112):
    """Cắt và xoay khuôn mặt về đúng tư thế chuẩn 112x112."""

    import cv2

    m, _ = cv2.estimateAffinePartial2D(
        np.asarray(points5, dtype=np.float32),
        ARCFACE_TEMPLATE,
        method=cv2.LMEDS
    )

    if m is None:
        return None

    return cv2.warpAffine(image_bgr, m, (size, size), borderValue=0.0)


def preprocess_arcface(aligned_bgr):
    """Ảnh đã căn chỉnh (BGR) -> tensor 1x3x112x112 (RGB, chuẩn hóa về [-1, 1])."""

    rgb = aligned_bgr[:, :, ::-1].astype(np.float32)

    blob = (rgb - 127.5) / 127.5

    return np.transpose(blob, (2, 0, 1))[None]


def l2_normalize(v):

    v = np.asarray(v, dtype=np.float64).ravel()

    n = np.linalg.norm(v)

    return v / n if n > 0 else v


class DlibBackend:

    name = "dlib"
    dim = 128
    default_threshold = 0.5
    default_margin = 0.04
    needs_full_res = False

    def encode(self, rgb, locations):

        import face_recognition as fr

        return fr.face_encodings(rgb, locations)


class ArcFaceBackend:

    name = "arcface"
    dim = 512
    default_threshold = 1.0
    default_margin = 0.05
    needs_full_res = True        # căn chỉnh chính xác cần ảnh gốc, không phải ảnh thu nhỏ

    def __init__(self, model_path, providers=None):

        if not os.path.exists(model_path):
            raise FileNotFoundError(
                f"Chưa có mô hình ArcFace tại {model_path}. "
                "Chạy: python tools/get_models.py"
            )

        import onnxruntime as ort

        self.session = ort.InferenceSession(
            model_path,
            providers=providers or ["CPUExecutionProvider"]
        )

        self.input_name = self.session.get_inputs()[0].name

    def embed_aligned(self, aligned_bgr):
        """Vector 512 chiều đã chuẩn hóa từ ảnh 112x112 đã căn chỉnh."""

        out = self.session.run(None, {self.input_name: preprocess_arcface(aligned_bgr)})[0]

        return l2_normalize(out)

    def encode(self, rgb, locations):
        """Mỗi vị trí mặt -> 1 vector, hoặc None nếu không căn chỉnh được."""

        import face_recognition as fr

        bgr = np.ascontiguousarray(rgb[:, :, ::-1])

        marks = fr.face_landmarks(rgb, locations)

        out = []

        for m in marks:

            pts = five_points(m)
            aligned = align_face(bgr, pts) if pts is not None else None

            out.append(None if aligned is None else self.embed_aligned(aligned))

        return out


def make_backend(cfg, base_dir="."):
    """Tạo backend theo cấu hình (cfg.backend)."""

    if cfg.backend == "arcface":

        path = cfg.arcface_model

        if not os.path.isabs(path):
            path = os.path.join(base_dir, path)

        return ArcFaceBackend(path)

    return DlibBackend()


def thresholds_for(cfg):
    """(ngưỡng, biên) áp dụng cho backend đang chọn."""

    if cfg.backend == "arcface":
        return cfg.arcface_threshold, cfg.arcface_margin

    return cfg.match_threshold, cfg.match_margin
