"""Mã hóa vector khuôn mặt khi lưu vào cơ sở dữ liệu (AES-256-GCM).

Vector khuôn mặt là dữ liệu sinh trắc học nhạy cảm. Khi bật mã hóa, ai chỉ
sao chép được file diemdanh.db (hoặc bản sao lưu) sẽ không đọc được vector.

Mỗi vector được mã hóa riêng, gắn với mã sinh viên (AAD) nên không thể hoán
đổi vector giữa hai sinh viên trong file mà không bị phát hiện.

Khóa:
  - Mặc định: file `data.key` (32 byte ngẫu nhiên) tạo lần đầu. Hãy SAO LƯU file
    này ở nơi khác với bản sao lưu cơ sở dữ liệu; mất khóa là mất dữ liệu mặt.
  - An toàn hơn: đặt biến môi trường FACE_DB_PASSPHRASE. Khi đó file data.key
    chỉ chứa "muối" và khóa được suy ra bằng scrypt từ mật khẩu cụm từ; chép
    cả hai file vẫn không giải mã được nếu không có mật khẩu.
"""

import hashlib
import logging
import os

log = logging.getLogger(__name__)

MAGIC = b"EMB1"
NONCE_LEN = 12
TAG_LEN = 16


class WrongKeyError(Exception):
    """Dữ liệu đã mã hóa nhưng khóa không đúng hoặc dữ liệu bị sửa."""


def is_encrypted(blob):

    return (
        isinstance(blob, (bytes, bytearray))
        and len(blob) > len(MAGIC) + NONCE_LEN + TAG_LEN
        and bytes(blob[:len(MAGIC)]) == MAGIC
    )


class EmbeddingCipher:

    def __init__(self, key):

        if len(key) != 32:
            raise ValueError("Khóa phải dài 32 byte")

        from cryptography.hazmat.primitives.ciphers.aead import AESGCM

        self._aes = AESGCM(bytes(key))

    def encrypt(self, plain, aad=b""):

        nonce = os.urandom(NONCE_LEN)

        return MAGIC + nonce + self._aes.encrypt(nonce, bytes(plain), aad)

    def decrypt(self, blob, aad=b""):
        """Giải mã; blob chưa mã hóa (dữ liệu cũ) được trả về nguyên vẹn."""

        if not is_encrypted(blob):
            return bytes(blob)

        from cryptography.exceptions import InvalidTag

        nonce = bytes(blob[len(MAGIC):len(MAGIC) + NONCE_LEN])
        ct = bytes(blob[len(MAGIC) + NONCE_LEN:])

        try:
            return self._aes.decrypt(nonce, ct, aad)
        except InvalidTag as e:
            raise WrongKeyError(
                "Không giải mã được vector khuôn mặt: sai khóa (data.key / "
                "FACE_DB_PASSPHRASE) hoặc dữ liệu đã bị sửa."
            ) from e


def derive_key(passphrase, salt):

    return hashlib.scrypt(
        passphrase.encode("utf-8"), salt=salt, n=2 ** 14, r=8, p=1, dklen=32
    )


def load_or_create_key(path, passphrase=None):
    """Đọc (hoặc tạo) khóa. Có passphrase thì file chỉ giữ muối."""

    if os.path.exists(path):

        with open(path, "rb") as f:
            raw = f.read()

        if len(raw) != 32:
            raise ValueError(f"{path} không phải file khóa hợp lệ (cần 32 byte)")

    else:

        raw = os.urandom(32)

        # Tạo file với quyền chỉ chủ sở hữu đọc được
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)

        with os.fdopen(fd, "wb") as f:
            f.write(raw)

        log.info("Đã tạo khóa mã hóa mới: %s", path)

    return derive_key(passphrase, raw) if passphrase else raw


def make_cipher(cfg, base_dir):
    """Tạo cipher theo cấu hình, hoặc None nếu không bật mã hóa."""

    if not cfg.encrypt_embeddings:
        return None

    path = cfg.key_file

    if not os.path.isabs(path):
        path = os.path.join(base_dir, path)

    passphrase = os.environ.get("FACE_DB_PASSPHRASE") or None

    return EmbeddingCipher(load_or_create_key(path, passphrase))
