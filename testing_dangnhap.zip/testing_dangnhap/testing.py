import os
import pickle
import datetime
import tkinter as tk
from tkinter import ttk, messagebox

import cv2
import face_recognition as fr
import numpy as np
from PIL import Image, ImageTk, ImageDraw, ImageFont
import openpyxl
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter


# =========================================================
# FILE DỮ LIỆU
# =========================================================
EXCEL_FILE = "diemdanh.xlsx"
DATASET_FILE = "dataset.pkl"
ACCOUNT_FILE = "accounts.pkl"


# =========================================================
# CẤU HÌNH EXCEL
# =========================================================
FIXED_HEADERS = ["Họ và Tên", "Lớp", "Khoa"]
FIXED_COLS = len(FIXED_HEADERS)


# =========================================================
# DANH SÁCH KHOA
# =========================================================
FACULTIES = [
    "Công nghệ thông tin",
    "Kinh tế",
    "Điện - Điện tử",
    "Cơ khí",
    "Ngoại ngữ",
    "Sư phạm",
    "Y - Dược",
    "Luật",
    "Khác",
]


# =========================================================
# BẢNG MÀU
# =========================================================
C_BG = "#EEF2F7"
C_HEADER = "#1E3A8A"
C_CARD = "#FFFFFF"

C_PRIMARY = "#2563EB"
C_PRIMARY_H = "#1D4ED8"

C_SUCCESS = "#16A34A"
C_SUCCESS_H = "#15803D"

C_DANGER = "#DC2626"
C_DANGER_H = "#B91C1C"

C_TEXT = "#0F172A"
C_MUTED = "#64748B"
C_BORDER = "#D5DDE8"

FONT = "Segoe UI"


# =========================================================
# TẠO NÚT
# =========================================================
def make_button(parent, text, color, hover, command, font_size=12):
    btn = tk.Label(
        parent,
        text=text,
        bg=color,
        fg="white",
        font=(FONT, font_size, "bold"),
        cursor="hand2",
        pady=10
    )

    btn.bind("<Enter>", lambda e: btn.config(bg=hover))
    btn.bind("<Leave>", lambda e: btn.config(bg=color))
    btn.bind("<Button-1>", lambda e: command())

    return btn


# =========================================================
# CĂN GIỮA CỬA SỔ
# =========================================================
def center_window(win, parent, w, h):
    parent.update_idletasks()

    x = parent.winfo_x() + (parent.winfo_width() - w) // 2
    y = parent.winfo_y() + (parent.winfo_height() - h) // 2

    win.geometry(
        f"{w}x{h}+{max(x, 0)}+{max(y, 0)}"
    )


# =========================================================
# ĐĂNG KÝ TÀI KHOẢN
# =========================================================
class AccountRegisterDialog(tk.Toplevel):

    def __init__(self, parent, accounts):
        super().__init__(parent)

        self.title("Đăng ký tài khoản")
        self.configure(bg=C_CARD)
        self.resizable(False, False)

        self.accounts = accounts
        self.result = None

        center_window(self, parent, 430, 390)

        # Header
        header = tk.Frame(self, bg=C_PRIMARY)
        header.pack(fill="x")

        tk.Label(
            header,
            text="ĐĂNG KÝ TÀI KHOẢN",
            bg=C_PRIMARY,
            fg="white",
            font=(FONT, 16, "bold"),
            pady=15
        ).pack()

        # Body
        body = tk.Frame(
            self,
            bg=C_CARD,
            padx=30,
            pady=20
        )
        body.pack(fill="both", expand=True)

        self.var_username = tk.StringVar()
        self.var_password = tk.StringVar()
        self.var_confirm = tk.StringVar()

        self._field(
            body,
            "Tên đăng nhập",
            tk.Entry(
                body,
                textvariable=self.var_username,
                font=(FONT, 12),
                relief="solid",
                bd=1
            )
        )

        self._field(
            body,
            "Mật khẩu",
            tk.Entry(
                body,
                textvariable=self.var_password,
                show="*",
                font=(FONT, 12),
                relief="solid",
                bd=1
            )
        )

        self._field(
            body,
            "Nhập lại mật khẩu",
            tk.Entry(
                body,
                textvariable=self.var_confirm,
                show="*",
                font=(FONT, 12),
                relief="solid",
                bd=1
            )
        )

        # Buttons
        btns = tk.Frame(body, bg=C_CARD)
        btns.pack(fill="x", pady=(20, 0))

        btns.columnconfigure(
            (0, 1),
            weight=1,
            uniform="b"
        )

        make_button(
            btns,
            "Hủy",
            C_MUTED,
            "#475569",
            self.destroy,
            11
        ).grid(
            row=0,
            column=0,
            sticky="ew",
            padx=(0, 6)
        )

        make_button(
            btns,
            "Đăng ký",
            C_SUCCESS,
            C_SUCCESS_H,
            self.submit,
            11
        ).grid(
            row=0,
            column=1,
            sticky="ew",
            padx=(6, 0)
        )

        self.bind(
            "<Return>",
            lambda e: self.submit()
        )

        self.bind(
            "<Escape>",
            lambda e: self.destroy()
        )

        self.transient(parent)
        self.grab_set()

    @staticmethod
    def _field(parent, label, widget):

        tk.Label(
            parent,
            text=label,
            bg=C_CARD,
            fg=C_MUTED,
            font=(FONT, 10, "bold"),
            anchor="w"
        ).pack(
            fill="x",
            pady=(8, 2)
        )

        widget.pack(
            fill="x",
            ipady=5
        )

    def submit(self):

        username = self.var_username.get().strip()
        password = self.var_password.get()
        confirm = self.var_confirm.get()

        if not username or not password or not confirm:
            messagebox.showwarning(
                "Thiếu thông tin",
                "Vui lòng nhập đầy đủ thông tin!",
                parent=self
            )
            return

        if len(username) < 3:
            messagebox.showwarning(
                "Tên đăng nhập",
                "Tên đăng nhập phải có ít nhất 3 ký tự!",
                parent=self
            )
            return

        if len(password) < 6:
            messagebox.showwarning(
                "Mật khẩu",
                "Mật khẩu phải có ít nhất 6 ký tự!",
                parent=self
            )
            return

        if password != confirm:
            messagebox.showwarning(
                "Mật khẩu",
                "Mật khẩu nhập lại không khớp!",
                parent=self
            )
            return

        if username in self.accounts:
            messagebox.showwarning(
                "Trùng tài khoản",
                "Tên đăng nhập này đã tồn tại!",
                parent=self
            )
            return

        self.result = (
            username,
            password
        )

        self.destroy()


# =========================================================
# ĐĂNG NHẬP
# =========================================================
class LoginPage:

    def __init__(self, root, on_login):

        self.root = root
        self.on_login = on_login

        self.accounts = self.load_accounts()

        self.build_ui()

    # -----------------------------------------------------
    # LOAD ACCOUNT
    # -----------------------------------------------------
    def load_accounts(self):

        if not os.path.exists(ACCOUNT_FILE):
            return {}

        try:
            with open(ACCOUNT_FILE, "rb") as f:
                return pickle.load(f)

        except Exception:
            return {}

    # -----------------------------------------------------
    # SAVE ACCOUNT
    # -----------------------------------------------------
    def save_accounts(self):

        with open(ACCOUNT_FILE, "wb") as f:
            pickle.dump(
                self.accounts,
                f
            )

    # -----------------------------------------------------
    # GIAO DIỆN ĐĂNG NHẬP
    # -----------------------------------------------------
    def build_ui(self):

        self.clear_window()

        self.root.title(
            "Đăng nhập - Hệ thống điểm danh"
        )

        self.root.geometry(
            "520x520"
        )

        self.root.minsize(
            450,
            450
        )

        self.root.configure(
            bg=C_BG
        )

        # Header
        header = tk.Frame(
            self.root,
            bg=C_HEADER,
            height=100
        )

        header.pack(
            fill="x"
        )

        tk.Label(
            header,
            text="HỆ THỐNG ĐIỂM DANH",
            bg=C_HEADER,
            fg="white",
            font=(FONT, 20, "bold"),
            pady=18
        ).pack()

        tk.Label(
            header,
            text="Đăng nhập hệ thống",
            bg=C_HEADER,
            fg="#BFDBFE",
            font=(FONT, 11)
        ).pack()

        # Card
        card = tk.Frame(
            self.root,
            bg=C_CARD,
            highlightbackground=C_BORDER,
            highlightthickness=1,
            padx=35,
            pady=30
        )

        card.pack(
            padx=50,
            pady=40,
            fill="both"
        )

        # Username
        tk.Label(
            card,
            text="Tên đăng nhập",
            bg=C_CARD,
            fg=C_MUTED,
            font=(FONT, 10, "bold"),
            anchor="w"
        ).pack(
            fill="x",
            pady=(0, 5)
        )

        self.username_var = tk.StringVar()

        username_entry = tk.Entry(
            card,
            textvariable=self.username_var,
            font=(FONT, 12),
            relief="solid",
            bd=1
        )

        username_entry.pack(
            fill="x",
            ipady=7
        )

        # Password
        tk.Label(
            card,
            text="Mật khẩu",
            bg=C_CARD,
            fg=C_MUTED,
            font=(FONT, 10, "bold"),
            anchor="w"
        ).pack(
            fill="x",
            pady=(18, 5)
        )

        self.password_var = tk.StringVar()

        password_entry = tk.Entry(
            card,
            textvariable=self.password_var,
            show="*",
            font=(FONT, 12),
            relief="solid",
            bd=1
        )

        password_entry.pack(
            fill="x",
            ipady=7
        )

        # Login button
        make_button(
            card,
            "ĐĂNG NHẬP",
            C_PRIMARY,
            C_PRIMARY_H,
            self.login,
            13
        ).pack(
            fill="x",
            pady=(25, 10)
        )

        # Register button
        make_button(
            card,
            "ĐĂNG KÝ TÀI KHOẢN",
            C_SUCCESS,
            C_SUCCESS_H,
            self.register_account,
            12
        ).pack(
            fill="x"
        )

        tk.Label(
            self.root,
            text="Face Recognition Attendance System",
            bg=C_BG,
            fg=C_MUTED,
            font=(FONT, 9)
        ).pack(
            pady=(0, 15)
        )

        username_entry.focus_set()

        self.root.bind(
            "<Return>",
            lambda e: self.login()
        )

    # -----------------------------------------------------
    # XÓA GIAO DIỆN
    # -----------------------------------------------------
    def clear_window(self):

        for widget in self.root.winfo_children():
            widget.destroy()

    # -----------------------------------------------------
    # ĐĂNG NHẬP
    # -----------------------------------------------------
    def login(self):

        username = self.username_var.get().strip()
        password = self.password_var.get()

        if not username or not password:

            messagebox.showwarning(
                "Thiếu thông tin",
                "Vui lòng nhập tên đăng nhập và mật khẩu!"
            )

            return

        if username not in self.accounts:

            messagebox.showerror(
                "Đăng nhập thất bại",
                "Tên đăng nhập không tồn tại!"
            )

            return

        if self.accounts[username] != password:

            messagebox.showerror(
                "Đăng nhập thất bại",
                "Mật khẩu không chính xác!"
            )

            return

        self.root.unbind("<Return>")

        self.on_login(username)

    # -----------------------------------------------------
    # ĐĂNG KÝ ACCOUNT
    # -----------------------------------------------------
    def register_account(self):

        dialog = AccountRegisterDialog(
            self.root,
            self.accounts
        )

        self.root.wait_window(dialog)

        if not dialog.result:
            return

        username, password = dialog.result

        self.accounts[username] = password

        self.save_accounts()

        messagebox.showinfo(
            "Thành công",
            "Đăng ký tài khoản thành công!\n\n"
            f"Tên đăng nhập: {username}"
        )

        self.username_var.set(username)
        self.password_var.set("")


# =========================================================
# HỘP THOẠI ĐĂNG KÝ KHUÔN MẶT
# =========================================================
class RegisterDialog(tk.Toplevel):

    def __init__(self, parent):

        super().__init__(parent)

        self.title(
            "Đăng ký khuôn mặt"
        )

        self.configure(
            bg=C_CARD
        )

        self.resizable(
            False,
            False
        )

        self.result = None

        center_window(
            self,
            parent,
            420,
            400
        )

        header = tk.Frame(
            self,
            bg=C_PRIMARY
        )

        header.pack(
            fill="x"
        )

        tk.Label(
            header,
            text="Thông tin đăng ký",
            bg=C_PRIMARY,
            fg="white",
            font=(FONT, 15, "bold"),
            pady=14
        ).pack()

        body = tk.Frame(
            self,
            bg=C_CARD,
            padx=30,
            pady=15
        )

        body.pack(
            fill="both",
            expand=True
        )

        self.var_name = tk.StringVar()
        self.var_class = tk.StringVar()
        self.var_faculty = tk.StringVar()

        name_entry = tk.Entry(
            body,
            textvariable=self.var_name,
            font=(FONT, 12),
            relief="solid",
            bd=1
        )

        class_entry = tk.Entry(
            body,
            textvariable=self.var_class,
            font=(FONT, 12),
            relief="solid",
            bd=1
        )

        faculty_box = ttk.Combobox(
            body,
            textvariable=self.var_faculty,
            values=FACULTIES,
            font=(FONT, 12),
            state="readonly"
        )

        self._field(
            body,
            "Họ và tên",
            name_entry
        )

        self._field(
            body,
            "Lớp",
            class_entry
        )

        self._field(
            body,
            "Khoa",
            faculty_box
        )

        name_entry.focus_set()

        btns = tk.Frame(
            body,
            bg=C_CARD
        )

        btns.pack(
            fill="x",
            pady=(18, 0)
        )

        btns.columnconfigure(
            (0, 1),
            weight=1,
            uniform="b"
        )

        make_button(
            btns,
            "Hủy",
            C_MUTED,
            "#475569",
            self.destroy,
            11
        ).grid(
            row=0,
            column=0,
            sticky="ew",
            padx=(0, 6)
        )

        make_button(
            btns,
            "Đăng ký",
            C_SUCCESS,
            C_SUCCESS_H,
            self.submit,
            11
        ).grid(
            row=0,
            column=1,
            sticky="ew",
            padx=(6, 0)
        )

        self.bind(
            "<Return>",
            lambda e: self.submit()
        )

        self.bind(
            "<Escape>",
            lambda e: self.destroy()
        )

        self.transient(parent)
        self.grab_set()

    @staticmethod
    def _field(parent, label, widget):

        tk.Label(
            parent,
            text=label,
            bg=C_CARD,
            fg=C_MUTED,
            font=(FONT, 10, "bold"),
            anchor="w"
        ).pack(
            fill="x",
            pady=(8, 2)
        )

        widget.pack(
            fill="x",
            ipady=5
        )

    def submit(self):

        name = self.var_name.get().strip()
        lop = self.var_class.get().strip().upper()
        khoa = self.var_faculty.get().strip()

        if not name or not lop or not khoa:

            messagebox.showwarning(
                "Thiếu thông tin",
                "Vui lòng nhập đầy đủ Họ tên, Lớp và Khoa!",
                parent=self
            )

            return

        self.result = (
            name.title(),
            lop,
            khoa
        )

        self.destroy()


# =========================================================
# HỘP THOẠI XÓA
# =========================================================
class DeleteDialog(tk.Toplevel):

    def __init__(self, parent, options):

        super().__init__(parent)

        self.title(
            "Xóa đăng ký"
        )

        self.configure(
            bg=C_CARD
        )

        self.resizable(
            False,
            False
        )

        self.result = None

        center_window(
            self,
            parent,
            460,
            230
        )

        header = tk.Frame(
            self,
            bg=C_DANGER
        )

        header.pack(
            fill="x"
        )

        tk.Label(
            header,
            text="Xóa đăng ký",
            bg=C_DANGER,
            fg="white",
            font=(FONT, 15, "bold"),
            pady=12
        ).pack()

        body = tk.Frame(
            self,
            bg=C_CARD,
            padx=30,
            pady=15
        )

        body.pack(
            fill="both",
            expand=True
        )

        tk.Label(
            body,
            text="Chọn người cần xóa",
            bg=C_CARD,
            fg=C_MUTED,
            font=(FONT, 10, "bold"),
            anchor="w"
        ).pack(
            fill="x",
            pady=(0, 4)
        )

        self.combo = ttk.Combobox(
            body,
            values=options,
            state="readonly",
            font=(FONT, 11)
        )

        self.combo.pack(
            fill="x",
            ipady=4
        )

        if options:
            self.combo.current(0)

        btns = tk.Frame(
            body,
            bg=C_CARD
        )

        btns.pack(
            fill="x",
            pady=(18, 0)
        )

        btns.columnconfigure(
            (0, 1),
            weight=1,
            uniform="b"
        )

        make_button(
            btns,
            "Hủy",
            C_MUTED,
            "#475569",
            self.destroy,
            11
        ).grid(
            row=0,
            column=0,
            sticky="ew",
            padx=(0, 6)
        )

        make_button(
            btns,
            "Xóa",
            C_DANGER,
            C_DANGER_H,
            self.submit,
            11
        ).grid(
            row=0,
            column=1,
            sticky="ew",
            padx=(6, 0)
        )

        self.transient(parent)
        self.grab_set()

    def submit(self):

        idx = self.combo.current()

        if idx >= 0:
            self.result = idx

        self.destroy()


# =========================================================
# ỨNG DỤNG ĐIỂM DANH
# =========================================================
class FaceRecognitionApp:

    def __init__(self, root, username, on_logout):

        self.root = root
        self.username = username
        self.on_logout = on_logout

        self.root.title(
            "Hệ thống Điểm Danh & Đăng Ký Khuôn Mặt"
        )

        self.root.geometry(
            "1050x680"
        )

        self.root.minsize(
            900,
            600
        )

        self.root.configure(
            bg=C_BG
        )

        self.style_widgets()

        self.font_label = self.load_font(20)

        # Dữ liệu khuôn mặt
        self.known_names = []
        self.known_classes = []
        self.known_faculties = []
        self.known_name_encodings = []

        self.current_face_encodings = []
        self.current_index = None

        # Cờ điều khiển các vòng lặp after()
        self.running = True
        self.frame_job = None
        self.clock_job = None

        self.load_dataset()
        self.init_excel()

        # Camera
        self.video_capture = cv2.VideoCapture(0)

        self.build_ui()

        if not self.video_capture.isOpened():
            messagebox.showerror(
                "Lỗi camera",
                "Không mở được camera!\n"
                "Hãy kiểm tra camera có đang bị ứng dụng khác dùng không."
            )

        self.update_frame()

        self.root.protocol(
            "WM_DELETE_WINDOW",
            self.on_closing
        )

    # =====================================================
    # STYLE
    # =====================================================
    def style_widgets(self):

        style = ttk.Style()

        try:
            style.theme_use("clam")

        except tk.TclError:
            pass

        style.configure(
            "TCombobox",
            padding=5
        )

    # =====================================================
    # FONT
    # =====================================================
    @staticmethod
    def load_font(size):

        for path in (
            "arial.ttf",
            "Arial.ttf",
            "segoeui.ttf",
            "DejaVuSans.ttf",
            "/System/Library/Fonts/Supplemental/Arial.ttf",
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
        ):

            try:
                return ImageFont.truetype(
                    path,
                    size
                )

            except OSError:
                continue

        return ImageFont.load_default()

    # =====================================================
    # GIAO DIỆN CHÍNH
    # =====================================================
    def build_ui(self):

        # Header
        header = tk.Frame(
            self.root,
            bg=C_HEADER
        )

        header.pack(
            fill="x"
        )

        tk.Label(
            header,
            text="HỆ THỐNG ĐIỂM DANH KHUÔN MẶT",
            bg=C_HEADER,
            fg="white",
            font=(FONT, 18, "bold"),
            pady=14
        ).pack(
            side="left",
            padx=25
        )

        # Khu vực bên phải header
        user_box = tk.Frame(
            header,
            bg=C_HEADER
        )

        user_box.pack(
            side="right",
            padx=20
        )

        tk.Label(
            user_box,
            text=f"Tài khoản: {self.username}",
            bg=C_HEADER,
            fg="#BFDBFE",
            font=(FONT, 10, "bold")
        ).pack(
            side="left",
            padx=(0, 12)
        )

        logout_btn = tk.Label(
            user_box,
            text="Đăng xuất",
            bg=C_DANGER,
            fg="white",
            font=(FONT, 10, "bold"),
            cursor="hand2",
            padx=12,
            pady=7
        )

        logout_btn.pack(
            side="left"
        )

        logout_btn.bind(
            "<Enter>",
            lambda e: logout_btn.config(
                bg=C_DANGER_H
            )
        )

        logout_btn.bind(
            "<Leave>",
            lambda e: logout_btn.config(
                bg=C_DANGER
            )
        )

        logout_btn.bind(
            "<Button-1>",
            lambda e: self.logout()
        )

        # Main
        main = tk.Frame(
            self.root,
            bg=C_BG
        )

        main.pack(
            fill="both",
            expand=True,
            padx=25,
            pady=20
        )

        main.columnconfigure(
            0,
            weight=3,
            uniform="cols"
        )

        main.columnconfigure(
            1,
            weight=2,
            uniform="cols"
        )

        main.rowconfigure(
            0,
            weight=1
        )

        # =================================================
        # CAMERA
        # =================================================
        cam_card = tk.Frame(
            main,
            bg=C_CARD,
            highlightbackground=C_BORDER,
            highlightthickness=1
        )

        cam_card.grid(
            row=0,
            column=0,
            sticky="nsew",
            padx=(0, 15)
        )

        tk.Label(
            cam_card,
            text="Camera",
            bg=C_CARD,
            fg=C_TEXT,
            font=(FONT, 12, "bold"),
            anchor="w"
        ).pack(
            fill="x",
            padx=15,
            pady=(10, 5)
        )

        cam_box = tk.Frame(
            cam_card,
            bg="#0F172A"
        )

        cam_box.pack(
            expand=True,
            fill="both",
            padx=15,
            pady=(0, 15)
        )

        cam_box.pack_propagate(False)

        self.cam_label = tk.Label(
            cam_box,
            bg="#0F172A"
        )

        self.cam_label.pack(
            expand=True,
            fill="both"
        )

        # =================================================
        # BÊN PHẢI
        # =================================================
        right = tk.Frame(
            main,
            bg=C_BG
        )

        right.grid(
            row=0,
            column=1,
            sticky="nsew"
        )

        # Status
        self.status_card = tk.Frame(
            right,
            bg=C_PRIMARY,
            height=95
        )

        self.status_card.pack(
            fill="x"
        )

        self.status_card.pack_propagate(False)

        self.status_var = tk.StringVar(
            value="Sẵn sàng"
        )

        self.status_lbl = tk.Label(
            self.status_card,
            textvariable=self.status_var,
            bg=C_PRIMARY,
            fg="white",
            font=(FONT, 13, "bold"),
            pady=16,
            wraplength=340,
            justify="center"
        )

        self.status_lbl.pack(
            expand=True,
            fill="both"
        )

        # Thông tin người
        info = tk.Frame(
            right,
            bg=C_CARD,
            highlightbackground=C_BORDER,
            highlightthickness=1,
            height=150
        )

        info.pack(
            fill="x",
            pady=15
        )

        info.pack_propagate(False)

        tk.Label(
            info,
            text="Người đang nhận diện",
            bg=C_CARD,
            fg=C_MUTED,
            font=(FONT, 10, "bold"),
            anchor="w"
        ).pack(
            fill="x",
            padx=15,
            pady=(10, 4)
        )

        self.info_vars = {}

        for key, title in (
            ("name", "Họ tên"),
            ("class", "Lớp"),
            ("faculty", "Khoa")
        ):

            row = tk.Frame(
                info,
                bg=C_CARD
            )

            row.pack(
                fill="x",
                padx=15,
                pady=3
            )

            tk.Label(
                row,
                text=title,
                width=7,
                anchor="w",
                bg=C_CARD,
                fg=C_MUTED,
                font=(FONT, 11)
            ).pack(
                side="left"
            )

            var = tk.StringVar(
                value="—"
            )

            self.info_vars[key] = var

            tk.Label(
                row,
                textvariable=var,
                anchor="w",
                bg=C_CARD,
                fg=C_TEXT,
                font=(FONT, 12, "bold"),
                justify="left"
            ).pack(
                side="left",
                fill="x"
            )

        tk.Frame(
            info,
            bg=C_CARD,
            height=8
        ).pack()

        # Buttons
        btn_box = tk.Frame(
            right,
            bg=C_BG
        )

        btn_box.pack(
            fill="x"
        )

        make_button(
            btn_box,
            "✔  Điểm danh",
            C_SUCCESS,
            C_SUCCESS_H,
            self.mark_attendance,
            13
        ).pack(
            fill="x",
            pady=(0, 10)
        )

        make_button(
            btn_box,
            "＋  Đăng ký khuôn mặt",
            C_PRIMARY,
            C_PRIMARY_H,
            self.register_face,
            13
        ).pack(
            fill="x",
            pady=(0, 10)
        )

        make_button(
            btn_box,
            "✖  Xóa đăng ký",
            C_DANGER,
            C_DANGER_H,
            self.delete_face,
            13
        ).pack(
            fill="x"
        )

        # Clock
        self.clock_var = tk.StringVar()

        tk.Label(
            right,
            textvariable=self.clock_var,
            bg=C_BG,
            fg=C_MUTED,
            font=(FONT, 10)
        ).pack(
            pady=15
        )

        self.update_clock()

    # =====================================================
    # CLOCK
    # =====================================================
    def update_clock(self):

        if not self.running:
            return

        self.clock_var.set(
            datetime.datetime.now().strftime(
                "%H:%M:%S  -  %d/%m/%Y"
            )
        )

        self.clock_job = self.root.after(
            1000,
            self.update_clock
        )

    # =====================================================
    # STATUS
    # =====================================================
    def set_status(self, text, kind="info"):

        color = {
            "info": C_PRIMARY,
            "success": C_SUCCESS,
            "error": C_DANGER
        }[kind]

        self.status_var.set(
            text
        )

        self.status_card.config(
            bg=color
        )

        self.status_lbl.config(
            bg=color
        )

    # =====================================================
    # THÔNG TIN
    # =====================================================
    def set_info(
        self,
        name="—",
        lop="—",
        khoa="—"
    ):

        self.info_vars["name"].set(
            name
        )

        self.info_vars["class"].set(
            lop or "—"
        )

        self.info_vars["faculty"].set(
            khoa or "—"
        )

    # =====================================================
    # EXCEL
    # =====================================================
    @staticmethod
    def style_sheet(ws):

        fill = PatternFill(
            "solid",
            fgColor="1E3A8A"
        )

        for cell in ws[1]:

            if cell.value is not None:

                cell.font = Font(
                    bold=True,
                    color="FFFFFF"
                )

                cell.fill = fill

                cell.alignment = Alignment(
                    horizontal="center",
                    vertical="center"
                )

        widths = {
            1: 28,
            2: 14,
            3: 26
        }

        for col in range(
            1,
            ws.max_column + 1
        ):

            ws.column_dimensions[
                get_column_letter(col)
            ].width = widths.get(
                col,
                20
            )

    def init_excel(self):

        try:

            if not os.path.exists(
                EXCEL_FILE
            ):

                wb = Workbook()

                ws = wb.active

                ws.title = "Diem Danh"

                ws.append(
                    FIXED_HEADERS
                )

                self.style_sheet(
                    ws
                )

                wb.save(
                    EXCEL_FILE
                )

            else:

                wb = openpyxl.load_workbook(
                    EXCEL_FILE
                )

                ws = wb.active

                if ws.cell(
                    row=1,
                    column=2
                ).value != "Lớp":

                    ws.insert_cols(
                        2,
                        2
                    )

                    for i, h in enumerate(
                        FIXED_HEADERS,
                        start=1
                    ):

                        ws.cell(
                            row=1,
                            column=i,
                            value=h
                        )

                    self.style_sheet(
                        ws
                    )

                    wb.save(
                        EXCEL_FILE
                    )

        except PermissionError:

            messagebox.showerror(
                "Lỗi",
                f"Vui lòng đóng file {EXCEL_FILE} rồi mở lại ứng dụng!"
            )

    # =====================================================
    # LOAD DATASET
    # =====================================================
    def load_dataset(self):

        if os.path.exists(
            DATASET_FILE
        ):

            try:

                with open(
                    DATASET_FILE,
                    "rb"
                ) as f:

                    data = pickle.load(
                        f
                    )

                self.known_names = data.get(
                    "names",
                    []
                )

                self.known_name_encodings = data.get(
                    "encodings",
                    []
                )

                n = len(
                    self.known_names
                )

                self.known_classes = data.get(
                    "classes",
                    [""] * n
                )

                self.known_faculties = data.get(
                    "faculties",
                    [""] * n
                )

            except Exception as e:

                print(
                    f"Lỗi khi nạp dữ liệu: {e}"
                )

    # =====================================================
    # SAVE DATASET
    # =====================================================
    def save_dataset(self):

        data = {
            "names": self.known_names,
            "classes": self.known_classes,
            "faculties": self.known_faculties,
            "encodings": self.known_name_encodings
        }

        with open(
            DATASET_FILE,
            "wb"
        ) as f:

            pickle.dump(
                data,
                f
            )

    # =====================================================
    # CAMERA + NHẬN DIỆN
    # =====================================================
    def update_frame(self):

        if not self.running or self.video_capture is None:
            return

        ret, frame = self.video_capture.read()

        if ret:

            frame = cv2.flip(
                frame,
                1
            )

            small = cv2.resize(
                frame,
                (0, 0),
                fx=0.5,
                fy=0.5
            )

            rgb_small = np.ascontiguousarray(
                small[:, :, ::-1]
            )

            face_locations = fr.face_locations(
                rgb_small
            )

            self.current_face_encodings = fr.face_encodings(
                rgb_small,
                face_locations
            )

            self.current_index = None

            # PIL
            pil_image = Image.fromarray(
                cv2.cvtColor(
                    frame,
                    cv2.COLOR_BGR2RGB
                )
            )

            draw = ImageDraw.Draw(
                pil_image
            )

            for (
                top,
                right,
                bottom,
                left
            ), enc in zip(
                face_locations,
                self.current_face_encodings
            ):

                label = "Unknown"

                color = (
                    220,
                    38,
                    38
                )

                if self.known_name_encodings:

                    distances = fr.face_distance(
                        self.known_name_encodings,
                        enc
                    )

                    best = int(
                        np.argmin(
                            distances
                        )
                    )

                    if distances[best] <= 0.5:

                        label = self.known_names[
                            best
                        ]

                        color = (
                            22,
                            163,
                            74
                        )

                        self.current_index = best

                top *= 2
                right *= 2
                bottom *= 2
                left *= 2

                draw.rectangle(
                    [
                        left,
                        top,
                        right,
                        bottom
                    ],
                    outline=color,
                    width=3
                )

                draw.rectangle(
                    [
                        left,
                        bottom,
                        right,
                        bottom + 30
                    ],
                    fill=color
                )

                draw.text(
                    (
                        left + 6,
                        bottom + 3
                    ),
                    label,
                    font=self.font_label,
                    fill="white"
                )

            # Cập nhật thông tin
            if self.current_index is not None:

                i = self.current_index

                self.set_info(
                    self.known_names[i],
                    self.known_classes[i],
                    self.known_faculties[i]
                )

            else:

                self.set_info()

            # Resize camera
            lbl_w = self.cam_label.winfo_width()
            lbl_h = self.cam_label.winfo_height()

            if lbl_w > 10 and lbl_h > 10:

                scale = min(
                    lbl_w / pil_image.width,
                    lbl_h / pil_image.height
                )

                pil_image = pil_image.resize(
                    (
                        max(
                            int(
                                pil_image.width * scale
                            ),
                            1
                        ),
                        max(
                            int(
                                pil_image.height * scale
                            ),
                            1
                        )
                    ),
                    Image.LANCZOS
                )

            imgtk = ImageTk.PhotoImage(
                image=pil_image
            )

            self.cam_label.imgtk = imgtk

            self.cam_label.configure(
                image=imgtk
            )

        if self.running:

            self.frame_job = self.root.after(
                15,
                self.update_frame
            )

    # =====================================================
    # ĐĂNG KÝ KHUÔN MẶT
    # =====================================================
    def register_face(self):

        if len(
            self.current_face_encodings
        ) == 0:

            messagebox.showwarning(
                "Cảnh báo",
                "Không tìm thấy khuôn mặt nào!\n"
                "Vui lòng nhìn thẳng vào camera."
            )

            return

        if len(
            self.current_face_encodings
        ) > 1:

            messagebox.showwarning(
                "Cảnh báo",
                "Có nhiều hơn 1 người trong camera!\n"
                "Vui lòng chỉ để 1 người."
            )

            return

        if self.current_index is not None:

            i = self.current_index

            messagebox.showwarning(
                "Đã đăng ký",
                f"Khuôn mặt này đã được đăng ký:\n"
                f"{self.known_names[i]} - "
                f"{self.known_classes[i]}"
            )

            return

        encoding = self.current_face_encodings[0]

        dlg = RegisterDialog(
            self.root
        )

        self.root.wait_window(
            dlg
        )

        if not dlg.result:
            return

        name, lop, khoa = dlg.result

        # Kiểm tra trùng
        for n, c in zip(
            self.known_names,
            self.known_classes
        ):

            if n == name and c == lop:

                messagebox.showwarning(
                    "Trùng thông tin",
                    f"{name} - {lop} đã tồn tại trong hệ thống!"
                )

                return

        try:

            wb = openpyxl.load_workbook(
                EXCEL_FILE
            )

            ws = wb.active

            ws.append(
                [
                    name,
                    lop,
                    khoa
                ]
            )

            self.style_sheet(
                ws
            )

            wb.save(
                EXCEL_FILE
            )

        except PermissionError:

            messagebox.showerror(
                "Lỗi",
                f"Vui lòng đóng file {EXCEL_FILE} trước khi đăng ký!"
            )

            return

        # Lưu khuôn mặt
        self.known_name_encodings.append(
            encoding
        )

        self.known_names.append(
            name
        )

        self.known_classes.append(
            lop
        )

        self.known_faculties.append(
            khoa
        )

        self.save_dataset()

        self.set_status(
            f"Đăng ký thành công:\n{name}",
            "success"
        )

        messagebox.showinfo(
            "Thành công",
            f"Đã đăng ký thành công!\n\n"
            f"{name}\n"
            f"Lớp: {lop}\n"
            f"Khoa: {khoa}"
        )

    # =====================================================
    # ĐIỂM DANH
    # =====================================================
    def mark_attendance(self):

        if len(
            self.current_face_encodings
        ) == 0:

            self.set_status(
                "Không thấy ai\ntrong camera!",
                "error"
            )

            return

        if self.current_index is None:

            self.set_status(
                "Thất bại:\nKhuôn mặt chưa đăng ký!",
                "error"
            )

            return

        i = self.current_index

        name = self.known_names[i]
        lop = self.known_classes[i]

        try:

            wb = openpyxl.load_workbook(
                EXCEL_FILE
            )

            ws = wb.active

            now = datetime.datetime.now()

            time_str = now.strftime(
                "%H:%M:%S %d/%m"
            )

            today = now.strftime(
                "%d/%m"
            )

            found = False

            for row_idx in range(
                2,
                ws.max_row + 1
            ):

                if (
                    ws.cell(
                        row=row_idx,
                        column=1
                    ).value == name
                    and
                    (
                        ws.cell(
                            row=row_idx,
                            column=2
                        ).value or ""
                    ) == lop
                ):

                    found = True

                    col_idx = FIXED_COLS + 1

                    last_value = None

                    while (
                        ws.cell(
                            row=row_idx,
                            column=col_idx
                        ).value is not None
                    ):

                        last_value = ws.cell(
                            row=row_idx,
                            column=col_idx
                        ).value

                        col_idx += 1

                    # Chặn điểm danh 2 lần/ngày
                    if (
                        last_value
                        and
                        str(last_value).endswith(
                            today
                        )
                    ):

                        self.set_status(
                            f"{name}\n"
                            "đã điểm danh hôm nay rồi!",
                            "info"
                        )

                        return

                    ws.cell(
                        row=row_idx,
                        column=col_idx,
                        value=time_str
                    )

                    if (
                        ws.cell(
                            row=1,
                            column=col_idx
                        ).value is None
                    ):

                        ws.cell(
                            row=1,
                            column=col_idx,
                            value=f"Buổi "
                                  f"{col_idx - FIXED_COLS}"
                        )

                    self.style_sheet(
                        ws
                    )

                    wb.save(
                        EXCEL_FILE
                    )

                    break

            if found:

                self.set_status(
                    f"Điểm danh thành công:\n{name}",
                    "success"
                )

            else:

                self.set_status(
                    "Không tìm thấy người này\n"
                    "trong file Excel!",
                    "error"
                )

        except PermissionError:

            messagebox.showerror(
                "Lỗi",
                f"Vui lòng đóng file {EXCEL_FILE} để điểm danh!"
            )

    # =====================================================
    # XÓA KHUÔN MẶT
    # =====================================================
    def delete_face(self):

        if not self.known_names:

            messagebox.showinfo(
                "Thông báo",
                "Chưa có ai đăng ký trong hệ thống."
            )

            return

        options = [
            f"{n}  -  {c}  -  {k}"
            for n, c, k in zip(
                self.known_names,
                self.known_classes,
                self.known_faculties
            )
        ]

        dlg = DeleteDialog(
            self.root,
            options
        )

        self.root.wait_window(
            dlg
        )

        if dlg.result is None:
            return

        idx = dlg.result

        name = self.known_names[idx]
        lop = self.known_classes[idx]

        if not messagebox.askyesno(
            "Xác nhận",
            f"Bạn chắc chắn muốn xóa\n"
            f"{name} - {lop}?"
        ):

            return

        try:

            wb = openpyxl.load_workbook(
                EXCEL_FILE
            )

            ws = wb.active

            for row in range(
                2,
                ws.max_row + 1
            ):

                if (
                    ws.cell(
                        row=row,
                        column=1
                    ).value == name
                    and
                    (
                        ws.cell(
                            row=row,
                            column=2
                        ).value or ""
                    ) == lop
                ):

                    ws.delete_rows(
                        row,
                        1
                    )

                    break

            wb.save(
                EXCEL_FILE
            )

        except PermissionError:

            messagebox.showerror(
                "Lỗi",
                f"Vui lòng đóng file {EXCEL_FILE} trước!"
            )

            return

        self.known_names.pop(
            idx
        )

        self.known_classes.pop(
            idx
        )

        self.known_faculties.pop(
            idx
        )

        self.known_name_encodings.pop(
            idx
        )

        self.save_dataset()

        self.set_status(
            f"Đã xóa:\n{name}",
            "info"
        )

        messagebox.showinfo(
            "Thành công",
            f"Đã xóa đăng ký của {name}"
        )

    # =====================================================
    # DỪNG CAMERA + CÁC VÒNG LẶP
    # =====================================================
    def shutdown(self):

        self.running = False

        for job in (self.frame_job, self.clock_job):

            if job is not None:

                try:
                    self.root.after_cancel(job)
                except tk.TclError:
                    pass

        self.frame_job = None
        self.clock_job = None

        if self.video_capture is not None:

            self.video_capture.release()

            self.video_capture = None

    # =====================================================
    # ĐĂNG XUẤT
    # =====================================================
    def logout(self):

        confirm = messagebox.askyesno(
            "Đăng xuất",
            "Bạn có chắc chắn muốn đăng xuất?"
        )

        if not confirm:
            return

        # Dừng camera và các vòng lặp
        self.shutdown()

        # Xóa giao diện điểm danh
        for widget in self.root.winfo_children():
            widget.destroy()

        # Quay về đăng nhập
        self.on_logout()

    # =====================================================
    # ĐÓNG CHƯƠNG TRÌNH
    # =====================================================
    def on_closing(self):

        self.shutdown()

        self.root.destroy()


# =========================================================
# CHƯƠNG TRÌNH
# =========================================================
class Application:

    def __init__(self):

        self.root = tk.Tk()

        self.current_app = None
        self.current_username = None

        self.show_login()

        self.root.mainloop()

    # -----------------------------------------------------
    # HIỂN THỊ LOGIN
    # -----------------------------------------------------
    def show_login(self):

        self.current_app = None

        LoginPage(
            self.root,
            self.login_success
        )

    # -----------------------------------------------------
    # LOGIN THÀNH CÔNG
    # -----------------------------------------------------
    def login_success(self, username):

        self.current_username = username

        # Xóa toàn bộ giao diện đăng nhập trước khi vào màn hình điểm danh
        for widget in self.root.winfo_children():
            widget.destroy()

        self.current_app = FaceRecognitionApp(
            self.root,
            username,
            self.logout_success
        )

    # -----------------------------------------------------
    # LOGOUT THÀNH CÔNG
    # -----------------------------------------------------
    def logout_success(self):

        self.current_app = None
        self.current_username = None

        self.root.protocol(
            "WM_DELETE_WINDOW",
            self.root.destroy
        )

        self.show_login()


# =========================================================
# MAIN
# =========================================================
if __name__ == "__main__":

    Application()